import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Base extends SetUp {
    protected void clickToWebElement(By by) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(by)).click();

        } catch (StaleElementReferenceException e) {
            wait.until(ExpectedConditions.elementToBeClickable(by)).click();
        }
    }

    protected void sendKeysToElement(By by, String text){
        try {
            wait.until(ExpectedConditions.elementToBeClickable(by)).sendKeys(text);
        }
        catch (StaleElementReferenceException e) {
            wait.until(ExpectedConditions.elementToBeClickable(by)).sendKeys(text);
        }
    }

    protected boolean elementIsDisplayed(String path){
        return driver.findElement(By.xpath(path)).isDisplayed();
    }

    protected boolean elementIsVisible(By by){
        return driver.findElement(by).isEnabled();
    }
}
