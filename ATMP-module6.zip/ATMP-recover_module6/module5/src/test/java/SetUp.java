import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import java.io.*;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class SetUp {
    protected WebDriver driver;
    protected WebDriverWait wait;
    static String login;
    static String pwd;
    static String subject;
    static String addressee;
    static String textArea;

    @BeforeTest
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:/data/chromedriver_win32/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
        wait = new WebDriverWait(driver, 7);
        driver.get("http://gmail.com");
        driver.manage().window().maximize();
    }

    @BeforeTest
    public static void getProperties(){
        Properties properties = new Properties();
        InputStream file = null;
        try {
            file = new FileInputStream(new File("src/test/java/resourses/prop.properties").getAbsoluteFile());
            properties.load(file);
            login = properties.getProperty("login");
            pwd = properties.getProperty("password");
            subject = properties.getProperty("subject");
            addressee = properties.getProperty("addressee");
            textArea = properties.getProperty("textArea");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                file.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @AfterTest
    public void stopBrowser(){
        driver.quit();
    }
}
