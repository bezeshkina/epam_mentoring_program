package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjects.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class MainTest extends GetProp{
    private WebDriver driver;
    private String driverPath = "src/test/java/resources/chromedriver.exe";
    private StartPage startPage;
    private String addressee;
    private String subject;
    private String textArea;

    @BeforeTest
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    @Test
    public void gmailCreateMailTest() throws IOException, InterruptedException {
        addressee = getProperties("addressee");
        subject = getProperties("subject");
        textArea = getProperties("textArea");
        new LoginPage(driver).open().fillLoginField(getProperties("login")).submitBtnClick();
        new PwdPage(driver).fillPwdField(getProperties("pwd")).submitBtnClick();
        startPage = new StartPage(driver);
        startPage.createBtnClick();
        new CreateNewEmailPage(driver).fillForm(addressee, subject, textArea).closeWindow();
        startPage.goToDraftsCategory();
        new DraftsPage(driver).findElementFromList(subject);
        new SendingEmailPage(driver).verifyAddressee(addressee);
        new SendingEmailPage(driver).verifySubject(subject);
        new SendingEmailPage(driver).verifyText(textArea);
        new SendingEmailPage(driver).sendEmail();
        new DraftsPage(driver).emailDisappeared(subject);
        new DraftsPage(driver).goToSentCategory();
        new SentPage(driver).findElementFromList(subject);
        new SentPage(driver).callingTheAccountMenu();
        new SentPage(driver).logOut();
    }

    @AfterTest
    public void close(){
        driver.quit();
    }
}
