package tests;

import java.io.*;
import java.util.Properties;

public class GetProp {
    private static String fileprop = "./src/test/java/resources/prop.properties";

    public static String getProperties(String request) throws IOException {
        Properties properties = new Properties();
        InputStream file;

        file = new FileInputStream(new File(fileprop).getAbsoluteFile());
        properties.load(file);

        switch (request) {
            case "login":
                return
                        properties.getProperty("login");
            case "pwd":
                return
                        properties.getProperty("password");
            case "subject":
                return
                        properties.getProperty("subject");
            case "addressee":
                return
                        properties.getProperty("addressee");
            case "textArea":
                return
                        properties.getProperty("textArea");
            default:
                throw new IOException();
        }
    }
}
