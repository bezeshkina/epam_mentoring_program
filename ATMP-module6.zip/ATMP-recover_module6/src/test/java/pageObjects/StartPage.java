package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StartPage extends Page{
    @FindBy(xpath = "//div[text()='Написать']")
    protected WebElement createBtn;

    @FindBy(xpath = "//a[@title='Черновики']")
    protected WebElement draftsCategory;

    public StartPage(WebDriver driver) {
        super(driver);
        waitForElementIsVisible(createBtn);
    }

    public CreateNewEmailPage createBtnClick(){
        waitElementAndClick(createBtn);
        return new CreateNewEmailPage(driver);
    }

    public DraftsPage goToDraftsCategory(){
        waitElementAndClick(draftsCategory);
        return new DraftsPage(driver);
    }
}
