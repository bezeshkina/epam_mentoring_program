package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreateNewEmailPage extends Page{
    @FindBy(xpath = "//textarea[@aria-label='Кому']")
    protected WebElement addresseeField;

    @FindBy(xpath = "//input[@name='subjectbox']")
    protected WebElement subjectField;

    @FindBy(xpath = "//div[@aria-label='Тело письма']")
    protected WebElement textAria;

    @FindBy(xpath = "//img[@data-tooltip='Сохранить и закрыть']")
    protected WebElement closeWindowBtn;

    public CreateNewEmailPage(WebDriver driver) {
        super(driver);
    }

    public CreateNewEmailPage fillForm(String addressee, String subj, String text){
        waitElementAndSendKeys(addresseeField, addressee);
        waitElementAndSendKeys(subjectField, subj);
        waitElementAndSendKeys(textAria, text);
        return this;
    }

    public StartPage closeWindow(){
        waitElementAndClick(closeWindowBtn);
        return new StartPage(driver);
    }
}
