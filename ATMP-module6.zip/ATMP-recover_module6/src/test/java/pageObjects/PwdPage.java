package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PwdPage extends Page {
    @FindBy(xpath = "//input[@type='password']")
    protected WebElement passwordField;

    @FindBy(xpath = "//span[text()='Далее']")
    protected WebElement submitBtn;

    public PwdPage(WebDriver driver) {
        super(driver);
    }

    public PwdPage fillPwdField(String pwd){
        waitElementAndSendKeys(passwordField, pwd);
        return this;
    }

    public StartPage submitBtnClick(){
        waitElementAndClick(submitBtn);
        return new StartPage(driver);
    }
}
