package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class DraftsPage extends Page {
    @FindBy(xpath = "//span[@class='bog']")
    protected List<WebElement> listOfDrafts;

    @FindBy(css = ".TN.bzz.aHS-bnu>div:nth-child(2)>span>a")
    protected WebElement sentCategory;

    public DraftsPage(WebDriver driver) {
        super(driver);
        waitForTitle("Черновик");
    }

    public SendingEmailPage findElementFromList(String text) {
        for (WebElement element : listOfDrafts) {
            if (element.getText().contains(text)) {
                element.click();
                return new SendingEmailPage(driver);
            }
        }
        throw new AssertionError("Element isn't found");
    }

    public SentPage goToSentCategory() {
        waitElementAndClick(sentCategory);
        return new SentPage(driver);
    }

    public DraftsPage emailDisappeared(String text) {
        for (WebElement element : listOfDrafts) {
            if (element.getText().contains(text)) {
                throw new AssertionError("Email wasn't sent");
            }
        }
        return this;
    }
}

