package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SendingEmailPage extends Page {
    @FindBy(css = ".aoD.hl>div:nth-child(1)>span")
    protected WebElement addresseeField;

    @FindBy(xpath = ("//input[@name='subject']"))
    protected WebElement subjField;

    @FindBy(css = ".Ar.Au>div")
    protected WebElement textArea;

    @FindBy(css = ".gU.Up>div>div:nth-child(2)")
    protected WebElement sendBtn;

    public SendingEmailPage(WebDriver driver) {
        super(driver);
        waitForElementIsVisible(addresseeField);
    }

    public SendingEmailPage verifyAddressee(String text) {
        verifyEquels(addresseeField.getText(), text, "Addressee doesn't match");
        return this;
    }

    public SendingEmailPage verifySubject(String text) {
        verifyEquels(subjField.getAttribute("value"), text, "Subject doesn't match");
        return this;
    }

    public SendingEmailPage verifyText(String text) {
        verifyEquels(textArea.getText(), text, "Text in text-area doesn't match");
        return this;
    }

    public DraftsPage sendEmail(){
        waitElementAndClick(sendBtn);
        return new DraftsPage(driver);
    }
}
