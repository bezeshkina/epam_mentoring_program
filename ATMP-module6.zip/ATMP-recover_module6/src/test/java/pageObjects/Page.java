package pageObjects;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public abstract class Page {
    protected WebDriver driver;
    private static final int WAIT_FOR_ELEMENT_SECONDS = 15;

    public Page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(this.driver, this);
    }

    protected void waitForElementIsVisible(WebElement element) {
        try {
            new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.visibilityOf(element));
        }
        catch (StaleElementReferenceException e){
            new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.visibilityOf(element));
        }
    }

    protected void waitForElementToBeClickable(WebElement element) {
        new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.elementToBeClickable(element));
    }

    protected void waitElementAndClick(WebElement element) {
        new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).click();
    }

    protected void waitElementAndSendKeys(WebElement element, String text) {
        new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.visibilityOf(element)).sendKeys(text);
    }

    protected void waitForTitle(String title) {
        try {
            new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.titleIs(title));
        } catch (TimeoutException ex) {
            ex.getStackTrace();
        }
    }

    protected void verifyEquels(String actual, String expected, String message){
        try {
            Assert.assertEquals(actual, expected, message);
        }
        catch (AssertionError e){
            System.out.println(e);
        }
    }

    protected void verifyFalse(WebElement element){
        try{
            Assert.assertFalse(element.isDisplayed());
        }
        catch (AssertionError e){
            System.out.println(e);
        }
    }

    protected void waitForInvisibility(WebElement element){
        try{
            new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.invisibilityOf(element));
        }
        catch (NoSuchElementException e){
            new WebDriverWait(driver, WAIT_FOR_ELEMENT_SECONDS).until(ExpectedConditions.invisibilityOf(element));
        }
    }
}