package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends Page {
    protected final String URL = "http://gmail.com";

    @FindBy(xpath = "//input[@id='identifierId']")
    protected WebElement loginField;

    @FindBy(xpath = "//span[text()='Далее']")
    protected WebElement submitBtn;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public LoginPage open(){
        driver.get(URL);
        return this;
    }

    public LoginPage fillLoginField(String login){
        waitElementAndSendKeys(loginField, login);
        return this;
    }

    public PwdPage submitBtnClick(){
        waitElementAndClick(submitBtn);
        return new PwdPage(driver);
    }

}
