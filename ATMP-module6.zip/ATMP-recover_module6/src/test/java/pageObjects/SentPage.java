package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class SentPage extends Page {


    @FindBy(xpath = "//span[@class='bog']")
    protected List<WebElement> listOfSentEmails;

    @FindBy(xpath = "//a[@class='gb_b gb_hb gb_R']")
    protected WebElement accountBtn;

    @FindBy(xpath = "//a[@id='gb_71']")
    protected WebElement logOutBtn;

    public SentPage(WebDriver driver) {
        super(driver);
        waitForTitle("Отправленные");
    }

    public SentPage findElementFromList(String text){
        for (WebElement element : listOfSentEmails) {
            if (element.getText().contains(text)) {
                return this;
            }
        }
        throw new AssertionError("Element isn't found");
    }

    public SentPage callingTheAccountMenu(){
        waitElementAndClick(accountBtn);
        return this;
    }

    public LoginPage logOut(){
        waitElementAndClick(logOutBtn);
        return new LoginPage(driver);
    }
}
