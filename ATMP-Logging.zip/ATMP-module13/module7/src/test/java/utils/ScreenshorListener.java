package utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestListener;
import org.testng.ITestResult;
import ru.yandex.qatools.allure.annotations.Attachment;

public class ScreenshorListener implements ITestListener {
    @Attachment(value = "Page screenshot", type = "image/png")
    public static byte[] takeScreenshot(){
        return ((TakesScreenshot)WebDriverSingleton.getInstance()).getScreenshotAs(OutputType.BYTES);
    }

    public void onTestFailure(ITestResult result){
        takeScreenshot();
    }

    public void onTestSuccess(ITestResult result){
        takeScreenshot();
    }
}
