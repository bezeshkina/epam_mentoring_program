package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class WebDriverSingleton {
    private static String driverChromePath = "src/test/java/resources/chromedriver.exe";
    private static WebDriver instance;

    private WebDriverSingleton(){

    }

    public static WebDriver getInstance() {
        if (instance != null){
            return instance;
        }
        return instance = init();
    }

    private static WebDriver init() {
        System.setProperty("webdriver.chrome.driver", driverChromePath);
        WebDriver driver = new ChromeDriver();
/*        try {
            driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), new ChromeOptions());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }*/
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public static void close(){
        if (instance != null){
            try {
                instance.quit();
            }
            catch (Exception e){
                System.out.println("Can't close browser");
            }
            finally {
                instance = null;
            }
        }
    }
}
