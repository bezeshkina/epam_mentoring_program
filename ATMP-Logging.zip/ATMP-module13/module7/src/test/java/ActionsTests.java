import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pages.*;
import ru.yandex.qatools.allure.annotations.Description;
import utils.ScreenshorListener;
import utils.WebDriverSingleton;

import java.net.MalformedURLException;

@Listeners({ScreenshorListener.class})
public class ActionsTests {
    private String login = "atmpmailbox@gmail.com";
    private String password = "QwertyYtrewq123";
    private String addressee = "atmptest@yandex.ru";
    private String subject = "test subject";
    private String textArea = "text text text";

    @BeforeTest(description = "precondition: Authorization")
    public void logIn() {
        new LoginPage().openPage().fillLoginFieldAndClick(login).fillPasswordField(password).Login();
    }

    @Test
    @Description("End-to-end test of creating email using Actions")
    public void testAction() {
        try {
            new InboxPage().clickCreateBtn();
            new CreateEmailPage().fillAddresseeField(addressee).fillSubjectField(subject).fillTextAreaField(textArea).closeWindow();
            new InboxPage().goToDrafts();
            new DraftsCategory().findElementOnPageAndClick(subject);
            new SendingEmailPage().verifyAddressee(addressee).verifySubject(subject).verifyText(textArea).sendEmail();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @AfterTest(description = "close browser")
    public void closeBrowser(){
        WebDriverSingleton.close();
    }
}
