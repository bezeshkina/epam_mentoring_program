package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

public class LoginPage extends Page{
    private static final String url = "http://gmail.com";

    @FindBy(xpath = "//input[@id='identifierId']")
    private WebElement loginField;

    @FindBy(xpath = "//input[@type='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//span[text()='Далее']")
    private WebElement submitBtn;

    public LoginPage() {
        super();
        waitTitle("Gmail");
    }

    @Step("Open Gmail.com")
    public LoginPage openPage(){
        driver.get(url);
        return this;
    }

    @Step("Type login")
    public LoginPage fillLoginFieldAndClick(String login){
        waitForElementAndSendKeys(loginField, login);
        waitForElementAndClick(submitBtn);
        return this;
    }

    @Step("Type password")
    public LoginPage fillPasswordField(String pwd){
        waitForElementAndSendKeys(passwordField, pwd);
        return this;
    }

    @Step("Click Submit button")
    public InboxPage Login(){
        waitForElementAndClick(submitBtn);
        return new InboxPage();
    }
}
