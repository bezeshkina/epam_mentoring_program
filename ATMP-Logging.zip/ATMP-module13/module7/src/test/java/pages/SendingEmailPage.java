package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

import java.net.MalformedURLException;

public class SendingEmailPage extends Page{
    @FindBy(xpath = "//input[@name='subject']")
    protected WebElement subjectText;

    @FindBy(css = ".aoD.hl>div:nth-child(1)>span")
    protected WebElement addresseeText;

    @FindBy(css = ".Ar.Au>div")
    protected WebElement textAreaText;

    @FindBy(css = ".gU.Up>div>div:nth-child(2)")
    protected WebElement sendBtn;

    public SendingEmailPage() throws MalformedURLException {
    }

    @Step("Send email")
    public DraftsCategory sendEmail() throws MalformedURLException {
        clickCtrlEnter();
        return new DraftsCategory();
    }

    @Step("Match the addressee")
    public SendingEmailPage verifyAddressee(String expected){
        verifyEquels("addresseeText.getText()", expected, "Addressee isn't match");
        return this;
    }

    @Step("Match the subject")
    public SendingEmailPage verifySubject(String expected){
        verifyEquels(subjectText.getAttribute("value"), expected, "Subject isn't match");
        return this;
    }

    @Step("Match the text")
    public SendingEmailPage verifyText(String expected){
        verifyEquels(textAreaText.getText(), expected, "Text isn't match");
        return this;
    }
}
