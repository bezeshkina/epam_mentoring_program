package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

public class CreateEmailPage extends Page{
    @FindBy(xpath = "//textarea[@aria-label='Кому']")
    protected WebElement addresseeField;

    @FindBy(xpath = "//input[@name='subjectbox']")
    protected WebElement subjectField;

    @FindBy(xpath = "//div[@aria-label='Тело письма']")
    protected WebElement textAreaField;

    @FindBy(xpath = "//img[@data-tooltip='Сохранить и закрыть']")
    protected WebElement closeBtn;

    @FindBy(xpath = "//table[@id='undefined']//textarea")
    protected WebElement dropArea;

    public CreateEmailPage(){
        super();

    }

    @Step("Fill the Addressee field")
    public CreateEmailPage fillAddresseeField(String addressee){
        waitForElementAndSendKeys(addresseeField, addressee);
        clickTab();
        return this;
    }

    @Step("Fill the Subject field")
    public CreateEmailPage fillSubjectField(String subject){
        waitForElementAndSendKeys(subjectField, subject);
        clickTab();
        return this;
    }

    @Step("Fill the TextArea")
    public CreateEmailPage fillTextAreaField(String text){
        waitForElementAndSendKeys(textAreaField, text);
        return this;
    }

    @Step("Click to cross-button and close window")
    public InboxPage closeWindow(){
        waitForElementAndClick(closeBtn);
        return new InboxPage();
    }
}
