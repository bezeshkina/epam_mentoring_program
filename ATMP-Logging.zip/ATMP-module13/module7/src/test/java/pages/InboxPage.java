package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

public class InboxPage extends Page{
    @FindBy(xpath = "//div[text()='Написать']")
    protected WebElement createBtn;

    @FindBy(xpath = "//a[@title='Черновики']")
    protected WebElement draftsCategory;

    public InboxPage() {
        super();
        waitTitle("Входящие");
    }

    @Step("Click Create button")
    public CreateEmailPage clickCreateBtn(){
        waitForElementAndClick(createBtn);
        return new CreateEmailPage();
    }

    @Step("Go to Draft category")
    public DraftsCategory goToDrafts(){
        jsAction(draftsCategory, jsHighlight);
        waitForElementAndClick(draftsCategory);
        jsAction(draftsCategory, jsUnhighlight);
        return new DraftsCategory();
    }
}
