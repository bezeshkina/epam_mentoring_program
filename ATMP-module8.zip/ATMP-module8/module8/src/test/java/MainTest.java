import businessObjects.Email;
import businessObjects.User;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjects.*;
import webdriverManager.WebDriverSingleton;

public class MainTest {
    private String login = new User().getLogin();
    private String password = new User().getPassword();
    private String addressee = new Email().getAddressee();
    private String subject = new Email().getSubject();
    private String textArea = new Email().getTextArea();

    @BeforeTest(description = "precondition: Authorization")
    public void logIn() {
        new LoginPage().openPage();
        new LoginPage().signIn(login, password);
    }

    @Test
    public void testAction() {
        new InboxPage().clickCreateBtn();
        new CreateEmailPage().fillAddresseeField(addressee).fillSubjectField(subject).fillTextAreaField(textArea).closeWindow();
        new InboxPage().goToDrafts();
        new DraftsCategory().findElementOnPageAndClick(subject);
        new SendingEmailPage().verifyAddressee(addressee).verifySubject(subject).verifyText(textArea).sendEmail();
        new DraftsCategory().logOut();
    }

    @AfterTest(description = "close browser")
    public void closeBrowser() {
        WebDriverSingleton.closeDriver();
    }
}
