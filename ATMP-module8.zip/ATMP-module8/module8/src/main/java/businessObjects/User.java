package businessObjects;

public class User {
    protected String login = "atmpmailbox@gmail.com";
    protected String password = "QwertyYtrewq123";

    public String getLogin(){
        return login;
    }

    public String getPassword(){
        return password;
    }
}
