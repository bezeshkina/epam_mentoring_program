package helper;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import pageObjects.Page;
import webdriverManager.WebDriverSingleton;

public class Clicker extends Page {
    public void clickTab(){
        Actions actions = new Actions(WebDriverSingleton.getDriver());
        actions.sendKeys(Keys.TAB).build().perform();
    }

    public void clickCtrlEnter(){
        Actions actions = new Actions(WebDriverSingleton.getDriver());
        actions.keyDown(Keys.CONTROL).sendKeys(Keys.RETURN).build().perform();
    }
}
