package helper;

import org.testng.Assert;

public class Assertions {
    public void verifyEquels(String actual, String expected, String message){
        try{

            Assert.assertEquals(actual, expected, message);
        }
        catch (AssertionError e){
            System.out.println(e);
        }
    }
}
