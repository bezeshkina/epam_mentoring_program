package webdriverManager;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class WebDriverSingleton {
    private static WebDriver instance;
    private static String DRIVER_PATH = "src/main/resources/chromedriver.exe";
    private static int TIMEOUT_IN_SECONDS = 10;

    private WebDriverSingleton(){}

    public static WebDriver getDriver() {
        if (instance == null){
            instance = initDriver();
        }
        return instance;
    }

    public static WebDriver initDriver(){
        System.setProperty("webdriver.chrome.driver", DRIVER_PATH);
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().pageLoadTimeout(TIMEOUT_IN_SECONDS, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(TIMEOUT_IN_SECONDS, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public static void closeDriver(){
        if (instance != null){
            try {
                instance.quit();
            }
            catch (Exception e){
                System.out.println("Can't close browser!" + e);
            }
            finally {
                instance = null;
            }
        }

    }
}
