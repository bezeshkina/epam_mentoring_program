package pageObjects;

import helper.Clicker;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreateEmailPage extends Page {
    @FindBy(xpath = "//textarea[@aria-label='Кому']")
    protected WebElement addresseeField;

    @FindBy(xpath = "//input[@name='subjectbox']")
    protected WebElement subjectField;

    @FindBy(xpath = "//div[@aria-label='Тело письма']")
    protected WebElement textAreaField;

    @FindBy(xpath = "//img[@data-tooltip='Сохранить и закрыть']")
    protected WebElement closeBtn;

    public CreateEmailPage(){
    }

    public CreateEmailPage fillAddresseeField(String addressee){
        waitForElementAndSendKeys(addresseeField, addressee);
        new Clicker().clickTab();
        return this;
    }

    public CreateEmailPage fillSubjectField(String subject){
        waitForElementAndSendKeys(subjectField, subject);
        new Clicker().clickTab();
        return this;
    }

    public CreateEmailPage fillTextAreaField(String text){
        waitForElementAndSendKeys(textAreaField, text);
        return this;
    }

    public InboxPage closeWindow(){
        waitForElementAndClick(closeBtn);
        return new InboxPage();
    }
}
