package pageObjects;

import helper.Assertions;
import helper.Clicker;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SendingEmailPage extends Page {
    protected Assertions assertions = new Assertions();

    @FindBy(xpath = "//input[@name='subject']")
    protected WebElement subjectText;

    @FindBy(css = ".aoD.hl>div:nth-child(1)>span")
    protected WebElement addresseeText;

    @FindBy(css = ".Ar.Au>div")
    protected WebElement textAreaText;

    public SendingEmailPage verifyAddressee(String expected){
        assertions.verifyEquels(addresseeText.getText(), expected, "Addressee isn't match");
        return this;
    }

    public SendingEmailPage verifySubject(String expected){
        assertions.verifyEquels(subjectText.getAttribute("value"), expected, "Subject isn't match");
        return this;
    }

    public SendingEmailPage verifyText(String expected){
        assertions.verifyEquels(textAreaText.getText(), expected, "Text isn't match");
        return this;
    }

    public DraftsCategory sendEmail(){
        new Clicker().clickCtrlEnter();
        return new DraftsCategory();
    }

}
