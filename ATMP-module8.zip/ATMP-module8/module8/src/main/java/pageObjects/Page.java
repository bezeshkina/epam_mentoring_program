package pageObjects;

import org.openqa.selenium.*;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import ru.yandex.qatools.htmlelements.element.HtmlElement;
import ru.yandex.qatools.htmlelements.loader.HtmlElementLoader;
import webdriverManager.WebDriverSingleton;

public abstract class Page extends HtmlElement {
    private final int DEFAULT_TIMEOUT_IN_SECONDS = 10;
    protected String jsHighlight = "arguments[0].style.border='3px solid red'";
    //protected String jsUnhighlight = "arguments[0].style.border='0px'";
    protected String jsClick = "arguments[0].click();";

    public Page(){
        HtmlElementLoader.populatePageObject(this, WebDriverSingleton.getDriver());
    }

    protected void waitForElementAndClick(WebElement element){
        try {
            new WebDriverWait(WebDriverSingleton.getDriver(), DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).click();
        } catch (StaleElementReferenceException e) {
            new WebDriverWait(WebDriverSingleton.getDriver(), DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).click();
        }
    }

    protected void waitForElementAndSendKeys(WebElement element, String text) {
        try {
            new WebDriverWait(WebDriverSingleton.getDriver(), DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
        } catch (StaleElementReferenceException e) {
            new WebDriverWait(WebDriverSingleton.getDriver(), DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
        }
    }

    protected void waitTitle(String text){
        try {
            new WebDriverWait(WebDriverSingleton.getDriver(), DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.titleIs(text));
        }
        catch (TimeoutException e){
            e.getStackTrace();
        }
    }

    protected void jsAction(WebElement element, String parameter){
        ((JavascriptExecutor)WebDriverSingleton.getDriver()).executeScript(parameter, element);
    }
}
