package pageObjects;

import elements.InboxMenu;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InboxPage extends Page {
    @FindBy(xpath = "//div[text()='Написать']")
    protected WebElement createBtn;

    public InboxPage(){
        waitTitle("Входящие");
    }

    public CreateEmailPage clickCreateBtn(){
        waitForElementAndClick(createBtn);
        return new CreateEmailPage();
    }

    public DraftsCategory goToDrafts(){
        InboxMenu inboxMenu = new InboxMenu();
        inboxMenu.clickToDrafts();
        return new DraftsCategory();
    }
}
