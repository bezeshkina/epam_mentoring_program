package pageObjects;

import elements.AccountMenu;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class DraftsCategory extends Page {
    @FindBy(xpath = "//span[@class='bog']")
    protected List<WebElement> listOfEmails;

    public DraftsCategory(){
        super();
        waitTitle("Черновики");
    }

    public SendingEmailPage findElementOnPageAndClick(String text){
        for (WebElement element : listOfEmails){
            if (element.getText().contains(text)){
                jsAction(element, jsHighlight);
                jsAction(element, jsClick);
                return new SendingEmailPage();
            }
        }
        throw new AssertionError("Email isn't found");
    }

    public DraftsCategory logOut(){
        AccountMenu accountMenu = new AccountMenu();
        accountMenu.logOut();
        return this;
    }
}
