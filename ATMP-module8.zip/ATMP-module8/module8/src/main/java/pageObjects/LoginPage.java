package pageObjects;

import elements.SignIn;
import webdriverManager.WebDriverSingleton;


public class LoginPage extends Page {
    private static final String url = "http://gmail.com";

    public LoginPage() {
        waitTitle("Gmail");
    }

    public LoginPage openPage() {
        WebDriverSingleton.getDriver().get(url);
        return this;
    }

    public static InboxPage signIn(String login, String pwd) {
        SignIn signIn = new SignIn();
        signIn.enterLogin(login);
        signIn.clickSubmitBtn();
        signIn.enterPwd(pwd);
        signIn.clickSubmitBtn();
        return new InboxPage();
    }
}
