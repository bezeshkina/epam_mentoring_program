package elements;

import org.openqa.selenium.support.FindBy;
import pageObjects.Page;
import ru.yandex.qatools.htmlelements.element.Button;

public class AccountMenu extends Page {
    @FindBy(xpath = "//a[@class='gb_b gb_hb gb_R']")
    protected Button accountBtn;

    @FindBy(xpath = "//a[@id='gb_71']")
    protected Button logOutBtn;

    public void logOut(){
        accountBtn.click();
        logOutBtn.click();
    }
}
