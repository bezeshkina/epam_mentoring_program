package elements;

import org.openqa.selenium.support.FindBy;
import pageObjects.Page;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.TextInput;

public class SignIn extends Page {
    @FindBy(xpath = "//input[@type='email']")
    protected TextInput loginField;

    @FindBy(xpath = ".//input[@type='password']")
    protected TextInput passwordField;

    @FindBy(xpath = ".//span[text()='Далее']")
    protected Button submitBtn;

    public void enterLogin(String login) {
        loginField.sendKeys(login);
    }

    public void enterPwd(String pwd) {
        passwordField.sendKeys(pwd);
    }

    public void clickSubmitBtn() {
        submitBtn.click();
    }
}
