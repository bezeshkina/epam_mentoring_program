package elements;

import org.openqa.selenium.support.FindBy;
import pageObjects.Page;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Link;

@Name("Inbox menu")
@FindBy(xpath = "//div[@class='byl']")
public class InboxMenu extends Page {
    @FindBy(xpath = ".//a[@title='Черновики']")
    protected Link draftsCategory;

    @FindBy(css = ".TN.bzz.aHS-bnu>div:nth-child(2)>span>a")
    protected Link outboxCategory;

    public void clickToDrafts(){
        draftsCategory.click();
    }
}
