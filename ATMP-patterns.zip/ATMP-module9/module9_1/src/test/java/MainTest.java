import businessObjects.EmailData;
import businessObjects.UserData;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjects.*;
import webdriverManager.WebDriverDecorator;
import webdriverManager.WebDriverSingleton;

public class MainTest {
    private String login = new UserData().getLogin();
    private String password = new UserData().getPassword();
    private String addressee = new EmailData().getAddressee();
    private String subject = new EmailData().getSubject();
    private String textArea = new EmailData().getTextArea();

    @BeforeTest(description = "precondition: Authorization")
    public void logIn() {
        new LoginPage().openPage().fillLoginFieldAndClick(login).fillPasswordField(password);
    }

    @Test
    public void testAction() throws InterruptedException {
        new InboxPage().clickCreateBtn();
        new CreateEmailPage().createDraft().closeWindow();
        new InboxPage().goToDrafts();
        new DraftsCategory().findElementOnPageAndClick(subject);
        new SendingEmailPage().verifyAddressee(addressee).verifySubject(subject).verifyText(textArea).sendEmail();
        new DraftsCategory().logOut();
    }

    @AfterTest(description = "close browser")
    public void closeBrowser() {
        new WebDriverDecorator(WebDriverSingleton.getInstance()).quit();
    }
}
