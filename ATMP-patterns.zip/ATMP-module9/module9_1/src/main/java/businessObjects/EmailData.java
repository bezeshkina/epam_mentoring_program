package businessObjects;

public class EmailData {
    private String addressee = "atmptest@yandex.ru";
    private String subject = "new subject";
    private String textArea = "test test text";

    public String getAddressee(){
        return addressee;
    }

    public String getSubject(){
        return subject;
    }

    public String getTextArea(){
        return textArea;
    }
}
