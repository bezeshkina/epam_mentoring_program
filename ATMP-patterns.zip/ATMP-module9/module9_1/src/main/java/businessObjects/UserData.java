package businessObjects;

public class UserData {
    private String login = "atmpmailbox@gmail.com";
    private String password = "QwertyYtrewq123";

    public String getLogin(){
        return login;
    }

    public String getPassword(){
        return password;
    }
}
