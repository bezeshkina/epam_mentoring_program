package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class DraftsCategory extends Page {
    @FindBy(xpath = "//a[@class='gb_b gb_hb gb_R']")
    private WebElement accountBtn;

    @FindBy(xpath = "//a[@id='gb_71']")
    private WebElement logOutBtn;

    @FindBy(xpath = "//span[@class='bog']")
    private List<WebElement> listOfEmails;

    public DraftsCategory(){
        super();
        waitTitle("Черновики");
    }

    public SendingEmailPage findElementOnPageAndClick(String text){
        for (WebElement element : listOfEmails){
            if (element.getText().contains(text)){
                clickToElement(element);
                return new SendingEmailPage();
            }
        }
        throw new AssertionError("Email isn't found");
    }

    public DraftsCategory logOut() {
        clickToElement(accountBtn);
        clickToElement(logOutBtn);
        return this;
    }
}
