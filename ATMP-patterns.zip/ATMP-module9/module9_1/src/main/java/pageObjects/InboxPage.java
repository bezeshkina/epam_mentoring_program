package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InboxPage extends Page{
    @FindBy(xpath = "//div[text()='Написать']")
    private WebElement createBtn;

    @FindBy(xpath = "//a[@title='Черновики']")
    private WebElement draftsCategory;

    public InboxPage() {
        super();
        waitTitle("Входящие");
    }

    public CreateEmailPage clickCreateBtn() {
        clickToElement(createBtn);
        return new CreateEmailPage();
    }

    public DraftsCategory goToDrafts(){
        clickToElement(draftsCategory);
        return new DraftsCategory();
    }
}
