package pageObjects;

import helper.Assertions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SendingEmailPage extends Page{
    private Assertions assertions = new Assertions();

    @FindBy(xpath = "//input[@name='subject']")
    private WebElement subjectText;

    @FindBy(css = ".aoD.hl>div:nth-child(1)>span")
    private WebElement addresseeText;

    @FindBy(css = ".Ar.Au>div")
    private WebElement textAreaText;

    @FindBy(css = ".gU.Up>div>div:nth-child(2)")
    private WebElement sendBtn;

    public SendingEmailPage(){
    }

    public DraftsCategory sendEmail(){
        clickToElement(sendBtn);
        return new DraftsCategory();
    }

    public SendingEmailPage verifyAddressee(String expected){
        assertions.verifyEquels(addresseeText.getText(), expected, "Addressee isn't match");
        return this;
    }

    public SendingEmailPage verifySubject(String expected){
        assertions.verifyEquels(subjectText.getAttribute("value"), expected, "Subject isn't match");
        return this;
    }

    public SendingEmailPage verifyText(String expected){
        assertions.verifyEquels(textAreaText.getText(), expected, "Text isn't match");
        return this;
    }

}
