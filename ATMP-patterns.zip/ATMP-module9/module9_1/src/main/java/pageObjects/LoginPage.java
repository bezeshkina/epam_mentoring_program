package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends Page {
    private static final String url = "http://gmail.com";

    @FindBy(xpath = "//input[@id='identifierId']")
    private WebElement loginField;

    @FindBy(xpath = "//input[@type='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//span[text()='Далее']")
    private WebElement submitBtn;

    public LoginPage() {
    }

    public LoginPage openPage(){
        openPage(url);
        return this;
    }

    public LoginPage fillLoginFieldAndClick(String login){
        sendKeys(loginField, login);
        clickToElement(submitBtn);
        return this;
    }

    public InboxPage fillPasswordField(String pwd){
        sendKeys(passwordField, pwd);
        clickToElement(submitBtn);
        return new InboxPage();
    }
}
