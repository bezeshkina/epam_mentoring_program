package pageObjects;

import factory.Email;
import factory.EmailWithAttachmentFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreateEmailPage extends Page {
    @FindBy(xpath = "//textarea[@aria-label='Кому']")
    private WebElement addresseeField;

    @FindBy(xpath = "//input[@name='subjectbox']")
    private WebElement subjectField;

    @FindBy(xpath = "//div[@aria-label='Тело письма']")
    private WebElement textAreaField;

    @FindBy(xpath = "//img[@data-tooltip='Сохранить и закрыть']")
    private WebElement closeBtn;

    @FindBy(xpath = "//input[@type='file']")
    private WebElement attachTheFile;

    public CreateEmailPage(){
        super();
    }

    public CreateEmailPage createDraft() {
        Email email = new EmailWithAttachmentFactory().createEmail();
        email.enterAddressee(addresseeField);
        email.enterSubject(subjectField);
        email.enterText(textAreaField);
        email.uploadAttachment(attachTheFile);
        return new CreateEmailPage();
    }

    public InboxPage closeWindow(){
        clickToElement(closeBtn);
        return new InboxPage();
    }
}
