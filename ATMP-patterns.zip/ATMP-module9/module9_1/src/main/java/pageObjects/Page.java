package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import helper.WaitSomeElement;
import webdriverManager.WebDriverSingleton;

public abstract class Page {
    private WebDriver driver = WebDriverSingleton.getInstance();
    private WaitSomeElement wait = new WaitSomeElement(driver);

    public Page(){
        PageFactory.initElements(driver, this);
    }

    protected void openPage(String url){
        driver.get(url);
    }

    protected void waitTitle(String title){
        wait.waitTitleContains(title);
    }

    protected void clickToElement(WebElement element){
        wait.waitWebElement(element).click();
    }

    protected void sendKeys(WebElement element, String s){
        wait.waitWebElement(element).sendKeys(s);
    }






}
