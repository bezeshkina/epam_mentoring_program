package helper;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import webdriverManager.WebDriverDecorator;

public class WaitSomeElement extends WebDriverDecorator {
    public WaitSomeElement(WebDriver driver) {
        super(driver);
    }

    public WebElement waitElementIsLocatedBy(By by){
        return super.waitForElement().until(ExpectedConditions.elementToBeClickable(by));
    }

    public WebElement waitWebElement(WebElement element){
        return super.waitForElement().until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitTitleContains(String s){
        super.waitForElement().until(ExpectedConditions.titleContains(s));
    }
}
