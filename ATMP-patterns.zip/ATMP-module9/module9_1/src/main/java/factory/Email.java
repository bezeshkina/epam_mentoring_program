package factory;

import org.openqa.selenium.WebElement;

public interface Email {
    void enterAddressee(WebElement element);
    void enterSubject(WebElement element);
    void enterText(WebElement element);
    void uploadAttachment(WebElement element);

}
