package factory;

public class EWSFactory implements EmailFactory{
    public Email createEmail() {
        return new EmailWithoutSubject();
    }
}
