package factory;

import businessObjects.EmailData;
import org.openqa.selenium.WebElement;

import java.io.File;

public class EmailWithAttachment implements Email {
    private String filePath = "src/main/resources/data/Blood-dripping-1467657378.gif";

    public void enterAddressee(WebElement element) {
        element.sendKeys(new EmailData().getAddressee());
    }

    public void enterSubject(WebElement element) {
        element.sendKeys(new EmailData().getSubject());
    }

    public void enterText(WebElement element) {
        element.sendKeys(new EmailData().getTextArea());
    }

    public void uploadAttachment(WebElement element) {
        element.sendKeys(new File(filePath).getAbsolutePath());
    }
}
