package factory;

import businessObjects.EmailData;
import org.openqa.selenium.WebElement;

public class EmailWithoutAttachments implements Email {
    public void enterAddressee(WebElement element) {
        element.sendKeys(new EmailData().getAddressee());
    }

    public void enterSubject(WebElement element) {
        element.sendKeys(new EmailData().getSubject());
    }

    public void enterText(WebElement element) {
        element.sendKeys(new EmailData().getTextArea());
    }

    public void uploadAttachment(WebElement element) {
    }
}
