package factory;

public class EWAFactory implements EmailFactory {
    public Email createEmail() {
        return new EmailWithoutAttachments();
    }
}
