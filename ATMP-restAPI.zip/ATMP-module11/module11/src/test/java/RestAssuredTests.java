import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import models.User;

public class RestAssuredTests {
    private String uri = "https://jsonplaceholder.typicode.com";
    private Response response;

    @BeforeTest
    public void init(){
        RestAssured.baseURI = uri;
    }

    @Test
    public void verifyStatusCode(){
        response = RestAssured.when()
                .get("/users")
                .andReturn();
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    @Test
    public void verifyResponseHeader(){
        response = RestAssured.when()
                .get("/users")
                .andReturn();
        String responseHeader = response.getHeader("Content-Type");
        Assert.assertNotNull(responseHeader, "There is no header Content-Type");
        Assert.assertEquals(responseHeader, "application/json; charset=utf-8");
    }

    @Test
    public void verifyResponseBody(){
        response = RestAssured.when()
                .get("/users")
                .andReturn();
        ResponseBody<?> responseBody = response.getBody();
        User[] users = responseBody.as(User[].class);
        Assert.assertEquals(users.length, 10);
    }
}
