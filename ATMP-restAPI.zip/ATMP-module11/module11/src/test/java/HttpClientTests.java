import com.google.gson.GsonBuilder;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import models.User;

import java.io.IOException;

public class HttpClientTests {
    private String uri = "https://jsonplaceholder.typicode.com/users";
    private HttpUriRequest request;
    private HttpResponse response;

    @BeforeTest
    public void init() throws IOException {
        request = new HttpGet(uri);
        response = HttpClientBuilder.create().build().execute(request);
    }

    @Test
    public void verifyStatusCode() {
        Assert.assertEquals(response.getStatusLine().getStatusCode(), 200);
    }

    @Test
    public void verifyResponseHeader(){
        Header[] headers = response.getHeaders("Content-Type");
        Assert.assertNotNull(headers, "There is no header Content-Type");
        Assert.assertEquals(headers[0].getValue(), "application/json; charset=utf-8");
    }

    @Test
    public void verifyResponseBody() throws IOException {
        ResponseHandler<String> responseHandler = new BasicResponseHandler();
        String responseBody = HttpClientBuilder.create().build().execute(request, responseHandler);
        User[] users = new GsonBuilder().create().fromJson(responseBody, User[].class);
        Assert.assertEquals(users.length, 10);
    }
}
