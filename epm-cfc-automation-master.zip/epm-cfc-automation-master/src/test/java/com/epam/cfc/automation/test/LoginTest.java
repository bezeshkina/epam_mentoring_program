package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.entity.Services;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test(description = "Login test", dataProvider = "getService", dataProviderClass = DataProviderSource.class)
    public void loginViaService(Services service) {
        startPage.openLoginPopupWindow().openServicePage(service);
        loginService.login(service, userDataEntry);
        LoggerUtil.LOGGER.info("Asserting that title is 'Carbon Footprint Calculator'");
        Assert.assertEquals(startPage.getTitle(), "Carbon Footprint Calculator", "User doesn't signed in in " + service.toString());
    }

    @AfterMethod
    public void logOut() {
        startPage.logout();
    }
}
