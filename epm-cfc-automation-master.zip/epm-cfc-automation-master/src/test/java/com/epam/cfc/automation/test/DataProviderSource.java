package com.epam.cfc.automation.test;

import org.testng.annotations.DataProvider;

import static com.epam.cfc.automation.framework.common.entity.Services.*;

public class DataProviderSource {
    @DataProvider
    public Object[][] getService() {
        return new Object[][]{
                {facebook},
                {vk},
                {twitter},
                {google},
                {email},
                {linkedIn},
                {github}
        };
    }

}
