package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.common.page.quiz.*;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;
import com.epam.cfc.automation.framework.config.data.UserDataReader;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.LogIn;
import com.epam.cfc.automation.test.listener.TestListener;
import com.epam.reportportal.testng.ReportPortalTestNGListener;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;

@Listeners({TestListener.class, ReportPortalTestNGListener.class})
public abstract class BaseTest {

    static UserDataEntry userDataEntry = UserDataReader.getUserData();

    StartPage startPage = new StartPage();
    LogIn loginService = new LogIn();
    TransportPage transportPage = new TransportPage();
    FuelPage fuelPage = new FuelPage();
    TimeOfJourneyPage timeOfJourneyPage = new TimeOfJourneyPage();
    FoodPage foodPage = new FoodPage();
    PetsPage petsPage = new PetsPage();
    ElectricityPage electricityPage = new ElectricityPage();
    QuizResultPage quizResultPage = new QuizResultPage();

    @BeforeSuite(alwaysRun = true)
    public void open() {
        startPage.open();
    }

    @AfterSuite(description = "Browser is quited after suite", alwaysRun = true)
    public void quitBrowser() {
        LoggerUtil.LOGGER.info("WebDriver quits after suite");
        DriverFactory.driverQuit();
    }
}
