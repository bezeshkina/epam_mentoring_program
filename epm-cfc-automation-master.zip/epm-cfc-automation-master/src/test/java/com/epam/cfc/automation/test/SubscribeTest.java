package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.entity.Services;
import com.epam.cfc.automation.framework.config.data.DatabaseConfigurationReader;
import com.epam.cfc.automation.framework.config.data.EmailConfigurationReader;
import com.epam.cfc.automation.framework.config.database.DBConnection;
import com.epam.cfc.automation.framework.config.mail.EmailNotification;
import com.epam.cfc.automation.framework.config.mail.EmailNotificationService;
import com.epam.cfc.automation.framework.config.mail.EmailNotificationSpec;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.testng.Assert;
import org.testng.annotations.*;

import static com.epam.cfc.automation.framework.config.mail.EmailNotificationSpecFactory.createSubscribeSpec;
import static com.epam.cfc.automation.framework.config.mail.EmailNotificationSpecFactory.createUnsubscribeSpec;
import static com.epam.cfc.automation.framework.config.mail.EmailNotificationSubject.USER_SUBSCRIBED;
import static com.epam.cfc.automation.framework.config.mail.EmailNotificationSubject.USER_UNSUBSCRIBED;
import static com.epam.cfc.automation.framework.core.util.CfcSoftAssertions.softlyAssert;

public class SubscribeTest extends BaseTest {

    private EmailNotificationService notificationService;

    @BeforeTest
    public void clearInbox() {
        EmailNotificationService emailNotificationService = new EmailNotificationService(EmailConfigurationReader.getEmailConfiguration());
        emailNotificationService.clearInbox();
        emailNotificationService.close();
    }

    @BeforeClass
    public void prepareTestData() {
        notificationService = new EmailNotificationService(EmailConfigurationReader.getEmailConfiguration());
    }

    @Parameters({"mService"})
    @Test(description = "Test for checking that user can subscribe to receiving notifications")
    public void subscribeTest(Services service) {
        DBConnection dbConnection = new DBConnection(DatabaseConfigurationReader.getDatabaseConfiguration());
        dbConnection.removeUserConnection(service);
        startPage
                .openLoginPopupWindow()
                .openServicePage(service);
        loginService.login(service, userDataEntry);
        startPage.start();
        transportPage
                .tickByBike()
                .goToNextQuestion();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickNext();
        electricityPage
                .setElectricityRange(520)
                .calculate();
        quizResultPage
                .clickSubscribe()
                .fillEmailField(EmailConfigurationReader.getEmailConfiguration().getLogin())
                .confirm();
        LoggerUtil.info("Asserting that the button changes it's title to 'Unsubscribe'");
        Assert.assertTrue(quizResultPage.isButtonChangesToUnsubscribe());
    }

    @Test(description = "Test for checking that user can unsubscribe", dependsOnMethods = "subscribeTest", priority = 1)
    public void unsubscribeTest() {
        quizResultPage
                .clickUnsubscribe()
                .confirm();
        LoggerUtil.info("Asserting that the button changes it's title to 'Subscribe'");
        Assert.assertTrue(quizResultPage.isButtonChangesToSubscribe());
    }

    @Test(description = "Check that a notification for subscribers was received", dependsOnMethods = "subscribeTest", priority = 2)
    public void checkEmailForSubscribers() {
        //Arrange
        EmailNotificationSpec specForSubscribers = createSubscribeSpec(USER_SUBSCRIBED);
        //Act
        EmailNotification srCreationNotification = notificationService.findNotificationBySpec(specForSubscribers);
        //Assert
        softlyAssert(softly -> softly.assertThat(srCreationNotification).subjectContains(specForSubscribers.getSubject())
                .contentContains(specForSubscribers.getExpectedContent()));
    }

    @Test(description = "Check that a notification for unsubscribers was received", dependsOnMethods = "unsubscribeTest", priority = 3)
    public void checkEmailForUnsubscribers() {
        //Arrange
        EmailNotificationSpec specForUnsubscribers = createUnsubscribeSpec(USER_UNSUBSCRIBED);
        //Act
        EmailNotification srCreationNotification = notificationService.findNotificationBySpec(specForUnsubscribers);
        //Assert
        softlyAssert(softly -> softly.assertThat(srCreationNotification).subjectContains(specForUnsubscribers.getSubject())
                .contentContains(specForUnsubscribers.getExpectedContent()));
    }

    @AfterTest(description = "Log out after test")
    public void logOut() {
        LoggerUtil.info("Logging out after test");
        startPage.logout();
    }

    @AfterSuite(alwaysRun = true)
    public void closeEmailNotificationService() {
        notificationService.close();
    }
}
