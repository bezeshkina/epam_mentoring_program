package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.entity.Services;
import com.epam.cfc.automation.framework.config.data.DatabaseConfigurationReader;
import com.epam.cfc.automation.framework.config.database.DBConnection;
import org.testng.Assert;
import org.testng.annotations.*;

public class QuizTest extends BaseTest {

    @Parameters({"mService"})
    @BeforeClass
    public void logIn(Services service) {
        startPage.openLoginPopupWindow().openServicePage(service);
        loginService.login(service, userDataEntry);
        startPage.logout();
    }

    @Parameters({"mService"})
    @BeforeMethod
    public void chooseService(Services service) {
        DBConnection dbConnection = new DBConnection(DatabaseConfigurationReader.getDatabaseConfiguration());
        dbConnection.removeUserConnection(service);
        startPage.openLoginPopupWindow().chooseService(service);
    }

    @Test(description = "Test with parameters: On foot, by bus, vegan, 2 dogs, 150 kWh")
    public void quizTest1() {
        startPage.start();
        transportPage
                .tickOnFoot()
                .tickByBike()
                .goToNextQuestion();
        foodPage
                .chooseVegan()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setDogsCount(10)
                .clickNext();
        electricityPage
                .setElectricityRange(150)
                .calculate();
        Assert.assertTrue(quizResultPage.resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "Test with parameters: By bike, by car, diesel, vegetarian, 1 cat, 250 kWh")
    public void quizTest2() {
        startPage.start();
        transportPage
                .tickByBike()
                .tickByCar()
                .goToNextQuestion();
        fuelPage
                .setHybrid()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(35)
                .clickNext();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setCatsCount(1)
                .clickNext();
        electricityPage
                .setElectricityRange(910)
                .calculate();
        Assert.assertTrue(quizResultPage.resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "Test with parameters: By car, on foot, gasoline, balanced, all pets, 320 kWh")
    public void quizTest3() {
        startPage.start();
        transportPage
                .tickByCar()
                .tickOnFoot()
                .goToNextQuestion();
        fuelPage
                .setGasoline()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(50)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickOtherSection()
                .setSnakesAndSpidersCount(5)
                .setDogsCount(9)
                .setCatsCount(1)
                .setRodentCount(8)
                .setAquariumFishCount(9)
                .setParrotsCount(3)
                .setRabbitsCount(2)
                .setLizardsCount(1)
                .clickNext();
        electricityPage
                .setElectricityRange(320)
                .calculate();
        Assert.assertTrue(quizResultPage.resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "Test with parameters: On foot, by subway, balanced, 4 rodents, 130 kWh")
    public void quizTest4() {
        startPage.start();
        transportPage
                .tickByBus()
                .tickBySubway()
                .tickByTrain()
                .tickOnFoot()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(10)
                .setTimeOfTrainJourney(120)
                .setTimeOfSubwayJourney(70)
                .clickNext();
        foodPage
                .chooseFastFood()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setRodentCount(4)
                .clickOtherSection()
                .setAquariumFishCount(9)
                .clickNext();
        electricityPage
                .setElectricityRange(630)
                .calculate();
        Assert.assertTrue(quizResultPage.resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "Test with parameters: By bike, vegetarian, 3 cats, 2 dogs, 520 kWh")
    public void quizTest5() {
        startPage.start();
        transportPage
                .tickByCar()
                .tickOnFoot()
                .tickByTrain()
                .tickBySubway()
                .tickByBus()
                .goToNextQuestion();
        fuelPage
                .setDiesel()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(10)
                .setTimeOfTrainJourney(120)
                .setTimeOfSubwayJourney(60)
                .setTimeOfBusJourney(45)
                .clickNext();
        foodPage
                .chooseVegan()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setCatsCount(0)
                .setDogsCount(9)
                .clickNext();
        electricityPage
                .setElectricityRange(90)
                .calculate();
        Assert.assertTrue(quizResultPage.resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "Test with parameters: By car, gasoline, vegan, 7 fishes, 440 kWh")
    public void quizTest6() {
        startPage.start();
        transportPage
                .tickByCar()
                .tickByBus()
                .goToNextQuestion();
        fuelPage
                .setGasoline()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(15)
                .setTimeOfBusJourney(50)
                .clickNext();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickOtherSection()
                .setAquariumFishCount(7)
                .clickNext();
        electricityPage
                .setElectricityRange(440)
                .calculate();
        Assert.assertTrue(quizResultPage.resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "Test with parameters: by foot, fast food, 5 dogs, 720 kWh")
    public void quizTest7() {
        startPage.start();
        transportPage
                .tickOnFoot()
                .goToNextQuestion();
        foodPage
                .chooseFastFood()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setDogsCount(5)
                .clickNext();
        electricityPage
                .setElectricityRange(720)
                .calculate();
        Assert.assertTrue(quizResultPage.resultIsPresented(), "Results isn't presented");
    }


    //---- couldn't found test cases. Have to write their
    @Test(description = "Open quiz by calculate button")
    public void calculateButtonTest() {
        startPage.scrollToGlobePage();
        startPage.clickToCalculate();
        Assert.assertTrue(transportPage.quizIsOpened(), "Quiz isn't opened");
    }

    @Test(description = "Start button is enabled after quiz skipping")
    public void startButtonAvailabilityTest() {
        startPage.start();
        transportPage
                .tickByCar()
                .tickByBus()
                .goToNextQuestion();
        fuelPage
                .setGasoline()
                .clickNext();
        timeOfJourneyPage
                .goToHomePage();
        Assert.assertTrue(startPage.startButtonIsEnabled(), "Start button isn't enabled");
    }


    //----- test cases for Back and Next button
    @Test(description = "EPMCFC-5603: Test of functional buttons (Next, Back) on Transport page")
    public void backButtonTestOnTransportPage() {
        startPage.start();
        transportPage
                .clickBack();
        startPage.start();
        transportPage
                .checkThatNextBtnDisabled();
        transportPage
                .tickByCar()
                .goToNextQuestion();
        Assert.assertTrue(fuelPage.fuelPageIsLoaded(), "Fuel page isn't loaded");
    }

    @Test(description = "EPMCFC-5608: Test of functional buttons (Next, Back) on Fuel page")
    public void backButtonTestOnFuelPage() {
        startPage.start();
        transportPage
                .tickByCar()
                .goToNextQuestion();
        fuelPage
                .clickBack();
        transportPage
                .clickNext();
        fuelPage
                .checkThatNextBtnDisabled();
        fuelPage
                .setGasoline()
                .clickNext();
        Assert.assertTrue(timeOfJourneyPage.timePageIsLoaded(), "Time page isn't loaded");
    }


    @Test(description = "EPMCFC-5611: Test of functional buttons (Next, Back) on Time page")
    public void backButtonTestOnTimePage() {
        startPage.start();
        transportPage
                .tickByBus()
                .goToNextQuestion();
        timeOfJourneyPage
                .clickBack();
        transportPage
                .clickNext();
        timeOfJourneyPage
                .setTimeOfBusJourney(60)
                .clickNext();
        Assert.assertTrue(foodPage.foodPageIsLoaded(), "Food page isn't loaded");
    }

    @Test(description = "EPMCFC-5616: Test of functional buttons (Next, Back) on Food page")
    public void backButtonTestOnFoodPage() {
        startPage.start();
        transportPage
                .tickByBus()
                .tickOnFoot()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(150)
                .clickNext();
        foodPage
                .clickBack();
        transportPage
                .clickNext();
        foodPage
                .checkThatNextBtnDisabled();
        foodPage
                .chooseBalanced()
                .clickNext();
        Assert.assertTrue(petsPage.petsPageIsLoaded(), "Food page isn't loaded");
    }

    @Test(description = "EPMCFC-5619: Test of functional buttons (Next, Back) on Pets page")
    public void backButtonTestOnPetsPage() {
        startPage.start();
        transportPage
                .tickByBus()
                .tickOnFoot()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(150)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .clickBack();
        foodPage
                .clickNext();
        petsPage
                .clickNext();
        Assert.assertTrue(electricityPage.electricityPageIsLoaded(), "Electricity page isn't loaded");
    }

    @Test(description = "EPMCFC-5616: Test of functional buttons (Next, Back) on Electricity page")
    public void backButtonTestOnElectricityPage() {
        startPage.start();
        transportPage
                .tickByBus()
                .tickOnFoot()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(150)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .clickNext();
        electricityPage
                .clickBack();
        petsPage
                .clickNext();
        electricityPage
                .setElectricityRange(0);
        Assert.assertTrue(electricityPage.calculateBtnDisabled(), "Calculate button enabled although electricity equals 0");
    }

    @AfterMethod
    public void logOut() {
        startPage.logout();
    }
}
