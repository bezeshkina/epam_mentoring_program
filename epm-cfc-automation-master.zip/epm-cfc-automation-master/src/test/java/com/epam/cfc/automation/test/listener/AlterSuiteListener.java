package com.epam.cfc.automation.test.listener;

import org.testng.IAlterSuiteListener;
import org.testng.xml.XmlSuite;

import java.util.List;

public class AlterSuiteListener implements IAlterSuiteListener {

    @Override
    public void alter(List<XmlSuite> suites) {
        suites.forEach(suite -> {
            suite.setPreserveOrder(true);
            suite.setGroupByInstances(true);
        });
    }
}
