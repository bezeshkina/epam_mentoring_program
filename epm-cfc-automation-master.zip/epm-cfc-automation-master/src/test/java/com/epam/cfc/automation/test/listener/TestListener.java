package com.epam.cfc.automation.test.listener;

import com.epam.cfc.automation.framework.core.util.Screenshots;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.testng.*;

public class TestListener implements IInvokedMethodListener {

    private static final String DELIMITER = "=========================================================================";

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult result) {
        if (method.isTestMethod()) {
            LoggerUtil.info(DELIMITER);
            LoggerUtil.info("%s", "Start executing");
            LoggerUtil.info("Description: %s", method.getTestMethod().getDescription());
            LoggerUtil.info(DELIMITER);
        }
    }

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult result) {
        if (result.isSuccess() && method.isTestMethod()) {
            LoggerUtil.info(DELIMITER);
            LoggerUtil.info("%s", "Finish executing");
            LoggerUtil.info(DELIMITER);
        } else if (!result.isSuccess()) {
            LoggerUtil.info(DELIMITER);
            Screenshots.takeScreenshot(result.getName(), String.format("%s failed", result.getName()));
            LoggerUtil.info(DELIMITER);
        }
    }
}
