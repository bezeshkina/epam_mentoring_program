package com.epam.cfc.automation.framework.core.util.services;

import com.epam.cfc.automation.framework.common.page.BasePage;
import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;

public abstract class ServicePage extends BasePage {

    public abstract ServicePage fillLogin(User user);

    public abstract ServicePage fillPassword(User user);
    public abstract StartPage submit();
}
