package com.epam.cfc.automation.framework.core.util.factory;

import com.epam.cfc.automation.framework.common.page.authorization.TwitterLoginPage;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;

public class TwitterLoginFactory implements Login {

    @Override
    public void logInService(UserDataEntry userDataEntry) {
        new TwitterLoginPage()
                .fillLogin(userDataEntry.getTwitterUser())
                .fillPassword(userDataEntry.getTwitterUser())
                .submit();
    }
}
