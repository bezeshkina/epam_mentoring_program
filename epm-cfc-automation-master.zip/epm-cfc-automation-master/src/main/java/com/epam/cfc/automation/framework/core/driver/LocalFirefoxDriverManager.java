package com.epam.cfc.automation.framework.core.driver;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.openqa.selenium.firefox.GeckoDriverService.GECKO_DRIVER_EXE_PROPERTY;

public class LocalFirefoxDriverManager extends DriverManager {

    @Override
    protected WebDriver createDriver() {
        System.setProperty(GECKO_DRIVER_EXE_PROPERTY, "webdriver/geckodriver.exe");
        LoggerUtil.LOGGER.info("Mozilla Firefox browser starts up");
        driver = new FirefoxDriver();
        return driver;
    }

}
