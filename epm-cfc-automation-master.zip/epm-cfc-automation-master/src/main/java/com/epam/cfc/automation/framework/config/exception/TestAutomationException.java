package com.epam.cfc.automation.framework.config.exception;

public class TestAutomationException extends RuntimeException {

    public TestAutomationException(String message) {
        super(message);
    }

    public TestAutomationException(Throwable cause) {
        super(cause);
    }
}
