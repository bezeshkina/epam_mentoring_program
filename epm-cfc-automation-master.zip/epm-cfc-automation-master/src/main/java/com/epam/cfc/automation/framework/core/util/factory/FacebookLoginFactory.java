package com.epam.cfc.automation.framework.core.util.factory;

import com.epam.cfc.automation.framework.common.page.authorization.FacebookLoginPage;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;

public class FacebookLoginFactory implements Login {

    @Override
    public void logInService(UserDataEntry userDataEntry) {
        new FacebookLoginPage()
                .fillLogin(userDataEntry.getFacebookUser())
                .fillPassword(userDataEntry.getFacebookUser())
                .submit();
    }
}
