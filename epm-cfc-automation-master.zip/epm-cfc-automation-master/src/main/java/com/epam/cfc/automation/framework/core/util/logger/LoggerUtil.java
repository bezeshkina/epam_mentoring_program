package com.epam.cfc.automation.framework.core.util.logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

public class LoggerUtil {

    public static final Logger LOGGER = LogManager.getLogger(LoggerUtil.class);

    private LoggerUtil(){
    }

    public static void info(String stepMessage, Object... parameters) {
        String message = String.format(stepMessage, parameters);
        LOGGER.info(message);
    }

    public static void error(String errorStepMessage, Object... parameters) {
        String message = String.format(errorStepMessage, parameters);
        LOGGER.error(message);
    }

    public static void log(File file, String message) {
        LOGGER.info("RP_MESSAGE#FILE#{}#{}", file.getAbsolutePath(), message);
    }
}
