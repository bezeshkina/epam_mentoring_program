package com.epam.cfc.automation.framework.config.mail;

public class EmailConfiguration {

    private String login;
    private String password;
    private String host;
    private String port;
    private String protocol;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHost() {
        return host;
    }

    public String getPort() {
        return port;
    }

    public String getProtocol() {
        return protocol;
    }
}
