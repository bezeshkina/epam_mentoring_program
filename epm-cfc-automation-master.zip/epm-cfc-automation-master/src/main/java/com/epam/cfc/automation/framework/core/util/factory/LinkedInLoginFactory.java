package com.epam.cfc.automation.framework.core.util.factory;

import com.epam.cfc.automation.framework.common.page.authorization.LinkedInLoginPage;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;

public class LinkedInLoginFactory implements Login {

    @Override
    public void logInService(UserDataEntry userDataEntry) {
        new LinkedInLoginPage()
                .fillLogin(userDataEntry.getLinkedInUser())
                .fillPassword(userDataEntry.getLinkedInUser())
                .submit();
    }
}
