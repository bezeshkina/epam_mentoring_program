package com.epam.cfc.automation.framework.config.mail;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.jsoup.Jsoup;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import javax.mail.*;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

public class EmailNotificationService {

    private Session session;
    private Store store;
    private Folder inbox;
    private String host;
    private String login;
    private String password;
    private String protocol;

    public EmailNotificationService(EmailConfiguration emailConfiguration) {
        this.host = emailConfiguration.getHost();
        this.login = emailConfiguration.getLogin();
        this.password = emailConfiguration.getPassword();
        this.protocol = emailConfiguration.getProtocol();
        Properties properties = new Properties();
        properties.put("mail.store.protocol", protocol);
        properties.setProperty("smtp.office365.com", host);
        properties.setProperty("mail.smtp.port", emailConfiguration.getPort());
        session = Session.getInstance(properties, null);
        connectToStore();
    }

    public EmailNotification findNotificationBySpec(EmailNotificationSpec specification) {
        openInboxIfNeeded();
        EmailNotification notification;
        try {
            Wait<EmailNotificationSpec> wait = new FluentWait<>(specification)
                    .pollingEvery(Duration.ofSeconds(2))
                    .withTimeout(Duration.ofSeconds(Long.parseLong(System.getProperty("cfc.notificationSearchTimeout", "30"))))
                    .ignoring(MessagingException.class);
            notification = wait.until(this::getNotificationBySpec);
        } catch (TimeoutException e) {
            LoggerUtil.error("A notification with the '%s' subject wasn't found, returning an empty notification", specification.getSubject());
            notification = new EmailNotification("Notification not found", "None");
        }
        return notification;
    }

    public void clearInbox() {
        openInboxIfNeeded();
        LoggerUtil.info("Clearing the '%s' inbox", login);
        try {
            for (Message message : inbox.getMessages()) {
                LoggerUtil.info("Deleting the '%s' message", message.getSubject());
                message.setFlag(Flags.Flag.DELETED, true);
            }
        } catch (MessagingException e) {
            LoggerUtil.error("The inbox '%s' wasn't cleared %s", login, e);
        }
    }

    public void close() {
        closeInbox();
        closeStore();
    }

    private void openInboxIfNeeded() {
        try {
            LoggerUtil.info("Opening the '%s' inbox", login);
            if (inbox == null) {
                inbox = store.getFolder("INBOX");
            }
            if (!inbox.isOpen()) {
                inbox.open(Folder.READ_WRITE);
            }
        } catch (MessagingException e) {
            LoggerUtil.error("The inbox '%s' wasn't opened %s", login, e);
        }
    }

    private void closeInbox() {
        if (inbox != null && inbox.isOpen()) {
            LoggerUtil.info("Closing the '%s' inbox", login);
            try {
                inbox.close(true);
            } catch (MessagingException e) {
                LoggerUtil.error("The inbox '%s' wasn't closed %s", login, e);
            }
        }
    }

    private void connectToStore() {
        try {
            LoggerUtil.info("Connecting to the store of '%s'", login);
            store = session.getStore(protocol);
            if (!store.isConnected()) {
                store.connect(host, login, password);
            }
        } catch (MessagingException e) {
            LoggerUtil.error("Connection to the store of '%s' wasn't established", login, e);
        }
    }

    private void closeStore() {
        if (store.isConnected()) {
            try {
                LoggerUtil.info("Closing the store of the '%s' inbox", login);
                store.close();
            } catch (MessagingException e) {
                LoggerUtil.error("The store of the inbox '%s' wasn't closed %s", login, e);
            }
        }
    }

    private EmailNotification getNotificationBySpec(EmailNotificationSpec spec) {
        LoggerUtil.info("Searching for a notification by its title '%s' through: ", spec.getSubject());
        try {
            for (Message message : inbox.getMessages()) {
                String subject = message.getSubject();
                LoggerUtil.info(subject);
                if (subject.toLowerCase().contains(spec.getSubject().toLowerCase())) {
                    String messageContent = getMessageContent(message);
                    boolean messageHasExpectedContent = hasExpectedContent(messageContent, spec.getExpectedContent());
                    if (messageHasExpectedContent) {
                        return new EmailNotification(subject, messageContent);
                    }
                }
            }
        } catch (MessagingException | IOException e) {
            LoggerUtil.error("An error occurred while retrieving messages from the '%s' inbox %s", login, e);
        }
        return null;
    }

    private boolean hasExpectedContent(String messageContent, List<String> expectedContent) {
        return expectedContent.stream()
                .map(String::toLowerCase)
                .allMatch(c -> messageContent.toLowerCase().contains(c));
    }

    private String getMessageContent(Message message) throws IOException, MessagingException {
        String result = "";
        if (message.isMimeType("text/plain")) {
            result = message.getContent().toString();
        } else if (message.isMimeType("multipart/*")) {
            MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
            result = getTextFromMimeMultipart(mimeMultipart);
        }
        return result;
    }

    private String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws MessagingException, IOException {
        int count = mimeMultipart.getCount();
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < count; i++) {
            BodyPart bodyPart = mimeMultipart.getBodyPart(i);
            if (bodyPart.isMimeType("text/plain")) {
                builder.append("\n");
                builder.append(bodyPart.getContent());
                break;
            } else if (bodyPart.isMimeType("text/html")) {
                String html = (String) bodyPart.getContent();
                builder.append("\n");
                builder.append(Jsoup.parse(html).text());
            } else if (bodyPart.getContent() instanceof MimeMultipart) {
                builder.append(getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent()));
            }
        }
        return builder.toString();
    }
}
