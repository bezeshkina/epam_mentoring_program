package com.epam.cfc.automation.framework.config.data;

import com.epam.cfc.automation.framework.config.exception.TestAutomationException;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class UserDataReader {

    private static final String PATH_TO_TEST_DATA = "src/test/resources/testdata/userdata.json";

    private static UserDataEntry userData;

    private UserDataReader() {
    }

    public static UserDataEntry getUserData() {
        if (userData == null) {
            try (JsonReader reader = new JsonReader(new FileReader(new File(PATH_TO_TEST_DATA)))) {
                userData = new Gson().fromJson(reader, UserDataEntry.class);
            } catch (IOException e) {
                throw new TestAutomationException(e);
            }
        }
        return userData;
    }
}
