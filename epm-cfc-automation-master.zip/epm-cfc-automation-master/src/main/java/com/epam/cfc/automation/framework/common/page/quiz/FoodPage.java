package com.epam.cfc.automation.framework.common.page.quiz;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementVisible;


public class FoodPage extends QuizPage {

    @FindBy(xpath = "//h2['What are your food preferences?']")
    private WebElement quizQuestion;

    @FindBy(css = ".quiz-answer:nth-child(1)")
    private WebElement veganSection;

    @FindBy(css = ".quiz-answer:nth-child(2)")
    private WebElement vegetarianSection;

    @FindBy(css = ".quiz-answer:nth-child(3)")
    private WebElement balancedSection;

    @FindBy(css = ".quiz-answer:nth-child(4)")
    private WebElement fastFoodSection;

    public FoodPage chooseVegan() {
        waitForQuestionVisible();
        LoggerUtil.LOGGER.info("Choosing 'vegan' section");
        veganSection.click();
        return this;
    }

    public FoodPage chooseVegetarian() {
        waitForQuestionVisible();
        LoggerUtil.LOGGER.info("Choosing 'vegetarian' section");
        vegetarianSection.click();
        return this;
    }

    public FoodPage chooseBalanced() {
        waitForQuestionVisible();
        LoggerUtil.LOGGER.info("Choosing 'balanced' section");
        balancedSection.click();
        return this;
    }

    public FoodPage chooseFastFood() {
        waitForQuestionVisible();
        LoggerUtil.LOGGER.info("Choosing 'fast food' section");
        fastFoodSection.click();
        return this;
    }

    private void waitForQuestionVisible() {
        waitForElementVisible(quizQuestion);
    }

    public boolean foodPageIsLoaded() {
        return quizQuestion.isDisplayed();
    }
}
