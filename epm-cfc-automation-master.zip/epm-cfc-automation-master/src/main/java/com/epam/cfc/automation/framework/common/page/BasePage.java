package com.epam.cfc.automation.framework.common.page;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementEnabled;

public class BasePage {

    protected WebDriver driver;
    protected Actions action;

    @FindBy(css = "#loader")
    protected WebElement loader;

    @FindBy(css = ".logo__head")
    private WebElement goHomeBtn;

    public BasePage() {
        this.driver = DriverFactory.getThreadDriver();
        PageFactory.initElements(driver, this);
        action = new Actions(driver);
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public void refresh() {
        LoggerUtil.LOGGER.info("Page is refreshing");
        driver.navigate().refresh();
    }

    public StartPage goToHomePage(){
        waitForElementEnabled(goHomeBtn);
        goHomeBtn.click();
        return new StartPage();
    }

    protected void clickByJS(WebElement element){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", element);
    }
}
