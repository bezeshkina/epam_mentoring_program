package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementVisible;
import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForTitleIs;

public class EmailLoginPage extends ServicePage {

    @FindBy(id = "username")
    private WebElement emailInput;

    @FindBy(id = "password")
    private WebElement passInput;

    @FindBy(id = "login")
    private WebElement loginButton;

    public EmailLoginPage fillLogin(User user) {
        waitForElementVisible(emailInput);
        LoggerUtil.LOGGER.info("Filling the email field(social login)");
        emailInput.sendKeys(user.getLogin());
        return this;
    }

    public EmailLoginPage fillPassword(User user) {
        LoggerUtil.LOGGER.info("Filling the password field(social login)");
        passInput.sendKeys(user.getPassword());
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(social login)");
        loginButton.click();
        waitForTitleIs();
        return new StartPage().pageIsLoaded();
    }

}
