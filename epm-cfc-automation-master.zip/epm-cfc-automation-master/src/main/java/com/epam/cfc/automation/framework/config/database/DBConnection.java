package com.epam.cfc.automation.framework.config.database;

import com.epam.cfc.automation.framework.common.entity.Services;
import com.mongodb.*;

import java.util.Arrays;

public class DBConnection {

    private String user;
    private String database;
    private char[] password;
    private Integer port;
    private String host;
    private String key;

    public DBConnection(DatabaseConfiguration databaseConfiguration) {
        this.user = databaseConfiguration.getUser();
        this.database = databaseConfiguration.getDatabase();
        this.password = databaseConfiguration.getPassword();
        this.port = databaseConfiguration.getPort();
        this.host = databaseConfiguration.getHost();
        this.key = databaseConfiguration.getKey();
    }

    public void removeUserConnection(Services services) {
        MongoCredential credential = MongoCredential.createScramSha1Credential(user, database, password);
        MongoClient mongoClient = new MongoClient(new ServerAddress(host, port), Arrays.asList(credential));
        DBCollection collection = mongoClient.getDB(database).getCollection("employeeFootprint");
        BasicDBObject query = new BasicDBObject().append(key, getEmployeeId(services));
        collection.remove(query);
    }

    private static String getEmployeeId(Services service) {
        switch (service) {
            case vk:
                return "70a75f0b-110a-496f-a528-9936c96acafd";
            case linkedIn:
                return "71f54459-f0fe-449c-b603-b11f93462ec6";
            case google:
                return "92a832f5-b801-455a-a2dd-e21108167444";
            case github:
                return "22da1691-2f90-474f-98d6-03c875452314";
            case twitter:
                return "44718803-55f0-40e4-8f9e-1de89a35b4ee";
            case facebook:
                return "facf7072-30b1-4789-b9d7-f9115e71291d";
            case email:
                return "63fc21be-c273-41f1-9469-bbe27187df6c";
            default:
                return  "";
        }
    }

}
