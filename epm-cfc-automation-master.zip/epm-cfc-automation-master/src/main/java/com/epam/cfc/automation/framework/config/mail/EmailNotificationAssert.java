package com.epam.cfc.automation.framework.config.mail;

import org.assertj.core.api.AbstractAssert;

import java.util.List;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

public class EmailNotificationAssert extends AbstractAssert<EmailNotificationAssert, EmailNotification> {

    EmailNotificationAssert(EmailNotification actual) {
        super(actual, EmailNotificationAssert.class);
    }

    public EmailNotificationAssert subjectContains(String subject) {
        isNotNull();
        assertThat(actual.getSubject()).containsIgnoringCase(subject);
        return this;
    }

    public EmailNotificationAssert contentContains(List<String> expectedContent) {
        isNotNull();
        assertThat(actual.getContent().toLowerCase().trim().replaceAll(" +", " "))
                .contains(expectedContent.stream().map(String::toLowerCase).collect(Collectors.toList()));
        return this;
    }

    public EmailNotificationAssert contentContains(String expectedContent) {
        isNotNull();
        assertThat(actual.getContent().toLowerCase().trim().replaceAll(" +", " "))
                .contains(expectedContent.toLowerCase());
        return this;
    }
}
