package com.epam.cfc.automation.framework.core.waiter;

public enum Timeout {

    ULTRA_SLOW(120),
    VERY_SLOW(60),
    SLOW(30),
    MEDIUM(15),
    NORMAL(10),
    QUICK(5),
    VERY_QUICK(2);

    private int seconds;

    Timeout(int seconds) {
        this.seconds = seconds;
    }

    public int getSeconds() {
        return seconds;
    }
}
