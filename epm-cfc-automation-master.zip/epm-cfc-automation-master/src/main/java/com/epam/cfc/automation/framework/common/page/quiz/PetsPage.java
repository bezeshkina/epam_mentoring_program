package com.epam.cfc.automation.framework.common.page.quiz;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementVisible;

public class PetsPage extends QuizPage {

    @FindBy(xpath = "//h2['Do you have pets?']")
    private WebElement quizQuestion;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['CAT']\"]//input")
    private WebElement countOfCatsInput;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['DOG']\"]//input")
    private WebElement countOfDogsInput;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['RODENT']\"]//input")
    private WebElement countOfRodentsInput;

    @FindBy(css = ".quiz-answer__card.other-card")
    private WebElement otherSection;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['AQUARIUM_FISH']\"]//input")
    private WebElement countOfAquariumFishInput;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['PARROT']\"]//input")
    private WebElement countOfParrotsInput;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['RABBITS']\"]//input")
    private WebElement countOfRabbitsInput;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['LIZARDS']\"]//input")
    private WebElement countOfLizardsInput;

    @FindBy(xpath = "//*[@count=\"$ctrl.pets['SNAKES_AND_SPIDERS']\"]//input")
    private WebElement countOfSnakesAndSpidersInput;

    public PetsPage setCatsCount(int count) {
        LoggerUtil.LOGGER.info("Setting cats count equal to: " + count);
        countOfCatsInput.sendKeys(String.valueOf(count));
        return this;
    }

    public PetsPage setDogsCount(int count) {
        LoggerUtil.LOGGER.info("Setting dogs count equal to: " + count);
        countOfDogsInput.sendKeys(String.valueOf(count));
        return this;
    }

    public PetsPage setRodentCount(int count) {
        LoggerUtil.LOGGER.info("Setting rodent count equal to: " + count);
        countOfRodentsInput.sendKeys(String.valueOf(count));
        return this;
    }
    public PetsPage setAquariumFishCount(int count) {
        LoggerUtil.LOGGER.info("Setting aquarium fish count equal to: " + count);
        countOfAquariumFishInput.sendKeys(String.valueOf(count));
        return this;
    }

    public PetsPage setParrotsCount(int count) {
        LoggerUtil.LOGGER.info("Setting parrots count equal to: " + count);
        countOfParrotsInput.sendKeys(String.valueOf(count));
        return this;
    }

    public PetsPage setRabbitsCount(int count) {
        LoggerUtil.LOGGER.info("Setting rabbits count equal to: " + count);
        countOfRabbitsInput.sendKeys(String.valueOf(count));
        return this;
    }

    public PetsPage setLizardsCount(int count) {
        LoggerUtil.LOGGER.info("Setting lizards count equal to: " + count);
        countOfLizardsInput.sendKeys(String.valueOf(count));
        return this;
    }

    public PetsPage setSnakesAndSpidersCount(int count) {
        LoggerUtil.LOGGER.info("Setting snakes and spiders count equal to: " + count);
        countOfSnakesAndSpidersInput.sendKeys(String.valueOf(count));
        return this;
    }

    public PetsPage waitForSectionVisible() {
        waitForElementVisible(quizQuestion);
        return this;
    }

    public PetsPage clickOtherSection() {
        LoggerUtil.LOGGER.info("Clicking on other section");
        otherSection.click();
        return this;
    }

    public boolean petsPageIsLoaded() {
        return quizQuestion.isDisplayed();
    }
}
