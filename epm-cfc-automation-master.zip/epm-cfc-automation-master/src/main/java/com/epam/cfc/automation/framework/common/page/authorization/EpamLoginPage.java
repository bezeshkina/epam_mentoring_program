package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForTitleIs;

public class EpamLoginPage extends ServicePage {

    @FindBy(css = "#userNameInput")
    private WebElement loginInput;

    @FindBy(css = "#passwordInput")
    private WebElement passwordInput;

    @FindBy(css = "#submitButton")
    private WebElement submitBtn;

    public ServicePage fillLogin(User user) {
        LoggerUtil.LOGGER.info("Filling the email field(epam login)");
        loginInput.sendKeys(user.getLogin());
        return this;
    }

    public ServicePage fillPassword(User user) {
        LoggerUtil.LOGGER.info("Filling the password field(epam login)");
        passwordInput.sendKeys(user.getPassword());
        return this;
    }

    @Override
    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(epam login)");
        submitBtn.click();
        waitForTitleIs();
        return new StartPage().pageIsLoaded();
    }

}
