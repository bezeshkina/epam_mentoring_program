package com.epam.cfc.automation.framework.core.driver;

import com.epam.cfc.automation.framework.core.waiter.Timeout;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class DriverFactory {

    private static WebDriver driver;

    private DriverFactory(){
    }

    private static WebDriver initDriver() {
        if (Browser.detect().getName().equalsIgnoreCase("chrome")) {
            driver = new /*Local*/ChromeDriverManager().createDriver();
        } else if (Browser.detect().getName().equalsIgnoreCase("firefox")) {
            driver = new /*Local*/FirefoxDriverManager().createDriver();
        }
        driver.manage().timeouts().pageLoadTimeout(Timeout.ULTRA_SLOW.getSeconds(), TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(Timeout.NORMAL.getSeconds(), TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public static void driverQuit() {
        if (driver != null){
            driver.quit();
        }
    }

    public static WebDriver getThreadDriver() {
        if (driver == null) {
            driver = initDriver();
        }
        return driver;
    }
}
