package com.epam.cfc.automation.framework.common.page.quiz;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.waiter.Timeout;
import com.epam.cfc.automation.framework.core.waiter.Waiting;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class QuizResultPage extends QuizPage {

    @FindBy(css = ".result-diagram__container")
    private WebElement diagramOfResults;

    @FindBy(xpath = "//div[@class='button_unsubscribe-subscribe']/button")
    private WebElement subscribeButton;

    @FindBy(css = ".subscribe-modal__email-input")
    private WebElement emailInput;

    @FindBy(css = ".subscribe-modal__confirm")
    private WebElement confirmButton;

    public Boolean resultIsPresented() {
        Waiting.waitForElementVisible(diagramOfResults);
        LoggerUtil.LOGGER.info("Asserting that quiz result is present");
        return diagramOfResults.isDisplayed();
    }

    public QuizResultPage clickSubscribe() {
        Waiting.waitForInvisibilityOfElement(loader);
        Waiting.waitForElementEnabled(subscribeButton);
        Waiting.sleep(Timeout.VERY_QUICK.getSeconds());
        if (subscribeButton.getText().equals("Unsubscribe")) {
            clickUnsubscribe();
            confirm();
        }
        Waiting.sleep(Timeout.VERY_QUICK.getSeconds());
        if (loader.isDisplayed()) {
            Waiting.waitForInvisibilityOfElement(loader);
        }
        LoggerUtil.LOGGER.info("Pressing 'Subscribe' button");
        subscribeButton.click();
        Waiting.waitForElementEnabled(confirmButton);
        return this;
    }

    public QuizResultPage clickUnsubscribe() {
        LoggerUtil.LOGGER.info("Pressing 'Unsubscribe' button");
        Waiting.sleep(Timeout.VERY_QUICK.getSeconds());
        clickByJS(subscribeButton);
        Waiting.waitForElementEnabled(confirmButton);
        return this;
    }

    public void confirm() {
        Waiting.waitForInvisibilityOfElement(loader);
        confirmButton.click();
        Waiting.waitForElementEnabled(subscribeButton);
    }

    public QuizResultPage fillEmailField(String email) {
        LoggerUtil.LOGGER.info("Filling email: " + email);
        emailInput.clear();
        emailInput.sendKeys(email);
        Waiting.waitForElementEnabled(confirmButton);
        return this;
    }

    public boolean isButtonChangesToUnsubscribe() {
        return subscribeButton.getText().equals("Unsubscribe");
    }

    public boolean isButtonChangesToSubscribe() {
        return subscribeButton.getText().equals("Subscribe");
    }
}
