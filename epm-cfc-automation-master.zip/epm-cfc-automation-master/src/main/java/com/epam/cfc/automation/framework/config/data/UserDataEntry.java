package com.epam.cfc.automation.framework.config.data;

public class UserDataEntry {

    private User gmail;
    private User linkedIn;
    private User facebook;
    private User twitter;
    private User vk;
    private User email;
    private User github;

    public User getGmailUser() {
        return gmail;
    }

    public User getLinkedInUser() {
        return linkedIn;
    }

    public User getFacebookUser() {
        return facebook;
    }

    public User getTwitterUser() {
        return twitter;
    }

    public User getVkUser() {
        return vk;
    }

    public User getEmailUser() {
        return email;
    }

    public User getGithubUser() {
        return github;
    }
}
