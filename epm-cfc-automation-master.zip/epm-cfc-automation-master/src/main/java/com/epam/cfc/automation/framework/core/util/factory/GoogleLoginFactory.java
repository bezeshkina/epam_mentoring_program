package com.epam.cfc.automation.framework.core.util.factory;

import com.epam.cfc.automation.framework.common.page.authorization.GoogleLoginPage;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;

public class GoogleLoginFactory implements Login {

    @Override
    public void logInService(UserDataEntry userDataEntry) {
        GoogleLoginPage loginPage = new GoogleLoginPage();
        loginPage
                .fillLogin(userDataEntry.getGmailUser()).clickNext()
                .fillPassword(userDataEntry.getGmailUser())
                .submit();
        loginPage.waitForTitle();
    }
}
