package com.epam.cfc.automation.framework.core.driver;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.openqa.selenium.chrome.ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY;

public class LocalChromeDriverManager extends DriverManager {

    public WebDriver createDriver() {
        System.setProperty(CHROME_DRIVER_EXE_PROPERTY, "webdriver/chromedriver.exe");
        LoggerUtil.LOGGER.info("Chrome browser starts up");
        driver = new ChromeDriver();
        return driver;
    }

}
