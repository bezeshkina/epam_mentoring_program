package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.BasePage;
import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForTitleIs;

class TwitterUserVerification extends BasePage {

    private static final String USER_NUMBER = "77785822317";
    private static final String PASSWORD = "password2019";

    @FindBy(id = "challenge_response")
    private WebElement telNumField;

    @FindBy(xpath = "//*[@id = 'email_challenge_submit']")
    private WebElement submitBtn;

    @FindBy(xpath = "//*[@class='clearfix field']/*[@name= 'session[username_or_email]']")
    private WebElement verifyNumField;

    @FindBy(xpath = "//*[@class='clearfix field']/*[@name= 'session[password]']")
    private WebElement passField;

    @FindBy(css = ".clearfix>.submit")
    private WebElement verifyBtn;

    StartPage verifyUser() {
        if (telNumField.isEnabled()) {
            LoggerUtil.LOGGER.debug("Verifying user's telephone number process");
            telNumField.sendKeys(USER_NUMBER);
            submitBtn.click();
            waitForTitleIs();
            return new StartPage();
        } else {
            LoggerUtil.LOGGER.debug("Verifying user process: strong verification");
            verifyNumField.sendKeys(USER_NUMBER);
            passField.sendKeys(PASSWORD);
            verifyBtn.click();
            telNumField.sendKeys(USER_NUMBER);
            submitBtn.click();
            waitForTitleIs();
            return new StartPage();
        }
    }
}
