package com.epam.cfc.automation.framework.core.util.factory;

import com.epam.cfc.automation.framework.config.data.UserDataEntry;

public interface Login {

    void logInService(UserDataEntry userDataEntry);
}
