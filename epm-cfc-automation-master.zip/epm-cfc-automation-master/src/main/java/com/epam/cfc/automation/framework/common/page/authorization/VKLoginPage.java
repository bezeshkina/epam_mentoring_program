package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.waiter.Waiting;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForTitleIs;

public class VKLoginPage extends ServicePage {

    @FindBy(name = "email")
    private WebElement emailField;

    @FindBy(name = "pass")
    private WebElement passwordField;

    @FindBy(css = "#install_allow")
    private WebElement submitBtn;

    public VKLoginPage(){
        LoggerUtil.LOGGER.info("Vkontakte login page was opened");
    }

    public VKLoginPage fillLogin(User user) {
        Waiting.waitForElementVisible(emailField);
        LoggerUtil.LOGGER.info("Filling the email field(VK)");
        emailField.sendKeys(user.getLogin());
        return this;
    }

    public VKLoginPage fillPassword(User user) {
        LoggerUtil.LOGGER.info("Filling the password field(VK)");
        passwordField.sendKeys(user.getPassword());
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(VK)");
        submitBtn.click();
        waitForTitleIs();
        return new StartPage();
    }
}
