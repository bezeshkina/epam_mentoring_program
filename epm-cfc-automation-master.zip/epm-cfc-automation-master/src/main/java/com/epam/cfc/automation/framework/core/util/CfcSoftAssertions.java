package com.epam.cfc.automation.framework.core.util;

import com.epam.cfc.automation.framework.config.mail.EmailNotification;
import com.epam.cfc.automation.framework.config.mail.EmailNotificationAssert;
import org.assertj.core.api.SoftAssertions;

import java.util.function.Consumer;

public class CfcSoftAssertions extends SoftAssertions {

    public EmailNotificationAssert assertThat(EmailNotification actual) {
        return proxy(EmailNotificationAssert.class, EmailNotification.class, actual);
    }

    public static void softlyAssert(Consumer<CfcSoftAssertions> softly) {
        CfcSoftAssertions assertions = new CfcSoftAssertions();
        softly.accept(assertions);
        assertions.assertAll();
    }
}
