package com.epam.cfc.automation.framework.config.mail;

public enum EmailNotificationSubject {

    USER_SUBSCRIBED(EmailNotificationSubjectTitle.CFC_INFORMATION_FOR_NEW_SUBSCRIBERS),
    USER_UNSUBSCRIBED(EmailNotificationSubjectTitle.CFC_INFORMATION_FOR_UNSUBSCRIBERS);

    private EmailNotificationSubjectTitle subjectTitle;

    EmailNotificationSubject(EmailNotificationSubjectTitle subjectTitle) {
        this.subjectTitle = subjectTitle;
    }

    public String getSubject() {
        return subjectTitle.getTitle();
    }

    private enum EmailNotificationSubjectTitle {

        CFC_INFORMATION_FOR_NEW_SUBSCRIBERS("[CFC] Information for New Subscribers"),
        CFC_INFORMATION_FOR_UNSUBSCRIBERS("[CFC] Information for Unsubscribers");

        private String title;

        EmailNotificationSubjectTitle(String title) {
            this.title = title;
        }

        public String getTitle() {
            return title;
        }
    }
}
