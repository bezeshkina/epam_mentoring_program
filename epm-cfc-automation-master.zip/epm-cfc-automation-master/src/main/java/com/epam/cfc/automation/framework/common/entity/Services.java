package com.epam.cfc.automation.framework.common.entity;

public enum Services {
    facebook,
    github,
    vk,
    twitter,
    email,
    google,
    linkedIn
}
