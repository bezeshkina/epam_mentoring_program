package com.epam.cfc.automation.framework.common.page.element;

import com.epam.cfc.automation.framework.common.page.BasePage;
import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.waiter.Waiting;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import java.util.List;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElement;
import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementEnabled;

public class LocationSelectionContainer extends BasePage {

    @FindBy(css = ".location-selection-container")
    private WebElement pickYourCityPopUpWindow;

    @FindBy(css = ".input-location")
    private WebElement inputLocation;

    @FindAll({@FindBy(css = ".scrollable-content>li")})
    private List<WebElement> cities;

    @FindBy(css = ".location-button__start")
    private WebElement saveLocationButton;

    @FindBy(css = ".scrollable-content>li")
    private WebElement city;

    @FindBy(css = ".location-button__cancel")
    private WebElement cancelButton;

    @FindBy(xpath = "//button[@class='location-button__start ng-binding disabled']")
    private WebElement disabledButton;

    @FindBy(xpath = "//div[@class='not-found ng-binding ng-scope'][contains(text(), 'Nothing is found for your request.')]")
    private WebElement nothingIsFoundMessage;

    private JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getThreadDriver();

    public boolean isContainerDisplayed() {
        Waiting.waitForElementVisible(pickYourCityPopUpWindow);
        return pickYourCityPopUpWindow.isDisplayed();
    }

    public void inputCity(String city) {
        waitForElement(inputLocation).clear();
        inputLocation.sendKeys(city);
    }

    public LocationSelectionContainer inputAndSelectCity(String key) {
        waitForElement(inputLocation).clear();
        inputLocation.sendKeys(key);
        action.pause(2);
        js.executeScript("arguments[0].click();", city);
        return this;
    }

    public LocationSelectionContainer clickCancel() {
        waitForElementEnabled(cancelButton);
        cancelButton.click();
        return this;
    }

    public StartPage saveLocation() {
        waitForElementEnabled(saveLocationButton);
        saveLocationButton.click();
        return new StartPage();
    }

    public boolean isListOfCitiesExist() {
        waitForElementEnabled(city);
        return city.isDisplayed();
    }

    public boolean isMessageAppears() {
        return nothingIsFoundMessage.isDisplayed();
    }

}
