package com.epam.cfc.automation.framework.core.driver;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URI;

public class FirefoxDriverManager extends DriverManager {

    private static final String SELENOID_HUB_URL = "http://ecsc00a0499a.epam.com:4444/wd/hub";

    @Override
    protected WebDriver createDriver() {
        WebDriver driver = null;
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setBrowserName("firefox");
        capabilities.setVersion("68.0");
        capabilities.setCapability("enableVNC", true);
        capabilities.setCapability("enableVideo", false);
        capabilities.setCapability("acceptInsecureCerts",true);
        try {
            driver = new RemoteWebDriver(
                    URI.create(SELENOID_HUB_URL).toURL(),
                    capabilities
            );
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        LoggerUtil.LOGGER.info("Mozilla Firefox browser starts up");
        return driver;
    }
}
