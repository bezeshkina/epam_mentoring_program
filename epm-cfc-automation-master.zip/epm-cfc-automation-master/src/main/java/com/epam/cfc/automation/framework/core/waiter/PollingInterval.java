package com.epam.cfc.automation.framework.core.waiter;

public enum PollingInterval {

    VERY_SLOW(3000),
    SLOW(1000),
    MEDIUM(500),
    QUICK(100);

    private int milliseconds;

    PollingInterval(int milliseconds) {
        this.milliseconds = milliseconds;
    }

    public int getMilliseconds() {
        return milliseconds;
    }
}
