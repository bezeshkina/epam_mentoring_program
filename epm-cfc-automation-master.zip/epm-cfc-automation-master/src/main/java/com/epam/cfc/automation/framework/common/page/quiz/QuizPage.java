package com.epam.cfc.automation.framework.common.page.quiz;

import com.epam.cfc.automation.framework.common.entity.TransportType;
import com.epam.cfc.automation.framework.common.page.BasePage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.HashMap;
import java.util.Map;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementEnabled;

public abstract class QuizPage extends BasePage {

    @FindBy(css = ".quiz-button-panel__button--next")
    private WebElement nextButton;

    @FindBy(css = ".quiz-button-panel__button--back")
    private WebElement backButton;

    private static Map<TransportType, Boolean> transport;

    static {
        transport = new HashMap<TransportType, Boolean>();
        transport.put(TransportType.FOOT, false);
        transport.put(TransportType.BIKE, false);
        transport.put(TransportType.CAR, false);
        transport.put(TransportType.BUS, false);
        transport.put(TransportType.SUBWAY, false);
        transport.put(TransportType.TRAIN, false);
    }

    protected static void setTransport(TransportType transportType, Boolean result){
        transport.put(transportType, result);
    }

    protected static Map getTransport(){
        return transport;
    }

    public QuizPage clickNext(){
        LoggerUtil.LOGGER.info("Click Next");
        nextButton.click();
        return this;
    }

    public boolean quizIsOpened(){
        LoggerUtil.LOGGER.info("Verifying that Quiz page was loaded");
        return nextButton.isDisplayed();
    }

    public void clickBack(){
        LoggerUtil.LOGGER.info("Click Back");
        waitForElementEnabled(backButton);
        backButton.click();
    }

    public boolean checkThatNextBtnDisabled(){
        LoggerUtil.LOGGER.info("Checking that the next button is disabled");
        return (!nextButton.isEnabled());
    }
}
