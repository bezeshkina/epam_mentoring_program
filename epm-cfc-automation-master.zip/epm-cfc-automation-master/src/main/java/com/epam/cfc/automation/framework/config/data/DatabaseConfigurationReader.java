package com.epam.cfc.automation.framework.config.data;

import com.epam.cfc.automation.framework.config.database.DatabaseConfiguration;
import com.epam.cfc.automation.framework.config.exception.TestAutomationException;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class DatabaseConfigurationReader {

    private static final String PATH_TO_DB_CONFIG_FILE = "src/test/resources/testdata/database.json";

    private static DatabaseConfiguration databaseConfiguration;

    private DatabaseConfigurationReader() {
    }

    public static DatabaseConfiguration getDatabaseConfiguration() {
        if (databaseConfiguration == null) {
            try (JsonReader reader = new JsonReader(new FileReader(new File(PATH_TO_DB_CONFIG_FILE)))) {
                databaseConfiguration = new Gson().fromJson(reader, DatabaseConfiguration.class);
            } catch (IOException e) {
                throw new TestAutomationException(e);
            }
        }
        return databaseConfiguration;
    }
}
