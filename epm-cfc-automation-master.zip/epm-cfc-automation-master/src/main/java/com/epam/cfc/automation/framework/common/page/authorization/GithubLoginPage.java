package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.waiter.Waiting;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForTitleIs;

public class GithubLoginPage extends ServicePage {

    @FindBy(css = "#login_field")
    private WebElement loginField;

    @FindBy(css = "#password")
    private WebElement passwordField;

    @FindBy(xpath = "//input[@value='Sign in']")
    private WebElement submitBtn;

    public GithubLoginPage(){
        LoggerUtil.LOGGER.info("Github login page was opened");
    }

    public GithubLoginPage fillLogin(User user) {
        Waiting.waitForElementVisible(loginField);
        LoggerUtil.LOGGER.info("Filling the email field(github)");
        loginField.sendKeys(user.getLogin());
        return this;
    }

    public GithubLoginPage fillPassword(User user) {
        LoggerUtil.LOGGER.info("Filling the password field(github)");
        passwordField.sendKeys(user.getPassword());
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(github)");
        submitBtn.click();
        waitForTitleIs();
        return new StartPage();
    }

}
