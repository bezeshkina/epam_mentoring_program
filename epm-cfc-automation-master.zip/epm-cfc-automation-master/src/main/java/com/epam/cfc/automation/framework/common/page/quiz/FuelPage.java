package com.epam.cfc.automation.framework.common.page.quiz;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementVisible;

////import io.qameta.allure.Step;

public class FuelPage extends QuizPage {

    @FindBy(css = ".quiz-answer:nth-child(1)")
    private WebElement gasolineCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(2)")
    private WebElement dieselCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(3)")
    private WebElement hybridCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(4)")
    private WebElement electricityCheckbox;

    @FindBy(xpath = "//h2['What is the type of fuel of your car?']")
    private WebElement quizQuestion;

    public TimeOfJourneyPage setGasoline() {
        LoggerUtil.LOGGER.info("Choosing 'gasoline' section");
        gasolineCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public TimeOfJourneyPage setDiesel() {
        LoggerUtil.LOGGER.info("Choosing 'diesel' section");
        dieselCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public TimeOfJourneyPage setHybrid() {
        LoggerUtil.LOGGER.info("Choosing 'gasoline' section");
        hybridCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public TimeOfJourneyPage setElectricity() {
        waitForElementVisible(quizQuestion);
        LoggerUtil.LOGGER.info("Choosing 'electricity' section");
        electricityCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public boolean fuelPageIsLoaded(){
        return quizQuestion.isDisplayed();
    }
}
