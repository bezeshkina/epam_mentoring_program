package com.epam.cfc.automation.framework.common.page;

import com.epam.cfc.automation.framework.common.entity.Services;
import com.epam.cfc.automation.framework.common.page.authorization.*;
import com.epam.cfc.automation.framework.common.page.element.LocationSelectionContainer;
import com.epam.cfc.automation.framework.common.page.quiz.QuizPage;
import com.epam.cfc.automation.framework.common.page.quiz.QuizResultPage;
import com.epam.cfc.automation.framework.common.page.quiz.TransportPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.waiter.Timeout;
import com.epam.cfc.automation.framework.core.waiter.Waiting;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.*;

public class StartPage extends BasePage {

    private static final String HOME_PAGE_URL = "https://ecsc00a03b05.epam.com";

    @FindBy(css = ".login_button button")
    private WebElement loginButton;

    @FindBy(css = ".login_popup")
    private WebElement loginPopup;

    @FindBy(css = "div.login_popup > div.login_email > p")
    private WebElement emailLink;

    @FindBy(css = ".button_google")
    private WebElement googleButton;

    @FindBy(css = ".button_facebook")
    private WebElement facebookButton;

    @FindBy(css = ".button_github")
    private WebElement githubButton;

    @FindBy(css = ".button_twitter")
    private WebElement twitterButton;

    @FindBy(css = ".button_vk")
    private WebElement vkButton;

    @FindBy(css = ".button_linkedin")
    private WebElement linkedInButton;

    @FindBy(css = "#big-calculate-button")
    private WebElement startButton;

    @FindBy(css = ".login_internal_login>button>span")
    private WebElement epamButton;

    @FindBy(css = ".dropbtn")
    private WebElement dropdownMenu;

    @FindBy(css = ".menu-item__icon.results")
    private WebElement myResults;

    @FindBy(css = ".log-out")
    private WebElement logOut;

    @FindBy(css = ".scroll-start-container")
    private WebElement scrollStartToGlobe;

    @FindBy(css = ".scroll-globe-container")
    private WebElement scrollGlobeToFinal;

    @FindBy(css = ".reason-main>.reason-title")
    private WebElement mainReasonHeaderFinalPage;

    @FindBy(css = ".reason-main__text")
    private WebElement mainReasonTextFinalPage;

    @FindBy(css = ".reason-footer")
    private WebElement mainReasonFooterFinalPage;

    @FindBy(css = "button.header__button-calculate")
    private WebElement calculateBtn;

    @FindBy(css = ".user-location__wrapper")
    private WebElement locationItem;

    @FindBy(xpath = "//div[@class='user-location__information']")
    private WebElement locationPresents;

    @FindBy(css = ".change-location")
    private WebElement changeLocation;

    @FindBy(xpath = "//p[@class='ng-binding'][contains(text(), 'Karaganda')]")
    private WebElement usersLocation;

    public StartPage open() {
        driver.get(HOME_PAGE_URL);
        LoggerUtil.LOGGER.info("Home page is loading");
        waitForElementVisible(startButton);
        return this;
    }

    public StartPage openLoginPopupWindow() {
        if(dropdownMenu.isDisplayed()) logout();
        waitForInvisibilityOfElement(loader);
        Waiting.waitForElementEnabled(loginButton);
        try {
            LoggerUtil.LOGGER.info("Clicking on the Login button");
            action.click(loginButton).build().perform();
            Waiting.waitForElementEnabled(loginPopup);
        } catch (WebDriverException e) {
            LoggerUtil.LOGGER.debug("Element " + loginButton.getLocation() + " isn't enabled", e);
            clickByJS(loginButton);
            sleep(Timeout.VERY_QUICK.getSeconds());
            Waiting.waitForElementEnabled(loginPopup);
        }
        return this;
    }

    public void logout() {
        try {
            waitForInvisibilityOfElement(loader);
            LoggerUtil.LOGGER.info("User logging out");
            action
                    .moveToElement(dropdownMenu)
                    .click(logOut)
                    .build()
                    .perform();
        } catch (WebDriverException e) {
            clickByJS(logOut);
            sleep(Timeout.VERY_QUICK.getSeconds());
        }
        refresh();
        waitForElementEnabled(loginButton);
    }

    public QuizResultPage openMyResults() {
        try {
            waitForInvisibilityOfElement(loader);
            LoggerUtil.LOGGER.info("Opening user's quiz results");
            action
                    .moveToElement(dropdownMenu)
                    .click(myResults)
                    .build()
                    .perform();
        } catch (TimeoutException | NoSuchElementException | JavascriptException e) {
            clickByJS(myResults);
        }
        waitForInvisibilityOfElement(loader);
        return new QuizResultPage();
    }

    public TransportPage start() {
        waitForInvisibilityOfElement(loginPopup);
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        LoggerUtil.LOGGER.info("Clicking on the 'Start' button");
        waitForElementEnabled(startButton);
        startButton.click();
        return new TransportPage();
    }

    public ServicePage openServicePage(Services service) {
        switch (service) {
            case linkedIn:
                LoggerUtil.LOGGER.info("Choosing singing in via LinkedIn");
                linkedInButton.click();
                return new LinkedInLoginPage();
            case facebook:
                LoggerUtil.LOGGER.info("Choosing singing in via Facebook");
                facebookButton.click();
                return new FacebookLoginPage();
            case vk:
                LoggerUtil.LOGGER.info("Choosing singing in via VK");
                vkButton.click();
                return new VKLoginPage();
            case github:
                LoggerUtil.LOGGER.info("Choosing singing in via Github");
                githubButton.click();
                return new GithubLoginPage();
            case twitter:
                LoggerUtil.LOGGER.info("Choosing singing in via Twitter");
                twitterButton.click();
                return new TwitterLoginPage();
            case email:
                LoggerUtil.LOGGER.info("Choosing singing in via social login");
                waitForElementEnabled(emailLink);
                emailLink.click();
                return new EmailLoginPage();
            default:
                LoggerUtil.LOGGER.info("Choosing singing in via Gmail");
                googleButton.click();
                return new GoogleLoginPage();
        }
    }

    public void chooseService(Services service) {
        switch (service) {
            case linkedIn:
                LoggerUtil.LOGGER.info("Choosing singing in via LinkedIn");
                linkedInButton.click();
                break;
            case facebook:
                LoggerUtil.LOGGER.info("Choosing singing in via Facebook");
                facebookButton.click();
                break;
            case vk:
                LoggerUtil.LOGGER.info("Choosing singing in via VK");
                vkButton.click();
                break;
            case github:
                LoggerUtil.LOGGER.info("Choosing singing in via Github");
                githubButton.click();
                break;
            case twitter:
                LoggerUtil.LOGGER.info("Choosing singing in via Twitter");
                twitterButton.click();
                break;
            case email:
                LoggerUtil.LOGGER.info("Choosing singing in via social login");
                waitForElementEnabled(emailLink);
                emailLink.click();
                break;
            default:
                LoggerUtil.LOGGER.info("Choosing singing in via Gmail");
                googleButton.click();
        }
        waitForElementEnabled(startButton);
    }

    public void scrollToGlobePage() {
        waitForInvisibilityOfElement(loginPopup);
        LoggerUtil.LOGGER.info("Scrolling to Globe Page");
        waitForElementEnabled(startButton);
        waitAndClick(scrollStartToGlobe);
        LoggerUtil.LOGGER.debug("Calculate button is displayed");
    }

    public boolean startButtonIsEnabled() {
        return startButton.isEnabled();
    }

    public QuizPage clickToCalculate() {
        LoggerUtil.LOGGER.info("Clicking to Calculate button");
        clickByJS(calculateBtn);
        sleep(Timeout.VERY_QUICK.getSeconds());
        return new TransportPage();
    }

    public StartPage pageIsLoaded() {
        waitForElementVisible(startButton);
        return this;
    }

    public StartPage clickLocationItem() {
        waitForElementVisible(locationItem);
        action.moveToElement(locationItem).build().perform();
        return this;
    }

    public boolean isLocationVisible() {
        return locationPresents.isDisplayed();
    }

    public LocationSelectionContainer openChangeLocationContainer() {
        Waiting.waitForElementEnabled(locationItem);
        action.moveToElement(locationItem).click(changeLocation).build().perform();
        return new LocationSelectionContainer();
    }

    public boolean isUsersLocationKaraganda() {
        Waiting.waitForElementVisible(locationPresents);
        return usersLocation.isDisplayed();
    }
}
