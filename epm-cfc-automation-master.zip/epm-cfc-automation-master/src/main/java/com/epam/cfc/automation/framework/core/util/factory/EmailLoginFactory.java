package com.epam.cfc.automation.framework.core.util.factory;

import com.epam.cfc.automation.framework.common.page.authorization.EmailLoginPage;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;

public class EmailLoginFactory implements Login {

    @Override
    public void logInService(UserDataEntry userDataEntry) {
        new EmailLoginPage()
                .fillLogin(userDataEntry.getEmailUser())
                .fillPassword(userDataEntry.getEmailUser())
                .submit();
    }
}
