package com.epam.cfc.automation.framework.core.util.services;


import com.epam.cfc.automation.framework.common.entity.Services;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;
import com.epam.cfc.automation.framework.core.util.factory.LoginFactory;

public class LogIn {

    public void login(Services service, UserDataEntry userDataEntry) {
        new LoginFactory().chooseService(service).logInService(userDataEntry);
    }
}
