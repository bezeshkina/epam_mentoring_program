package com.epam.cfc.automation.framework.core.util.factory;

import com.epam.cfc.automation.framework.common.page.authorization.GithubLoginPage;
import com.epam.cfc.automation.framework.config.data.UserDataEntry;

public class GithubLoginFactory implements Login {

    @Override
    public void logInService(UserDataEntry userDataEntry) {
        new GithubLoginPage()
                .fillLogin(userDataEntry.getGithubUser())
                .fillPassword(userDataEntry.getGithubUser())
                .submit();
    }
}
