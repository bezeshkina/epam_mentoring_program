package com.epam.cfc.automation.framework.config.mail;

public class EmailNotificationSpecFactory {

    private EmailNotificationSpecFactory() {
    }

    public static EmailNotificationSpec createSubscribeSpec(EmailNotificationSubject subject) {
        EmailNotificationSpec notificationSpecification = new EmailNotificationSpec(subject.getSubject());
        notificationSpecification.getExpectedContent().add("You have successfully subscribed");
        return notificationSpecification;
    }

    public static EmailNotificationSpec createUnsubscribeSpec(EmailNotificationSubject subject) {
        EmailNotificationSpec notificationSpecification = new EmailNotificationSpec(subject.getSubject());
        notificationSpecification.getExpectedContent().add("You have successfully unsubscribed");
        return notificationSpecification;
    }

}
