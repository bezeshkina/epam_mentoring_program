package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForTitleIs;

public class LinkedInLoginPage extends ServicePage {

    @FindBy(id = "username")
    private WebElement usernameInput;

    @FindBy(id = "password")
    private WebElement passwordInput;

    @FindBy(css = ".btn__primary--large")
    private WebElement submitButton;

    @Override
    public ServicePage fillLogin(User user) {
        LoggerUtil.LOGGER.info("Filling the email field(linkedIn)");
        try {
            usernameInput.sendKeys(user.getLogin());
        } catch (NoSuchElementException | TimeoutException e) {
            refresh();
        }
        return this;
    }

    @Override
    public ServicePage fillPassword(User user) {
        LoggerUtil.LOGGER.info("Filling the password field(linkedIn)");
        passwordInput.sendKeys(user.getPassword());
        return this;
    }

    @Override
    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(linkedIn)");
        submitButton.click();
        waitForTitleIs();
        return new StartPage();
    }
}
