package com.epam.cfc.automation.framework.common.entity;

public enum TransportType {
    FOOT,
    CAR,
    BUS,
    TRAIN,
    SUBWAY,
    BIKE
}
