package com.epam.cfc.automation.framework.core.util;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;

public class Screenshots {

    private Screenshots() {
    }

    public static void takeScreenshot(String methodName, String reportPortalMessage) {
        File screenshot = ((TakesScreenshot) DriverFactory.getThreadDriver()).getScreenshotAs(OutputType.FILE);
        try {
            File file = new File("target/" + methodName + System.currentTimeMillis() + ".png");
            FileHandler.copy(screenshot, file);
            LoggerUtil.log(screenshot, reportPortalMessage);
        } catch (IOException e) {
            LoggerUtil.LOGGER.info(e);
        }
    }
}
