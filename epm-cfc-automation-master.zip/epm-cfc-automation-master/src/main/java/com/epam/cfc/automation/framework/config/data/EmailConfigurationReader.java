package com.epam.cfc.automation.framework.config.data;

import com.epam.cfc.automation.framework.config.exception.TestAutomationException;
import com.epam.cfc.automation.framework.config.mail.EmailConfiguration;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class EmailConfigurationReader {

    private static final String PATH_TO_EMAIL_CONFIG_FILE = "src/test/resources/testdata/emailconfiguration";

    private static EmailConfiguration emailConfiguration;

    private EmailConfigurationReader() {
    }

    public static EmailConfiguration getEmailConfiguration() {
        if (emailConfiguration == null) {
            try (JsonReader reader = new JsonReader(new FileReader(new File(PATH_TO_EMAIL_CONFIG_FILE)))) {
                emailConfiguration = new Gson().fromJson(reader, EmailConfiguration.class);
            } catch (IOException e) {
                throw new TestAutomationException(e);
            }
        }
        return emailConfiguration;
    }
}
