package com.epam.cfc.automation.framework.common.page.quiz;

import com.epam.cfc.automation.framework.common.entity.TransportType;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.waiter.Waiting;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForInvisibilityOfElement;

public class TransportPage extends QuizPage {

    @FindBy(css = ".input-location")
    private WebElement inputLocation;

    @FindAll({@FindBy(css = ".scrollable>div>li")})
    private List<WebElement> cities;

    @FindBy(css = ".dropdown-loader")
    private WebElement dropdownLoader;

    @FindBy(css = ".location-button__start")
    private WebElement startQuizButton;

    @FindBy(css = "section.quiz-answer:nth-child(1)")
    private WebElement onFootCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(2)")
    private WebElement byBikeCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(3)")
    private WebElement byCarCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(4)")
    private WebElement byBusCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(5)")
    private WebElement bySubwayCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(6)")
    private WebElement byTrainCheckbox;

    /*public TransportPage chooseCity(String city) {
        try {
            waitForElementVisible(inputLocation);
            inputLocation.sendKeys(city);
            for (WebElement element : cities) {
                if (element.getText().contains(city))
                    js.executeScript("arguments[0].click();", element);
            }
            startQuizButton.click();
        } catch (TimeoutException | ElementNotInteractableException | NullPointerException e) {
            System.out.println("You have already chosen the city");
        }
        finally {
            return this;
        }
    }*/

    public TransportPage tickOnFoot() {
        LoggerUtil.LOGGER.info("Clicking 'on foot' section");
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        onFootCheckbox.click();
        setTransport(TransportType.FOOT, true);
        return this;
    }

    public TransportPage tickByBike() {
        Waiting.waitForElementEnabled(byBikeCheckbox);
        LoggerUtil.LOGGER.info("Clicking 'by bike' section");
        if (loader.isDisplayed()) waitForInvisibilityOfElement(loader);
        byBikeCheckbox.click();
        setTransport(TransportType.BIKE, true);
        return this;
    }

    public TransportPage tickByCar() {
        LoggerUtil.LOGGER.info("Clicking 'by car' section");
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        byCarCheckbox.click();
        setTransport(TransportType.CAR, true);
        return this;
    }

    public TransportPage tickByBus() {
        LoggerUtil.LOGGER.info("Clicking 'by bus' section");
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        byBusCheckbox.click();
        setTransport(TransportType.BUS, true);
        return this;
    }

    public TransportPage tickBySubway() {
        LoggerUtil.LOGGER.info("Clicking 'by subway' section");
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        bySubwayCheckbox.click();
        setTransport(TransportType.SUBWAY, true);
        return this;
    }

    public TransportPage tickByTrain() {
        LoggerUtil.LOGGER.info("Clicking 'by train' section");
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        byTrainCheckbox.click();
        setTransport(TransportType.TRAIN, true);
        return this;
    }

    public QuizPage goToNextQuestion() {
        Map<TransportType, Boolean> chosenTransport = QuizPage.getTransport();
        List<TransportType> publicTransport = new ArrayList<TransportType>() {{
            add(TransportType.BUS);
            add(TransportType.SUBWAY);
            add(TransportType.TRAIN);
        }};
        clickNext();
        if (chosenTransport.get(TransportType.CAR))
            return new FuelPage();
        else {
            if (chosenTransport.entrySet()
                    .stream()
                    .filter(Map.Entry::getValue)
                    .collect(Collectors.toList())
                    .containsAll(publicTransport))
                return new TimeOfJourneyPage();
            else
                return new FoodPage();
        }
    }
}
