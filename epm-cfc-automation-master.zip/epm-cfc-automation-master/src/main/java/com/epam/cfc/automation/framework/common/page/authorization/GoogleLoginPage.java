package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.waiter.Waiting;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GoogleLoginPage extends ServicePage {

    @FindBy(css = "input[type='email']")
    private WebElement loginInput;

    @FindBy(id = "passwordNext")
    private WebElement submitButton;

    @FindBy(id = "identifierNext")
    private WebElement nextButton;

    @FindBy(name = "password")
    private WebElement passwordInput;

    public GoogleLoginPage(){
        DriverFactory.getThreadDriver().switchTo().defaultContent();
    }

    public GoogleLoginPage fillLogin(User user) {
        LoggerUtil.LOGGER.info("Filling the email field(gmail)");
        loginInput.sendKeys(user.getLogin());
        return this;
    }

    public GoogleLoginPage fillPassword(User user) {
        Waiting.waitForElementVisible(passwordInput);
        LoggerUtil.LOGGER.info("Filling the password field(gmail)");
        passwordInput.sendKeys(user.getPassword());
        return this;
    }

    public GoogleLoginPage clickNext() {
        nextButton.click();
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(gmail)");
        submitButton.click();
        return new StartPage();
    }

    public void waitForTitle() {
        Waiting.waitForTitleIs();
    }

}
