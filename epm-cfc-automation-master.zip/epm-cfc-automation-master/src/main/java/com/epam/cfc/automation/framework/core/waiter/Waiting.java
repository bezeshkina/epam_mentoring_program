package com.epam.cfc.automation.framework.core.waiter;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waiting {

    private static final String TIMEOUT_EXCEPTION_WAS_IGNORED_MESSAGE = "A timeout exception was ignored ";
    private static final String BASE_PAGE_TITLE = "Carbon Footprint Calculator";

    private Waiting() {
    }

    public static void waitForElementVisible(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element '" + element + "' visible");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), Timeout.QUICK.getSeconds()).until(ExpectedConditions.visibilityOf(element));
        } catch (TimeoutException | ElementNotVisibleException e) {
            LoggerUtil.LOGGER.info(TIMEOUT_EXCEPTION_WAS_IGNORED_MESSAGE + e.getMessage());
        }
    }

    public static void waitForElementEnabled(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element'" + element + "' enable");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), Timeout.NORMAL.getSeconds()).until(ExpectedConditions.elementToBeClickable(element));
        } catch (TimeoutException | ElementClickInterceptedException e) {
            LoggerUtil.LOGGER.info(TIMEOUT_EXCEPTION_WAS_IGNORED_MESSAGE + e.getMessage());
        }
    }

    public static WebElement waitForElement(WebElement element) {
        LoggerUtil.LOGGER.debug(" Waiting for element'" + element + "' clickable");
        new WebDriverWait(DriverFactory.getThreadDriver(), Timeout.NORMAL.getSeconds()).until(ExpectedConditions.elementToBeClickable(element));
        return element;
    }

    public static void waitForTitleIs() {
        LoggerUtil.LOGGER.debug("Waiting for title is " + BASE_PAGE_TITLE);
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), Timeout.SLOW.getSeconds()).until(ExpectedConditions.titleContains(BASE_PAGE_TITLE));
        } catch (TimeoutException e) {
            LoggerUtil.LOGGER.info(TIMEOUT_EXCEPTION_WAS_IGNORED_MESSAGE + e.getMessage());
        }
    }

    public static void waitForInvisibilityOfElement(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element is disappeared");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), Timeout.MEDIUM.getSeconds()).until(ExpectedConditions.invisibilityOf(element));
        } catch (TimeoutException | ElementNotVisibleException | NoSuchElementException e) {
            LoggerUtil.LOGGER.info(TIMEOUT_EXCEPTION_WAS_IGNORED_MESSAGE + e.getMessage());
        }
    }

    public static void waitAndClick(WebElement element) {
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), Timeout.MEDIUM.getSeconds())
                    .until(ExpectedConditions.elementToBeClickable(element))
                    .click();
        } catch (TimeoutException | ElementNotVisibleException | NoSuchElementException | ElementClickInterceptedException e) {
            LoggerUtil.LOGGER.debug(TIMEOUT_EXCEPTION_WAS_IGNORED_MESSAGE + e.getMessage());
        }
    }

    public static void sleep(int sec) {
        try {
            LoggerUtil.LOGGER.debug("Waiting for [{}] sec", sec);
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            LoggerUtil.LOGGER.info(e.getMessage());
        }
    }
}
