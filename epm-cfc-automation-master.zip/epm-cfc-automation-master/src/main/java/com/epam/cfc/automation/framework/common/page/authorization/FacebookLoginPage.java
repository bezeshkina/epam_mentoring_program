package com.epam.cfc.automation.framework.common.page.authorization;

import com.epam.cfc.automation.framework.common.page.StartPage;
import com.epam.cfc.automation.framework.config.data.User;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForElementEnabled;
import static com.epam.cfc.automation.framework.core.waiter.Waiting.waitForTitleIs;

public class FacebookLoginPage extends ServicePage {

    @FindBy(xpath = "//input[@id='email']")
    private WebElement fbLoginInput;

    @FindBy(xpath = "//input[@id='pass']")
    private WebElement fbPwdInput;

    @FindBy(xpath = "//button[@id='loginbutton']")
    private WebElement fbLoginBtn;

    public FacebookLoginPage() {
        LoggerUtil.LOGGER.info("Facebook login psge was opened");
        waitForElementEnabled(fbLoginBtn);
    }

    public FacebookLoginPage fillLogin(User user) {
        LoggerUtil.LOGGER.info("Filling the email field(facebook)");
        fbLoginInput.sendKeys(user.getLogin());
        return this;
    }

    public FacebookLoginPage fillPassword(User user) {
        LoggerUtil.LOGGER.info("Filling the password field(facebook)");
        fbPwdInput.sendKeys(user.getPassword());
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(facebook)");
        fbLoginBtn.click();
        waitForTitleIs();
        LoggerUtil.LOGGER.info("Start page is opened");
        return new StartPage();
    }

}
