import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MailTest extends Base {

    private By nextBtn = By.xpath("//span[text()='Далее']");
    private By usnameField = By.xpath("//input[@id='identifierId']");
    private By passwordField = By.xpath("//input[@type='password']");
    private By createBtn = By.xpath("//div[text()='Написать']");
    private By addresseeField = By.xpath("//textarea[@aria-label='Кому']");
    private By subjectField = By.xpath("//input[@name='subjectbox']");
    private By mailTextField = By.xpath("//div[@aria-label='Тело письма']");
    private By closeBtn = By.xpath("//img[@data-tooltip='Сохранить и закрыть']");
    private By draftCategoryBtn = By.xpath("//a[@title='Черновики']");
    private By sendBtn = By.cssSelector(".gU.Up>div>div:nth-child(2)");
    private By sentCategoryBtn = By.cssSelector(".TN.bzz.aHS-bnu>div:nth-child(2)>span>a");
    private By checkboxBtn = By.xpath("(//*[@class='bzn']//span[@role='checkbox'])[last()]");
    private By deleteBtn = By.xpath("//div[@gh='mtb']//div[@act='10']/div");
    private By accountBtn = By.xpath("//a[@class='gb_b gb_hb gb_R']");
    private By logOffBtn = By.xpath("//a[@id='gb_71']");
    private By subjectTextField = By.xpath("//input[@name='subject']");
    private By addresseeTextField = By.cssSelector(".aoD.hl>div:nth-child(1)>span");
    private By textAreaField = By.cssSelector(".Ar.Au>div");
    private By mailIsSentMsg = By.xpath("//span[text()='Письмо отправлено.']");
    private By emails = By.xpath("//span[@class='bog']");
    private String addresseeText;
    private String textAreaText;
    private String subjText;
    private WebElement email;
    private WebElement sentEmail;

    @BeforeTest(description = "Login to the mail box")
    public void login() {
        sendKeysToElement(usnameField, login);
        clickToWebElement(nextBtn);
        sendKeysToElement(passwordField, pwd);
        clickToWebElement(nextBtn);
        //Assert, that the login is successful
        Assert.assertTrue(driver.findElement(createBtn).isDisplayed(), "Login unsuccessful");
    }

    @Test(description = "end-to-end test")
    public void createMailTest() throws InterruptedException {
        //Create a new mail (fill addressee, subject and body fields)
        clickToWebElement(createBtn);
        sendKeysToElement(addresseeField, addressee);
        sendKeysToElement(subjectField, subject);
        sendKeysToElement(mailTextField, textArea);
        clickToWebElement(closeBtn);
        //Save the mail as a draft
        clickToWebElement(draftCategoryBtn);
        //Verify, that the mail presents in ‘Drafts’ folder
        //Thread.sleep(4000);
        email = findElementInList(emails, subject, "Черновики");
        clickToWebElement(email);
        addresseeText = driver.findElement(addresseeTextField).getText();
        textAreaText = driver.findElement(textAreaField).getText();
        subjText = driver.findElement(subjectTextField).getAttribute("value");
        //Verify the draft content (addressee, subject and body – should be the same as in 3)
        Assert.assertEquals(addresseeText, addressee, "Addressee doesn't match");
        Assert.assertEquals(textAreaText, textArea, "Text in text-area doesn't match");
        Assert.assertEquals(subjText, subject, "Subject doesn't match");
        //Send the mail
        clickToWebElement(sendBtn);
        //Verify, that the mail disappeared from ‘Drafts’ folder
        Assert.assertTrue(elementIsVisible(mailIsSentMsg), "Email hasn't been sent");
        clickToWebElement(sentCategoryBtn);
        //Verify, that the mail is in ‘Sent’ folder
        sentEmail = findElementInList(emails, subject, "Отправленные");
        clickToWebElement(accountBtn);
        //Log off
        clickToWebElement(logOffBtn);
    }
}
