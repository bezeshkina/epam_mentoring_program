import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class Base extends SetUp {
    List<WebElement> elements;

    protected void clickToWebElement(By by) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(by)).click();

        } catch (StaleElementReferenceException e) {
            wait.until(ExpectedConditions.elementToBeClickable(by)).click();
        }
    }

    protected void clickToWebElement(WebElement element) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(element)).click();

        } catch (StaleElementReferenceException e) {
            wait.until(ExpectedConditions.elementToBeClickable(element)).click();
        }
    }

    protected void sendKeysToElement(By by, String text) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(by)).sendKeys(text);
        } catch (StaleElementReferenceException e) {
            wait.until(ExpectedConditions.elementToBeClickable(by)).sendKeys(text);
        }
    }

    protected boolean elementIsVisible(By by) {
        return driver.findElement(by).isEnabled();
    }

    protected WebElement findElementInList(By by, String text, String title) {
        new WebDriverWait(driver, 10).until(ExpectedConditions.titleContains(title));
        new WebDriverWait(driver, 10).until(ExpectedConditions.numberOfElementsToBeMoreThan(by, 1));
        elements = driver.findElements(by);
        for (WebElement element : elements) {
            String findText = element.getText();
            if (findText.contains(text))
                return element;
        }

        throw new AssertionError("Element isn't found");
    }
}
