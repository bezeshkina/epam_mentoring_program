package tests;

import com.epam.tat.module4.Calculator;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;


public class BaseTest {
    protected Calculator calculator;

    @BeforeMethod(groups = {"simpleTest"})
    public void setUp(){
        calculator = new Calculator();
    }

    @AfterMethod(groups = {"simpleTest"})
    public void tearDown() {
        calculator = null;
    }

    @BeforeMethod(groups = {"exceptionTest"})
    public void setUp1(){
        calculator = new Calculator();
    }

    @AfterMethod(groups = {"exceptionTest"})
    public void tearDown1() {
        calculator = null;
    }

    @BeforeMethod(groups = {"trigonometricTest"})
    public void setUp2(){
        calculator = new Calculator();
    }

    @AfterMethod(groups = {"trigonometricTest"})
    public void tearDown2() {
        calculator = null;
    }
}
