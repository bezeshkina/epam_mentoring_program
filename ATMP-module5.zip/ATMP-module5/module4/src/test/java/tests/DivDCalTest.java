package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DivDCalTest extends BaseTest {
    @Test(dataProvider = "valuesForTest", groups = {"simpleTest"})
    public void divDoubleCalTest(double a, double b, double expectedResult){
        Assert.assertEquals(calculator.div(a, b), expectedResult, "Invalid result of operation");
    }

    @DataProvider(name = "valuesForTest")
    public Object[][] valuesForTest (){
        return new Object[][]{
                {12.11, 1.0, 12.11},
                {-1.1, 1.1, -1.0},
                {0.0, 4.111, 0.0},
                {2.1, -0.01, -210.0}
        };
    }
}
