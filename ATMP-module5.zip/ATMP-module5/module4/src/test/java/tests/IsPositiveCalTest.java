package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class IsPositiveCalTest extends BaseTest {
    @Test(groups = {"simpleTest"})
    public void isPositiveCalTest(){
        Assert.assertTrue(calculator.isPositive(4));
    }

    @Test(groups = {"simpleTest"})
    public void isPositiveZeroCalTest(){
        Assert.assertFalse(calculator.isPositive(0));
    }
}
