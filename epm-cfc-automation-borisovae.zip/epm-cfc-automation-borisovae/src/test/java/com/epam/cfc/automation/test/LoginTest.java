package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.bo.Services;
import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.util.services.LogIn;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.testng.Assert;
import org.testng.annotations.*;

//@Listeners(ListenerTest.class)
public class LoginTest extends BaseTest {

    @Parameters("mService")
    @Test(description = "Login test")
    public void loginViaService(Services mService) {
        StartPage startPage = new StartPage();
        startPage.open().openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        LoggerUtil.LOGGER.info("Asserting that title is 'Carbon Footprint Calculator'");
        Assert.assertEquals(startPage.getTitle(), "Carbon Footprint Calculator", "User doesn't signed in in " + mService.toString());
    }
}
