package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.testng.annotations.*;

class BaseTest {

    @AfterMethod(description = "Browser is quited after method")
    public static void dismissBrowser() {
        LoggerUtil.LOGGER.info("Browser quits after method");
        DriverFactory.driverQuit();
    }

    @AfterSuite(description = "Browser is quited after suite")
    public static void quitBrowser() {
        LoggerUtil.LOGGER.info("Browser quits after suite");
        DriverFactory.driverQuit();
    }
}
