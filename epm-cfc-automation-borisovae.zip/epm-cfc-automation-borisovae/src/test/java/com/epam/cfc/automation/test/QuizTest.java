package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.bo.Services;
import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.common.pages.quiz.*;
import com.epam.cfc.automation.framework.core.util.DBConnection;
import com.epam.cfc.automation.framework.core.util.services.LogIn;
import org.testng.Assert;
import org.testng.annotations.*;

//@Listeners(ListenerTest.class)
public class QuizTest extends BaseTest {
    @Parameters({"mService"})
    @Test(description = "Test with parameters: By car, on foot, gasoline, balanced, all pets, 320 kWh")
    public void quizTest3(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByCar()
                .tickOnFoot()
                .goToNextQuestion();
        new FuelPage()
                .setGasoline()
                .clickNext();
        new TimeOfJourneyPage()
                .setTimeOfCarJourney(50)
                .clickNext();
        new FoodPage()
                .chooseBalanced()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .clickOtherSection()
                .setSnakesAndSpidersCount(5)
                .setDogsCount(9)
                .setCatsCount(1)
                .setRodentCount(8)
                .setAquariumFishCount(9)
                .setParrotsCount(3)
                .setRabbitsCount(2)
                .setLizardsCount(1)
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(320)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Parameters({"mService"})
    @Test(description = "Test with parameters: On foot, by bus, vegan, 2 dogs, 150 kWh")
    public void quizTest1(Services mService) {
        StartPage startPage = new StartPage();
        startPage.open();
        DBConnection.removeUserConnection(mService);
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickOnFoot()
                .tickByBike()
                .goToNextQuestion();
        new FoodPage()
                .chooseVegan()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .setDogsCount(10)
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(150)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Parameters({"mService"})
    @Test(description = "Test with parameters: By bike, by car, diesel, vegetarian, 1 cat, 250 kWh")
    public void quizTest2(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByBike()
                .tickByCar()
                .goToNextQuestion();
        new FuelPage()
                .setHybrid()
                .clickNext();
        new TimeOfJourneyPage()
                .setTimeOfCarJourney(35)
                .clickNext();
        new FoodPage()
                .chooseVegetarian()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .setCatsCount(1)
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(910)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Parameters({"mService"})
    @Test(description = "Test with parameters: On foot, by subway, balanced, 4 rodents, 130 kWh")
    public void quizTest4(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByBus()
                .tickBySubway()
                .tickByTrain()
                .tickOnFoot()
                .goToNextQuestion();
        new TimeOfJourneyPage()
                .setTimeOfBusJourney(10)
                .setTimeOfTrainJourney(120)
                .setTimeOfSubwayJourney(70)
                .clickNext();
        new FoodPage()
                .chooseFastFood()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .setRodentCount(4)
                .clickOtherSection()
                .setAquariumFishCount(9)
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(630)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Parameters({"mService"})
    @Test(description = "Test with parameters: By bike, vegetarian, 3 cats, 2 dogs, 520 kWh")
    public void quizTest5(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByCar()
                .tickOnFoot()
                .tickByTrain()
                .tickBySubway()
                .tickByBus()
                .goToNextQuestion();
        new FuelPage()
                .setDiesel()
                .clickNext();
        new TimeOfJourneyPage()
                .setTimeOfCarJourney(10)
                .setTimeOfTrainJourney(120)
                .setTimeOfSubwayJourney(60)
                .setTimeOfBusJourney(45)
                .clickNext();
        new FoodPage()
                .chooseVegan()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .setCatsCount(0)
                .setDogsCount(9)
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(90)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Parameters({"mService"})
    @Test(description = "Test with parameters: By car, gasoline, vegan, 7 fishes, 440 kWh")
    public void quizTest6(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByCar()
                .tickByBus()
                .goToNextQuestion();
        new FuelPage()
                .setGasoline()
                .clickNext();
        new TimeOfJourneyPage()
                .setTimeOfCarJourney(15)
                .setTimeOfBusJourney(50)
                .clickNext();
        new FoodPage()
                .chooseVegetarian()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .clickOtherSection()
                .setAquariumFishCount(7)
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(440)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Parameters({"mService"})
    @Test(description = "Test with parameters: by foot, fast food, 5 dogs, 720 kWh")
    public void quizTest7(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickOnFoot()
                .goToNextQuestion();
        new FoodPage()
                .chooseFastFood()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .setDogsCount(5)
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(720)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    //---- couldn't found test cases. Have to write their

    @Parameters({"mService"})
    @Test(description = "Open quiz by calculate button")
    public void calculateButtonTest(Services mService){
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        new StartPage().scrollToGlobePage();
        new StartPage().clickToCalculate();
        Assert.assertTrue(new TransportPage().quizIsOpened(), "Quiz isn't opened");
    }

    @Parameters({"mService"})
    @Test(description = "Start button is enabled after quiz skipping")
    public void startButtonAvailabilityTest(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByCar()
                .tickByBus()
                .goToNextQuestion();
        new FuelPage()
                .setGasoline()
                .clickNext();
        new TimeOfJourneyPage()
                .goToHomePage();
        Assert.assertTrue(new StartPage().startButtonIsEnabled(), "Start button isn't enabled");
    }

    //----- test cases for Back and Next button

    @Parameters({"mService"})
    @Test(description = "EPMCFC-5603: Test of functional buttons (Next, Back) on Transport page")
    public void backButtonTestOnTransportPage(Services mService){
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .clickBack();
        startPage.start();
        new TransportPage()
                .checkThatNextBtnDisabled();
        new TransportPage()
                .tickByCar()
                .goToNextQuestion();
        Assert.assertTrue(new FuelPage().fuelPageIsLoaded(), "Fuel page isn't loaded");
    }

    @Parameters({"mService"})
    @Test(description = "EPMCFC-5608: Test of functional buttons (Next, Back) on Fuel page")
    public void backButtonTestOnFuelPage(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByCar()
                .goToNextQuestion();
        new FuelPage()
                .clickBack();
        new TransportPage()
                .clickNext();
        new FuelPage()
                .checkThatNextBtnDisabled();
        new FuelPage()
                .setGasoline()
                .clickNext();
        Assert.assertTrue(new TimeOfJourneyPage().timePageIsLoaded(), "Time page isn't loaded");
    }


    @Parameters({"mService"})
    @Test(description = "EPMCFC-5611: Test of functional buttons (Next, Back) on Time page")
    public void backButtonTestOnTimePage(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByBus()
                .goToNextQuestion();
        new TimeOfJourneyPage()
                .clickBack();
        new TransportPage()
                .clickNext();
        new TimeOfJourneyPage()
                .setTimeOfBusJourney(60)
                .clickNext();
        Assert.assertTrue(new FoodPage().foodPageIsLoaded(), "Food page isn't loaded");
    }

    @Parameters({"mService"})
    @Test(description = "EPMCFC-5616: Test of functional buttons (Next, Back) on Food page")
    public void backButtonTestOnFoodPage(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByBus()
                .tickOnFoot()
                .goToNextQuestion();
        new TimeOfJourneyPage()
                .setTimeOfBusJourney(150)
                .clickNext();
        new FoodPage()
                .clickBack();
        new TimeOfJourneyPage()
                .clickNext();
        new FoodPage()
                .checkThatNextBtnDisabled();
        new FoodPage()
                .chooseBalanced()
                .clickNext();
        Assert.assertTrue(new PetsPage().petsPageIsLoaded(), "Food page isn't loaded");
    }

    @Parameters({"mService"})
    @Test(description = "EPMCFC-5619: Test of functional buttons (Next, Back) on Pets page")
    public void backButtonTestOnPetsPage(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByBus()
                .tickOnFoot()
                .goToNextQuestion();
        new TimeOfJourneyPage()
                .setTimeOfBusJourney(150)
                .clickNext();
        new FoodPage()
                .chooseBalanced()
                .clickNext();
        new PetsPage()
                .clickBack();
        new FoodPage()
                .clickNext();
        new PetsPage()
                .clickNext();
        Assert.assertTrue(new ElectricityPage().electricityPageIsLoaded(), "Electricity page isn't loaded");
    }

    @Parameters({"mService"})
    @Test(description = "EPMCFC-5616: Test of functional buttons (Next, Back) on Electricity page")
    public void backButtonTestOnElectricityPage(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByBus()
                .tickOnFoot()
                .goToNextQuestion();
        new TimeOfJourneyPage()
                .setTimeOfBusJourney(150)
                .clickNext();
        new FoodPage()
                .chooseBalanced()
                .clickNext();
        new PetsPage()
                .clickNext();
        new ElectricityPage()
                .clickBack();
        new PetsPage()
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(0);
        Assert.assertTrue(new ElectricityPage().calculateBtnDisabled(), "Calculate button enabled although electricity equals 0");
    }
}
