package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.bo.Services;
import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.common.pages.quiz.*;
import com.epam.cfc.automation.framework.common.pages.subscribe.gmail.GmailHomePage;
import com.epam.cfc.automation.framework.common.pages.subscribe.gmail.GmailInboxPage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.DBConnection;
import com.epam.cfc.automation.framework.core.util.data.UserData;
import com.epam.cfc.automation.framework.core.util.mail.ClearInboxFolder;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.LogIn;
import org.testng.Assert;
import org.testng.annotations.*;

//@Listeners(ListenerTest.class)
public class GmailSubscribeTest {

    private QuizResultPage resultPage;
    private GmailInboxPage inboxPage;

    @Parameters({"mService"})
    @Test(description = "Test of subscribing from site")
    public void subscribeTest(Services mService) {
        StartPage startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open().openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        startPage.start();
        new TransportPage()
                .tickByBike()
                .goToNextQuestion();
        new FoodPage()
                .chooseVegetarian()
                .clickNext();
        new PetsPage()
                .waitForSectionVisible()
                .clickNext();
        new ElectricityPage()
                .setElectricityRange(520)
                .calculate();
        resultPage = new QuizResultPage();
        resultPage.clickSubscribe();
        resultPage.fillEmailField(new UserData().getGoogleLogin()).confirm();
        LoggerUtil.LOGGER.info("Asserting that button changes it's title to 'Unsubscribe'");
        Assert.assertTrue(resultPage.isButtonChangesToUnsubscribe());
    }

    @Test(description = "Test of unsubscribing from site", priority = 1)
    public void unsubscribeTest() {
        resultPage = new QuizResultPage();
        resultPage.clickUnsubscribe().confirm();
        LoggerUtil.LOGGER.info("Asserting that button changes it's title to 'Subscribe'");
        Assert.assertTrue(resultPage.isButtonChangesToSubscribe());
    }

    @Test(description = "Check that email for subscribers was received", priority = 2)
    public void checkEmailForSubscribers() {
        resultPage = new QuizResultPage();
        inboxPage = new GmailInboxPage();
        new GmailHomePage().openNewTab();
        new GmailHomePage().openGmail().goToInbox(new GmailHomePage().getTitle());
        inboxPage.waitForPageWillBeLoaded();
        Assert.assertTrue(inboxPage.isEmailForSubscribersReceived());
    }

    @Test(description = "Check that email for unsubscribers was received",priority = 3)
    public void checkEmailForUnsubscribers() {
        inboxPage = new GmailInboxPage();
        inboxPage.waitForPageWillBeLoaded();
        Assert.assertTrue(inboxPage.isEmailForUnsubscribersReceived());
    }

    @AfterClass(description = "Deleting emails after test set")
    public void deleteLetters() {
        ClearInboxFolder.deleteMsgs();
    }

    @AfterTest(description = "Close browser after test")
    public void dismissBrowser() {
        LoggerUtil.LOGGER.info("Browser quits after test");
        DriverFactory.driverQuit();
    }
}
