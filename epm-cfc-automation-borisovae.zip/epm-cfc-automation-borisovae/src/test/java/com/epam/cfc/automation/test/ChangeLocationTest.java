package com.epam.cfc.automation.test;

import com.epam.cfc.automation.framework.common.bo.Services;
import com.epam.cfc.automation.framework.common.pages.LocationSelectionContainer;
import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.DBConnection;
import com.epam.cfc.automation.framework.core.util.services.LogIn;
import org.testng.Assert;
import org.testng.annotations.*;

public class ChangeLocationTest {

    private StartPage startPage;
    private LocationSelectionContainer locationSelectionContainer;

    @Parameters({"mService"})
    @BeforeClass(description = "Log in to the platform")
    public void login(Services mService) {
        startPage = new StartPage();
        DBConnection.removeUserConnection(mService);
        startPage.open();
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
    }

    @Test(priority = 0, description = "Check the pop-up window for the location item [EPMCFC-5588]")
    public void usersLocationAppearsTest() {
        Assert.assertTrue(startPage.clickLocationItem().isLocationVisible());
    }

    @Test(priority = 1, description = "Check pop-up window after clicking on the 'change location' item [EPMCFC-5589]")
    public void checkPopUpWindowAppearsTest() {
        locationSelectionContainer = startPage.openChangeLocationContainer();
        Assert.assertTrue(locationSelectionContainer.isContainerDisplayed());
    }

    @Test(priority = 2, description = "Check putting of the city into the search bar [EPMCFC-5591]")
    public void checkSearchBarTest() {
        locationSelectionContainer.inputCity("Karaganda");
        Assert.assertTrue(locationSelectionContainer.isListOfCitiesExist());
    }

    @Test(priority = 2, description = "Putting of the uncompleted value into the search bar [EPMCFC-5592]")
    public void setUncompletedValueTest() {
        locationSelectionContainer.inputCity("Karaganda, Kazakh");
        Assert.assertTrue(locationSelectionContainer.isListOfCitiesExist());
    }

    @Test(priority = 2, description = "Check putting special symbols into the search bar [EPMCFC-5600]")
    public void putSpecialSymbolsTest() {
        locationSelectionContainer.inputCity("$!/.");
        Assert.assertTrue(locationSelectionContainer.isMessageAppears());
    }

    @Test(priority = 3, description = "Putting city then after , type country [EPMCFC-5602]")
    public void putCityAndCountryTest() {
        locationSelectionContainer.inputCity("Karaganda, Kazakhstan");
        Assert.assertTrue(locationSelectionContainer.isListOfCitiesExist());
    }

    @Test(priority = 4, description = "Check the 'Save location' button [EPMCFC-5593]")
    public void saveLocationTest() {
        locationSelectionContainer
                .inputAndSelectCity("Karaganda, Kazakhstan")
                .saveLocation()
                .refresh();
        startPage.clickLocationItem();
        Assert.assertTrue(startPage.isUsersLocationKaraganda());
    }

    @Test(priority = 5, description = "Check 'Cancel' button when user puts the valid values into the search bar [EPMCFC-5595]")
    public void checkCancelButtonTest() {
        startPage.openChangeLocationContainer();
        locationSelectionContainer.inputAndSelectCity("Nizh").clickCancel();
        startPage.refresh();
        startPage.clickLocationItem();
        Assert.assertTrue(startPage.isUsersLocationKaraganda());
    }

    @Test(priority = 5, description = "Check 'Cancel' button when user hasn't put values into the search bar [EPMCFC-5594]")
    public void checkCancelTest() {
        startPage.openChangeLocationContainer();
        locationSelectionContainer.clickCancel();
        startPage.refresh();
        startPage.clickLocationItem();
        Assert.assertTrue(startPage.isUsersLocationKaraganda());
    }

    @AfterClass
    public void quitDriver() {
        DriverFactory.driverQuit();
    }
}
