package com.epam.cfc.automation.framework.common.bo;

public enum TransportType {
    FOOT,
    CAR,
    BUS,
    TRAIN,
    SUBWAY,
    BIKE
}
