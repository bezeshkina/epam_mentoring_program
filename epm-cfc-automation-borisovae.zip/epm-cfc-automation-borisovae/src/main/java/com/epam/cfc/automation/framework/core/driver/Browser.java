package com.epam.cfc.automation.framework.core.driver;

import java.util.stream.Stream;

public enum Browser {

    CHROME("chrome"),
    FIREFOX("firefox");

    private String name;

    Browser(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static Browser detect() {
        String browserProperty = System.getProperty("cfc.browser");
        return Stream.of(values())
                .filter(browser -> browser.getName().equalsIgnoreCase(browserProperty))
                .findFirst()
                .orElse(CHROME);
    }

}
