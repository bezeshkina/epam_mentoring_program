package com.epam.cfc.automation.framework.common.pages.quiz;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.Waiting;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class QuizResultPage extends QuizPage {

    @FindBy(css = ".result-diagram__container")
    private WebElement diagramOfResults;

    @FindBy(xpath = "//div[@class='button_unsubscribe-subscribe']/button")
    private WebElement subscribeButton;

    @FindBy(css = ".subscribe-modal__email-input")
    private WebElement emailInput;

    @FindBy(css = ".subscribe-modal__confirm")
    private WebElement confirmButton;

    private JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getThreadDriver();

    public Boolean resultIsPresented() {
        Waiting.waitForElementVisible(diagramOfResults);
        LoggerUtil.LOGGER.info("Asserting that quiz result is present");
        return diagramOfResults.isDisplayed();
    }

    public QuizResultPage clickSubscribe() {
        LoggerUtil.LOGGER.info("Pressing 'Subscribe' button");
        js.executeScript("arguments[0].click();", subscribeButton);
        Waiting.waitForElementVisible(emailInput);
        return this;
    }

    public QuizResultPage clickUnsubscribe() {
        LoggerUtil.LOGGER.info("Pressing 'Subscribe' button");
        js.executeScript("arguments[0].click();", subscribeButton);
        Waiting.waitForElementEnabled(confirmButton);
        return this;
    }

    public QuizResultPage confirm() {
        Waiting.waitAndClick(confirmButton);
        Waiting.waitForElementEnabled(subscribeButton);
        return this;
    }

    public QuizResultPage fillEmailField(String email) {
        LoggerUtil.LOGGER.info("Filling email: " + email);
        emailInput.clear();
        emailInput.sendKeys(email);
        Waiting.waitForElementEnabled(confirmButton);
        return this;
    }

    public boolean isButtonChangesToUnsubscribe() {
        return subscribeButton.getText().equals("Unsubscribe");
    }

    public boolean isButtonChangesToSubscribe() {
        return subscribeButton.getText().equals("Subscribe");
    }

}
