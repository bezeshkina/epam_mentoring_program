package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TwitterLoginPage extends ServicePage {

    @FindBy(id = "username_or_email")
    private WebElement usernameInput;

    @FindBy(id = "password")
    private WebElement passInput;

    @FindBy(id = "allow")
    private WebElement loginButton;

    @FindBy(id = "challenge_response")
    private WebElement telNumber;

    @FindBy(xpath = "//*[@id = 'email_challenge_submit']")
    private WebElement telSubmit;

    @FindBy(xpath = "//*[@class='clearfix field']/*[@name= 'session[username_or_email]']")
    private WebElement verifyNumber;

    @FindBy(xpath = "//*[@class='clearfix field']/*[@name= 'session[password]']")
    private WebElement verifyPassword;

    @FindBy(css = ".clearfix>.submit")
    private WebElement submitBtn;

    public TwitterLoginPage() {
        LoggerUtil.LOGGER.info("Twitter login page was opened");
    }

    public TwitterLoginPage fillLogin(String username) {
        Waiting.waitForElementEnabled(usernameInput);
        LoggerUtil.LOGGER.info("Filling the email field(twitter)");
        usernameInput.sendKeys(username);
        return this;
    }

    public TwitterLoginPage fillPassword(String pass) {
        LoggerUtil.LOGGER.info("Filling the password field(twitter)");
        passInput.sendKeys(pass);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(twitter)");
        loginButton.click();
        if (DriverFactory.getThreadDriver().getTitle().equals("Verify your identity"))
            return new TwitterUserVerification().verifyUser();
        else {
            Waiting.waitForTitleIs(new ConfigParameters().getTitleCFC());
            return new StartPage();
        }
    }

}
