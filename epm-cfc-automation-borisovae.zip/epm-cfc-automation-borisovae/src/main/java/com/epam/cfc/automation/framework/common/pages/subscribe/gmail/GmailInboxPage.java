package com.epam.cfc.automation.framework.common.pages.subscribe.gmail;

import com.epam.cfc.automation.framework.common.bo.Letter;
import com.epam.cfc.automation.framework.common.pages.BasePage;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;

public class GmailInboxPage extends BasePage {

    @FindBy(css = ".zA.zE.byw")
    private List<WebElement> letters;

    @FindBy(xpath = "//descendant::span[@name='Auto EPM-CFC Mailer'][2]")
    private List<WebElement> sendersList;

    @FindBy(xpath = "//span[@class='bog']")
    private List<WebElement> subjList;

    @FindBy(xpath = "//div[@role='checkbox']")
    private List<WebElement> btnCheckbox;

    @FindBy(xpath = "//div[@role='checkbox']")
    private WebElement checkbox;

    @FindBy(xpath = "//div[@class='T-I J-J5-Ji nX T-I-ax7 T-I-Js-Gs mA']")
    private WebElement deleteButton;

    @FindBy(xpath = "//a[@title='Gmail']/img")
    private WebElement gmailLogo;

    @FindBy(css = ".bog>.bqe")
    private List<WebElement> emails;

    //--

    @FindBy(xpath = "//span[contains(text(), 'Unsubscribers')]")
    private List<WebElement> emailForUnsubscribers;

    @FindBy(xpath = "//span[contains(text(), 'Subscribers')]")
    private List<WebElement> emailForSubscribers;

    //--

    @FindBy(xpath = "//*[@id=':2x']//tr")
    private List<WebElement> emailContainer;

    public GmailInboxPage waitForPageWillBeLoaded(){
        Waiting.waitForElementVisible(gmailLogo);
        return this;
    }

/*    public boolean isEmailForUnsubscribersReceived(){
        boolean result = true;
        for (WebElement element : emailContainer){
            if ((element.getText().contains("Unsubscribers"))&&(element.getText().contains(new CurrentTime().getCurrentTime())))
                result = true;
            else
                result = false;
        }
        return result;
    }*/

    private List<Letter> getLetterList() {
        List<Letter> results = new ArrayList<>();
        for (WebElement letter : letters) {
            String addr = letter.findElement((By.xpath(".//descendant::span[@name='Auto EPM-CFC Mailer'][2]"))).getText();
            String subj = letter.findElement((By.xpath(".//span[@class='bog']"))).getText();
            results.add(new Letter(addr, subj));
        }
        return results;
    }

    public boolean isLetterReceived(Letter letter) {
        LoggerUtil.LOGGER.info("Asserting that letter " + letter.getSubject() +" is received");
        Waiting.waitForElementVisible(letters.get(0));
        List<Letter> lettersList = getLetterList();
        boolean content = false;
        for (Letter newLetter : lettersList) {
            if (newLetter.getAddressee().equals(letter.getAddressee()) &&
                    newLetter.getSubject().equals(letter.getSubject())) {
                content = true;
                break;
            }
        }
        return content;
    }

    public boolean isEmailForSubscribersReceived(){
        LoggerUtil.LOGGER.info("Asserting that an email for subscribers is received");
        if (!emailForSubscribers.isEmpty())
            return true;
        else
            return false;
    }

    public boolean isEmailForUnsubscribersReceived(){
        LoggerUtil.LOGGER.info("Asserting that an email for unsubscribers is received");
        if (!emailForUnsubscribers.isEmpty())
            return true;
        else
            return false;
    }


    /*private int getIndexOfLetter(Letter letter) {
        int index = 0;
        List<Letter> letters = getLetterList();
        for (int i = 0; i < letters.size(); i++) {
            if (letters.get(i).getAddressee().equals(letter.getAddressee()) &&
                    letters.get(i).getSubject().equals(letter.getSubject())) {
                index = i;
            }
        }
        return index;
    }*/

    public EmailPage goToEmailForUnsubscribers(){
        for (WebElement element : emails){
            if (element.getText().contains("Unsubscribers"))
                element.click();
        }
        return new EmailPage();
    }

    public EmailPage goToEmailForSubscribers(){
        for (WebElement element : emails){
            if (element.getText().contains("Subscribers"))
                element.click();
        }
        return new EmailPage();
    }
}
