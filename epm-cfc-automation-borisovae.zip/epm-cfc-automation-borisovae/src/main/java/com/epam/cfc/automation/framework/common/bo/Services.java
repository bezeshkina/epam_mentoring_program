package com.epam.cfc.automation.framework.common.bo;

public enum Services {
    facebook,
    github,
    vk,
    twitter,
    email,
    google,
    linkedn,
    epam
}
