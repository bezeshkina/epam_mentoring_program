package com.epam.cfc.automation.framework.core.util;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.io.FileHandler;

public class Screenshoter {

    private static final String SCREENSHOTS_NAME_TPL = "target/surefire-reports/";

    public static void takeScreenshot() {
        WebDriver driver = DriverFactory.getThreadDriver();
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String screenshotName = SCREENSHOTS_NAME_TPL + System.nanoTime();
        String rp_message = "\"Screenshot saved in: {} " + screenshot.getAbsolutePath();
        File file = new File(screenshotName + ".png");
        try {
            FileHandler.copy(screenshot, file);
            LoggerUtil.log(screenshot, rp_message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
