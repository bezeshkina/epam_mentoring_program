package com.epam.cfc.automation.framework.core.util;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

public class Waiting {

    private static final int WAIT_FOR_ELEMENT_TIMEOUT_SECONDS = 60;

    public static void waitForElementVisible(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element '" + element + "' visible");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.visibilityOf(element));
        } catch (TimeoutException | ElementNotVisibleException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.visibilityOf(element));
        }
    }

    public static void waitForElementEnabled(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element'" + element + "' enable");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.elementToBeClickable(element));
        } catch (TimeoutException | ElementClickInterceptedException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.elementToBeClickable(element));
        }
    }

    public static WebElement waitForElement(WebElement element){
        LoggerUtil.LOGGER.debug(" Waiting for element'" + element + "' clickable");
        new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.elementToBeClickable(element));
        return element;
    }

    public static void waitForTitleIs(String title) {
        LoggerUtil.LOGGER.debug("Waiting for title is " + title);
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.titleContains(title));
        } catch (TimeoutException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
        }
    }

    public static void waitForInvisibilityOfElement(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element is disappeared");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.invisibilityOf(element));
        } catch (TimeoutException | ElementNotVisibleException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
        }
    }

    public static void sleep(int sec) {
        try {
            LoggerUtil.LOGGER.debug("Waiting for [{}] sec", sec);
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            LoggerUtil.LOGGER.warn(e.getMessage());
        }
    }

    public static void pause(long duration){
        Actions actions = new Actions(DriverFactory.getThreadDriver());
        LoggerUtil.LOGGER.debug("Waiting for [{}] milliseconds", duration);
        actions.pause(duration).build().perform();
    }

    public static void waitAndClick(WebElement element){
        new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS)
                .until(ExpectedConditions.elementToBeClickable(element))
                .click();
    }

    public static String getCSSValue(WebElement element, String cssValue){
        return
                new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS)
                        .until(ExpectedConditions.visibilityOf(element))
                        .getCssValue(cssValue);
    }
}
