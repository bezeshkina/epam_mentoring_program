package com.epam.cfc.automation.framework.core.util.loginFactory;

import com.epam.cfc.automation.framework.common.pages.authorization.GithubLoginPage;
import com.epam.cfc.automation.framework.core.util.data.UserData;

public class GithubLoginFactory implements Login {
    @Override
    public void logInService() {
        new GithubLoginPage()
                .fillLogin(new UserData().getGithubLogin())
                .fillPassword(new UserData().getGithubPwd())
                .submit();
    }
}
