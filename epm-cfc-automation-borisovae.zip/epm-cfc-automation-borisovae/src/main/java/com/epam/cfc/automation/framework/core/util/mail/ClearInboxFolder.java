package com.epam.cfc.automation.framework.core.util.mail;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.data.UserData;

import javax.mail.*;
import javax.mail.search.FromStringTerm;
import java.util.Properties;

public class ClearInboxFolder {
    private static Folder connectToGmail(String user, String pwd) throws MessagingException {
        String host = "imap.gmail.com";
        String port = "993";
        String protocol = "imaps";

        Properties properties = new Properties();
        properties.put("mail.store.protocol", protocol);
        properties.put("mail.imap.port", port);

        Session session = Session.getDefaultInstance(properties);

        Store store = session.getStore(protocol);
        store.connect(host, user, pwd);

        Folder folder = store.getFolder("INBOX");

        if (!folder.exists()) {
            System.out.println("inbox not found");
            System.exit(0);
        } else
            folder.open(Folder.READ_WRITE);

        return folder;
    }

    private static Message[] getMsgs() throws MessagingException {
        String user = new UserData().getGoogleLogin();
        String pwd = new UserData().getGooglePwd();
        Folder inboxFolder = connectToGmail(user, pwd);

        String pattern = "Auto_EPM-CFC_Mailer@epam.com";
        Message[] messages = inboxFolder.search(new FromStringTerm(pattern));

        return messages;
    }

    public static void deleteMsgs() {
        LoggerUtil.LOGGER.info("Clearing inbox folder");
        Message[] messages = new Message[0];
        try {
            messages = getMsgs();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        for (Message message : messages){
            try {
                message.setFlag(Flags.Flag.DELETED, true);
            } catch (MessagingException e) {
                e.printStackTrace();
            }
        }
        LoggerUtil.LOGGER.info("Inbox folder was cleared");
    }
}
