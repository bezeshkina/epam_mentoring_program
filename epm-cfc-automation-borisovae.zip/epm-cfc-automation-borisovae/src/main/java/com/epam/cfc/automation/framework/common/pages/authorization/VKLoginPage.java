package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.util.Waiting.waitForTitleIs;

public class VKLoginPage extends ServicePage {

    @FindBy(name = "email")
    private WebElement emailField;

    @FindBy(name = "pass")
    private WebElement passwordField;

    @FindBy(css = "#install_allow")
    private WebElement submitBtn;

    public VKLoginPage(){
        LoggerUtil.LOGGER.info("Vkontakte login page was opened");
    }

    public VKLoginPage fillLogin(String email) {
        Waiting.waitForElementVisible(emailField);
        LoggerUtil.LOGGER.info("Filling the email field(VK)");
        emailField.sendKeys(email);
        return this;
    }

    public VKLoginPage fillPassword(String pwd) {
        LoggerUtil.LOGGER.info("Filling the password field(VK)");
        passwordField.sendKeys(pwd);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(VK)");
        submitBtn.click();
        waitForTitleIs(new ConfigParameters().getTitleCFC());
        return new StartPage();
    }
}
