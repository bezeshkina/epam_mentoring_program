package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.common.pages.subscribe.gmail.GmailInboxPage;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class GoogleLoginPage extends ServicePage {

    @FindBy(css = "input[type='email']")
    private WebElement loginInput;

    @FindBy(id = "passwordNext")
    private WebElement submitButton;

    @FindBy(id = "identifierNext")
    private WebElement nextButton;

    @FindBy(name = "password")
    private WebElement passwordInput;

    public GoogleLoginPage(){
        DriverFactory.getThreadDriver().switchTo().defaultContent();
    }

    public GoogleLoginPage(List<String > handlers){
        DriverFactory.getThreadDriver().switchTo().defaultContent().switchTo().window(handlers.get(2));
    }

    public GoogleLoginPage fillLogin(String username) {
        LoggerUtil.LOGGER.info("Filling the email field(gmail)");
        loginInput.sendKeys(username);
        return this;
    }

    public GoogleLoginPage fillPassword(String pass) {
        Waiting.waitForElementVisible(passwordInput);
        LoggerUtil.LOGGER.info("Filling the password field(gmail)");
        passwordInput.sendKeys(pass);
        return this;
    }

    public GoogleLoginPage clickNext() {
        nextButton.click();
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(gmail)");
        submitButton.click();
        return new StartPage();
    }

    public void waitForTitle() {
        Waiting.waitForTitleIs(new ConfigParameters().getTitleCFC());
    }

    public GmailInboxPage goToInboxPage(){
        LoggerUtil.LOGGER.info("Clicking the login button(gmail)");
        submitButton.click();
        return new GmailInboxPage();
    }

}
