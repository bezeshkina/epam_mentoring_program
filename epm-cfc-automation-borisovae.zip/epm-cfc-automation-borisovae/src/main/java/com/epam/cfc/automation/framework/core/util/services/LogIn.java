package com.epam.cfc.automation.framework.core.util.services;


import com.epam.cfc.automation.framework.common.bo.Services;
import com.epam.cfc.automation.framework.core.util.loginFactory.LoginFactory;

public class LogIn {

    public void loginInService(Services service){
        new LoginFactory().chooseService(service).logInService();
    }
}
