package com.epam.cfc.automation.framework.core.driver;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URI;

public class FirefoxDriverManager extends DriverManager {

    @Override
    protected WebDriver createDriver() {
        WebDriver driver = null;
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setBrowserName("firefox");
        capabilities.setVersion("67.0");
        capabilities.setCapability("enableVNC", true);
        capabilities.setCapability("enableVideo", false);
        capabilities.setCapability("acceptInsecureCerts",true);

        try {
            driver = new RemoteWebDriver(
                    URI.create(new ConfigParameters().getSelenoidHub()).toURL(),
                    capabilities
            );
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        LoggerUtil.LOGGER.info("Mozilla Firefox browser starts up");
        return driver;
    }

}
