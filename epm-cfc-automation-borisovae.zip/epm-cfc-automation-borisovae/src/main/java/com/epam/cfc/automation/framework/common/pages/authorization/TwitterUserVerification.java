package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.BasePage;
import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import com.epam.cfc.automation.framework.core.util.data.UserData;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.util.Waiting.waitForTitleIs;

class TwitterUserVerification extends BasePage {

    private String tel = new UserData().getTwitterTelForVerifying();

    @FindBy(id = "challenge_response")
    private WebElement telNumField;

    @FindBy(xpath = "//*[@id = 'email_challenge_submit']")
    private WebElement submitBtn;

    @FindBy(xpath = "//*[@class='clearfix field']/*[@name= 'session[username_or_email]']")
    private WebElement verifyNumField;

    @FindBy(xpath = "//*[@class='clearfix field']/*[@name= 'session[password]']")
    private WebElement passField;

    @FindBy(css = ".clearfix>.submit")
    private WebElement verifyBtn;

    public StartPage verifyUser() {
        if (telNumField.isEnabled()) {
            LoggerUtil.LOGGER.debug("Verifying user's telephone number process");
            telNumField.sendKeys(tel);
            submitBtn.click();
            waitForTitleIs(new ConfigParameters().getTitleCFC());
            return new StartPage();
        } else {
            LoggerUtil.LOGGER.debug("Verifying user process: strong verification");
            verifyNumField.sendKeys(tel);
            passField.sendKeys(new UserData().getTwitterPwd());
            verifyBtn.click();
            telNumField.sendKeys(tel);
            submitBtn.click();
            waitForTitleIs(new ConfigParameters().getTitleCFC());
            return new StartPage();
        }
    }
}
