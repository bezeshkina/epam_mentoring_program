package com.epam.cfc.automation.framework.common.pages.subscribe.gmail;

import com.epam.cfc.automation.framework.common.pages.BasePage;
import com.epam.cfc.automation.framework.common.pages.authorization.GoogleLoginPage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import com.epam.cfc.automation.framework.core.util.data.UserData;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.*;

public class GmailHomePage extends BasePage {

    @FindBy(xpath = "//div[@class=\"h-c-header__cta\"]//li[@data-ng-click=\"ctrl.trackEvent_('sign in', 'ab experiment', 'nav')\"]/a[@class=\"h-c-header__nav-li-link \"]")
    private WebElement signInButton;

    public GoogleLoginPage clickSignIn() {
        LoggerUtil.LOGGER.info("Clicking sign in button on GmailHomePage");
        signInButton.click();
        return new GoogleLoginPage();
    }

    public void openNewTab() {
        JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getThreadDriver();
        js.executeScript("window.open('about:blank','_blank');");
        String subWindowHandler = null;
        Set<String> handles = DriverFactory.getThreadDriver().getWindowHandles();
        for (String handle : handles) {
            subWindowHandler = handle;
        }
        DriverFactory.getThreadDriver().switchTo().window(subWindowHandler);
    }

    public GmailHomePage openGmail() {
        DriverFactory.getThreadDriver().get(new ConfigParameters().getGmailUrl());
        LoggerUtil.LOGGER.info("Gmail page is opening");
        DriverFactory.getThreadDriver().navigate().refresh();
        return this;
    }

    public GmailInboxPage goToInbox(String title) {
        switch (title){
            case "Gmail – электронная почта и бесплатное хранилище от Google": //Gmail - Free Storage and Email from Google
                clickSignIn();
                int countOfWindows = 3;
                boolean isChildWindowOpen = new WebDriverWait(DriverFactory.getThreadDriver(), 60).until(ExpectedConditions.numberOfWindowsToBe(countOfWindows));
                List<String> handles = Collections.emptyList();
                if (isChildWindowOpen) {
                    handles = new ArrayList<>(DriverFactory.getThreadDriver().getWindowHandles());
                }
                new GoogleLoginPage(handles)
                        .fillLogin(new UserData().getGoogleLogin())
                        .clickNext()
                        .fillPassword(new UserData().getGooglePwd())
                        .goToInboxPage();
                return new GmailInboxPage();
            case "Gmail":
                return
                        new GoogleLoginPage()
                                .fillLogin(new UserData().getGoogleLogin())
                                .clickNext()
                                .fillPassword(new UserData().getGooglePwd())
                                .goToInboxPage();
            default:
                return new GmailInboxPage();
        }
    }
}
