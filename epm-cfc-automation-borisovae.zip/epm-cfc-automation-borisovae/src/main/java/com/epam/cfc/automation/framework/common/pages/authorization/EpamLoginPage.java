package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.common.pages.StartPage;

public class EpamLoginPage extends ServicePage {

    public ServicePage fillLogin(String login) {
        return null;
    }

    public ServicePage fillPassword(String password) {
        return null;
    }

    @Override
    public StartPage submit() {
        return null;
    }

}
