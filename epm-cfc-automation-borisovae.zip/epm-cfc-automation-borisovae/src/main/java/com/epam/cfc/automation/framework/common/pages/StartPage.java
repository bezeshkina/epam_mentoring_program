package com.epam.cfc.automation.framework.common.pages;

import com.epam.cfc.automation.framework.common.bo.Services;
import com.epam.cfc.automation.framework.common.pages.authorization.*;
import com.epam.cfc.automation.framework.common.pages.quiz.QuizPage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.common.pages.quiz.TransportPage;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import static com.epam.cfc.automation.framework.core.util.Waiting.*;

public class StartPage extends BasePage {

    @FindBy(css = ".login_button button")
    private WebElement loginButton;

    @FindBy(css = ".login_popup")
    private WebElement loginPopup;

    @FindBy(css = ".login_email a")
    private WebElement emailLink;

    @FindBy(css = ".button_google")
    private WebElement googleButton;

    @FindBy(css = ".button_facebook")
    private WebElement facebookButton;

    @FindBy(css = ".button_github")
    private WebElement githubButton;

    @FindBy(css = ".button_twitter")
    private WebElement twitterButton;

    @FindBy(css = ".button_vk")
    private WebElement vkButton;

    @FindBy(css = ".button_linkedin")
    private WebElement linkedInButton;

    @FindBy(css = "#big-calculate-button")
    private WebElement startButton;

    @FindBy(css = ".login_internal_login>button>span")
    private WebElement epamButton;

    @FindBy(css = ".dropbtn")
    private WebElement dropdownMenu;

    @FindBy(css = ".log-out")
    private WebElement logOut;

    @FindBy(css = ".scroll-start-container")
    private WebElement scrollStartToGlobe;

    @FindBy(css = ".scroll-globe-container")
    private WebElement scrollGlobeToFinal;

    @FindBy(css = ".reason-main>.reason-title")
    private WebElement mainReasonHeaderFinalPage;

    @FindBy(css = ".reason-main__text")
    private WebElement mainReasonTextFinalPage;

    @FindBy(css = ".reason-footer")
    private WebElement mainReasonFooterFinalPage;

    @FindBy(css = "button.header__button-calculate")
    private WebElement calculateBtn;

    private JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getThreadDriver();

    private Actions action = new Actions(DriverFactory.getThreadDriver());

    public StartPage open() {
        DriverFactory.getThreadDriver().get(new ConfigParameters().getUrl());
        LoggerUtil.LOGGER.info("Home page is loading");
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        return this;
    }

    public StartPage openLoginPopupWindow() {
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        Waiting.waitForElementEnabled(loginButton);
        if (loginButton.isEnabled()) try {
            action.click(loginButton).build().perform();
            LoggerUtil.LOGGER.info("Login pop-up was launched");
            Waiting.waitForElementEnabled(loginPopup);
            if (loginPopup.isDisplayed()) {
                LoggerUtil.LOGGER.info("Login pop-up window is opening");
                return this;
            } else
                throw new AssertionError("Login pop-up with location " + loginPopup.getLocation() + " isn't displayed" );
        } catch (TimeoutException | ElementClickInterceptedException e) {
            LoggerUtil.LOGGER.error("Element " + loginButton.getLocation() + " isn't enabled", e);
        }
        throw new AssertionError("Element " + loginButton.getLocation() + " isn't enabled");
    }

    public StartPage logout() {
        try {
            waitForInvisibilityOfElement(loader);
            LoggerUtil.LOGGER.info("User logging out");
            action
                    .moveToElement(dropdownMenu)
                    .click()
                    .moveToElement(logOut)
                    .click()
                    .build()
                    .perform();
            waitForElementEnabled(loginButton);
            return this;
        } catch (TimeoutException | NoSuchElementException e ){
            return open();
        }
    }

    public TransportPage start() {
        if (loader.isDisplayed())
            waitForInvisibilityOfElement(loader);
        waitForElementEnabled(startButton);
        startButton.click();
        LoggerUtil.LOGGER.info("Clicking on the 'Start' button");
        return new TransportPage();
    }

    public ServicePage openServicePage(Services service) {
        switch (service) {
            case linkedn:
                linkedInButton.click();
                LoggerUtil.LOGGER.info("Authorization via Linkedin was chosen");
                return new LinkedInLoginPage();
            case facebook:
                facebookButton.click();
                LoggerUtil.LOGGER.info("Authorization via Facebook was chosen");
                return new FacebookLoginPage();
            case vk:
                vkButton.click();
                LoggerUtil.LOGGER.info("Authorization via VK was chosen");
                return new VKLoginPage();
            case github:
                githubButton.click();
                LoggerUtil.LOGGER.info("Authorization via Github was chosen");
                return new GithubLoginPage();
            case epam:
                epamButton.click();
                LoggerUtil.LOGGER.info("Authorization via Epam login was chosen");
                return new EpamLoginPage();
            case twitter:
                twitterButton.click();
                LoggerUtil.LOGGER.info("Authorization via Twitter was chosen");
                return new TwitterLoginPage();
            case email:
                emailLink.click();
                LoggerUtil.LOGGER.info("Authorization via social login was chosen");
                return new EmailLoginPage();
            default:
                googleButton.click();
                LoggerUtil.LOGGER.info("Authorization via Google account was chosen");
                return new GoogleLoginPage();
        }
    }

    public void scrollToGlobePage(){
        LoggerUtil.LOGGER.info("Scrolling to Globe Page");
        waitForElement(startButton);
        waitAndClick(scrollStartToGlobe);
        new SoftAssert().assertTrue(new WebDriverWait(DriverFactory.getThreadDriver(), 60).until(ExpectedConditions.attributeContains(calculateBtn, "style", "display: block;")).booleanValue(), calculateBtn.getLocation() + " isn't displayed");
        LoggerUtil.LOGGER.debug("Calculate button is displayed");
    }

    public boolean startButtonIsEnabled(){
        if (startButton.isEnabled())
            return true;
        else
            return false;
    }

    public QuizPage clickToCalculate(){
        LoggerUtil.LOGGER.info("Clicking to Calculate button");
        js.executeScript("arguments[0].click();", calculateBtn);
        return new TransportPage();
    }

    public StartPage pageIsLoaded(){
        waitForElementVisible(startButton);
        return this;
    }
}
