package com.epam.cfc.automation.framework.common.pages.quiz;

import com.epam.cfc.automation.framework.common.bo.TransportType;
import com.epam.cfc.automation.framework.common.pages.BasePage;
import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.asserts.SoftAssert;

import java.util.HashMap;
import java.util.Map;

public abstract class QuizPage extends BasePage {

    @FindBy(css = ".quiz-button-panel__button--next")
    private WebElement nextButton;

    @FindBy(css = ".quiz-button-panel__button--back")
    private WebElement backButton;

    Actions actions = new Actions(DriverFactory.getThreadDriver());

    private static Map<TransportType, Boolean> transport;

    static {
        transport = new HashMap<TransportType, Boolean>();
        transport.put(TransportType.FOOT, false);
        transport.put(TransportType.BIKE, false);
        transport.put(TransportType.CAR, false);
        transport.put(TransportType.BUS, false);
        transport.put(TransportType.SUBWAY, false);
        transport.put(TransportType.TRAIN, false);
    }

    public static void setTransport(TransportType transportType, Boolean result){
        transport.put(transportType, result);
    }

    public static Map getTransport(){
        return transport;
    }

    public QuizPage clickNext(){
        LoggerUtil.LOGGER.info("Click Next");
        nextButton.click();
        return this;
    }

    public boolean quizIsOpened(){
        LoggerUtil.LOGGER.info("Verifying that Quiz page was loaded");
        if (nextButton.isDisplayed())
            return true;
        else
            return false;
    }

    public void clickBack(){
        LoggerUtil.LOGGER.info("Click Back");
        Waiting.waitAndClick(backButton);
    }

    public void checkThatNextBtnDisabled(){
        new SoftAssert().assertTrue(!nextButton.isEnabled(), "Next button enabled although nothing ticked");
        LoggerUtil.LOGGER.info("Nothing ticked. Next button disabled");
    }
}
