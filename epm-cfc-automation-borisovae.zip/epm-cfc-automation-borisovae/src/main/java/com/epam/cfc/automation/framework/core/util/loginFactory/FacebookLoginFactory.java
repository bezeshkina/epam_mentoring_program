package com.epam.cfc.automation.framework.core.util.loginFactory;

import com.epam.cfc.automation.framework.common.pages.authorization.FacebookLoginPage;
import com.epam.cfc.automation.framework.core.util.data.UserData;

public class FacebookLoginFactory implements Login {
    @Override
    public void logInService() {
        new FacebookLoginPage()
                .fillLogin(new UserData().getFacebookLogin())
                .fillPassword(new UserData().getFacebookPwd())
                .submit();
    }
}
