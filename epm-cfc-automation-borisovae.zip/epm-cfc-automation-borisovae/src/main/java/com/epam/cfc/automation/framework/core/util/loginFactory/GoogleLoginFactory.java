package com.epam.cfc.automation.framework.core.util.loginFactory;

import com.epam.cfc.automation.framework.common.pages.authorization.GoogleLoginPage;
import com.epam.cfc.automation.framework.core.util.data.UserData;

public class GoogleLoginFactory implements Login {
    @Override
    public void logInService() {
        GoogleLoginPage loginPage = new GoogleLoginPage();
        loginPage
                .fillLogin(new UserData().getGoogleLogin()).clickNext()
                .fillPassword(new UserData().getGooglePwd())
                .submit();
        loginPage.waitForTitle();
    }
}
