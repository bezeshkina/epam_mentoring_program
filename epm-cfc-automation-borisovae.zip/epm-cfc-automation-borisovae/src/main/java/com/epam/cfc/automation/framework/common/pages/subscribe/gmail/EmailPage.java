package com.epam.cfc.automation.framework.common.pages.subscribe.gmail;

import com.epam.cfc.automation.framework.common.pages.BasePage;
import com.epam.cfc.automation.framework.core.util.CurrentTime;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EmailPage extends BasePage {
    @FindBy(xpath = "//a[@title='Unsubscribe']")
    private WebElement unsubscribeLink;

    @FindBy(xpath = "//a[@title='Subscribe']")
    private WebElement subscribeLink;

    @FindBy(xpath = "//*[@title='Inbox']")
    private WebElement inbox;

    public String clickToUnsubscribe(){
        unsubscribeLink.click();
        return
                new CurrentTime().getCurrentTime();
    }

    public String clickToSubscribe(){
        subscribeLink.click();
        return
                new CurrentTime().getCurrentTime();
    }

    public GmailInboxPage goToInboxFolder(){
        inbox.click();
        return
                new GmailInboxPage();
    }
}
