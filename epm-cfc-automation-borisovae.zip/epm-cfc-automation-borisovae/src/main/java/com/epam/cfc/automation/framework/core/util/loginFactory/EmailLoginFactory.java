package com.epam.cfc.automation.framework.core.util.loginFactory;

import com.epam.cfc.automation.framework.common.pages.authorization.EmailLoginPage;
import com.epam.cfc.automation.framework.core.util.data.UserData;

public class EmailLoginFactory implements Login {
    @Override
    public void logInService() {
        new EmailLoginPage()
                .fillLogin(new UserData().getEmailLogin())
                .fillPassword(new UserData().getEmailPwd())
                .submit();
    }
}
