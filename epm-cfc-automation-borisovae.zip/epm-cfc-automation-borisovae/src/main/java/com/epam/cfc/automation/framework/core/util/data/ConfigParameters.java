package com.epam.cfc.automation.framework.core.util.data;

public class ConfigParameters {

    private char[] dbPassword = "12345".toCharArray();

    public String getUrl() {
        return "https://ecsc00a03b05.epam.com";
    }

    public String getProdUrl() {
        return "https://carbon.lab.epam.com";
    }

    public String getSelenoidHub() {
        return "http://ecsc00a0499a.epam.com:4444/wd/hub";
    }

    public String getDbUser() {
        return "cfc";
    }

    public String getDatabase() {
        return "test-cfc";
    }

    public char[] getDbPassword() {
        return dbPassword;
    }

    public String getKey() {
        return "employeeId";
    }

    public String getHost() {
        return "ecsc00a03b05.epam.com";
    }

    public String getYahooUrl() {
        return "https://mail.yahoo.com/";
    }

    public String getGmailUrl() {
        return "https://gmail.com";
    }

    public String getTitleCFC() {
        return "Carbon Footprint Calculator";
    }
}