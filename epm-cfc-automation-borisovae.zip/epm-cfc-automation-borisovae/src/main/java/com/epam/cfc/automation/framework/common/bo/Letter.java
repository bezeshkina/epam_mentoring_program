package com.epam.cfc.automation.framework.common.bo;

public class Letter {

    private String addressee;
    private String subject;

    public Letter(String addressee, String subject) {
        this.addressee = addressee;
        this.subject = subject;
    }

    public String getAddressee() {
        return addressee;
    }

    public void setAddressee(String addressee) {
        this.addressee = addressee;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

}
