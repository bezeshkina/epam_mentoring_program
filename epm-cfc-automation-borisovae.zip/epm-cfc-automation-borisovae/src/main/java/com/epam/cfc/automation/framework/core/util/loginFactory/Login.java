package com.epam.cfc.automation.framework.core.util.loginFactory;

public interface Login {
    void logInService();
}
