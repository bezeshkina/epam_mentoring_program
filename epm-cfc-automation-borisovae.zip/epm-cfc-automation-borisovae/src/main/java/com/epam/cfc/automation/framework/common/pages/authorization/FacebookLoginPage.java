package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.util.Waiting.*;

public class FacebookLoginPage extends ServicePage {

    @FindBy(xpath = "//input[@id='email']")
    private WebElement fbLoginInput;

    @FindBy(xpath = "//input[@id='pass']")
    private WebElement fbPwdInput;

    @FindBy(xpath = "//button[@id='loginbutton']")
    private WebElement fbLoginBtn;

    public FacebookLoginPage() {
        LoggerUtil.LOGGER.info("Facebook login psge was opened");
        waitForElementEnabled(fbLoginBtn);
    }

    public FacebookLoginPage fillLogin(String login) {
        LoggerUtil.LOGGER.info("Filling the email field(facebook)");
        fbLoginInput.sendKeys(login);
        return this;
    }

    public FacebookLoginPage fillPassword(String pwd) {
        LoggerUtil.LOGGER.info("Filling the password field(facebook)");
        fbPwdInput.sendKeys(pwd);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(facebook)");
        fbLoginBtn.click();
        //waitForInvisibilityOfElement(loader);
        waitForTitleIs("Carbon Footprint Calculator");
        LoggerUtil.LOGGER.info("Start page is opened");
        return new StartPage();
    }

}
