package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.util.Waiting.waitForTitleIs;

public class GithubLoginPage extends ServicePage {

    @FindBy(css = "#login_field")
    private WebElement loginField;

    @FindBy(css = "#password")
    private WebElement passwordField;

    @FindBy(xpath = "//input[@value='Sign in']")
    private WebElement submitBtn;

    public GithubLoginPage(){
        LoggerUtil.LOGGER.info("Github login page was opened");
    }

    public GithubLoginPage fillLogin(String login) {
        Waiting.waitForElementVisible(loginField);
        LoggerUtil.LOGGER.info("Filling the email field(github)");
        loginField.sendKeys(login);
        return this;
    }

    public GithubLoginPage fillPassword(String pwd) {
        LoggerUtil.LOGGER.info("Filling the password field(github)");
        passwordField.sendKeys(pwd);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(github)");
        submitBtn.click();
        //Waiting.waitForInvisibilityOfElement(loader);
        waitForTitleIs(new ConfigParameters().getTitleCFC());
        return new StartPage();
    }

}
