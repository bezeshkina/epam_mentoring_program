package com.epam.cfc.automation.framework.core.util.services;

import com.epam.cfc.automation.framework.common.pages.BasePage;
import com.epam.cfc.automation.framework.common.pages.StartPage;

public abstract class ServicePage extends BasePage {

    public abstract ServicePage fillLogin(String login);
    public abstract ServicePage fillPassword(String password);
    public abstract StartPage submit();
}
