package com.epam.cfc.automation.framework.common.pages.quiz;

import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.asserts.SoftAssert;

public class ElectricityPage extends QuizPage {

    @FindBy(xpath = "//range-input[@ng-model='$ctrl.electricity']//input")
    private WebElement rangeInput;

    @FindBy(xpath = "//range-input[@ng-model='$ctrl.electricity']//p[2]")
    private WebElement roomCount;

    @FindBy(xpath = "//button[@ng-click='$ctrl.submit()']")
    private WebElement calculateButton;

    @FindBy(xpath = "//div[@class='button_unsubscribe-subscribe']/button")
    private WebElement subscribeButton;

    @FindBy(css = ".quiz__question.quiz__question--title")
    private WebElement quizQuestion;

    private SoftAssert softAssert = new SoftAssert();

    private int offsetX = 0;
    private int zeroValue = 500;
    private double stepUp = 0.5;
    private double stepDown = -0.5;

    public ElectricityPage setElectricityRange(int kWh){
        if (kWh < zeroValue)
            offsetX = (int) ((zeroValue - kWh) * stepDown);
        else
        if (kWh > zeroValue)
            offsetX = (int) ((kWh - zeroValue) * stepUp);
        LoggerUtil.LOGGER.info("Setting the electricity range to: " + kWh);
        actions.pause(500)
                .clickAndHold(rangeInput)
                .moveByOffset(offsetX, -153)
                .click()
                .build()
                .perform();
        softAssert.assertEquals(sortElectricity(kWh), roomCount.getText());
        return this;
    }

    private String sortElectricity(int kWh){
        if ((kWh > 0)&&(kWh <= 250))
            return "Like a 1-2 room flat";
        if ((kWh > 250)&&(kWh <= 500))
            return "Like a 2-3 room flat";
        if (kWh == 0)
            return "Shadow mode";
        if ((kWh > 500)&&(kWh <= 750))
            return "Like a 2-storey house";
        if ((kWh > 750)&&(kWh <= 1000))
            return "Like a mining farm";
        throw new AssertionError("The value entered is not valid.");
    }

    public QuizResultPage calculate(){
        LoggerUtil.LOGGER.info("Clicking 'calculate' button");
        calculateButton.click();
        Waiting.waitForElementEnabled(subscribeButton);
        return new QuizResultPage();
    }

    public boolean electricityPageIsLoaded() {
        if (quizQuestion.isDisplayed())
            return true;
        else
            return false;
    }

    public boolean calculateBtnDisabled() {
        if (!calculateButton.isEnabled())
            return true;
        else
            return false;
    }
}
