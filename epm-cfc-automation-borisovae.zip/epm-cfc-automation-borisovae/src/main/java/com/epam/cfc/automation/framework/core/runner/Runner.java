package com.epam.cfc.automation.framework.core.runner;

import com.beust.jcommander.internal.Lists;
import com.epam.reportportal.testng.ReportPortalTestNGListener;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.xml.XmlSuite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Runner {

    public static void main(String[] args) {
        /*TestNG testNG = new TestNG();
        testNG.addListener(new TestListenerAdapter());
        final XmlSuite suite = new XmlSuite();
        suite.setName("Main suite");
        suite.setSuiteFiles(
                new ArrayList<String>() {{
                    add("./src/test/suites/" + args[0]);
                    //add("./src/suites/" + args[1]);
                }}
        );

        testNG.setXmlSuites(new ArrayList<XmlSuite>() {{
            add(suite);
        }});

        testNG.run();*/
        ReportPortalTestNGListener listener = new ReportPortalTestNGListener();
        TestNG testNg = new TestNG();
        List<String> lSuites = new ArrayList<String>() {
            {
                add("./src/test/suites/" + args[0]);
            }};
        testNg.setTestSuites(lSuites);
        testNg.addListener((Object) listener);
        testNg.run();
    }
}
