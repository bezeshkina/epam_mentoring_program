package com.epam.cfc.automation.framework.core.util.data;

public class UserData {

    public String getFacebookLogin() {
        return "auto.tester2019";
    }

    public String getFacebookPwd() {
        return "password2019";
    }

    public String getVkLogin() {
        return "+77785822317";
    }

    public String getVkPwd() {
        return "password2019";
    }

    public String getGithubLogin() {
        return "dev-test-2019";
    }

    public String getGithubPwd() {
        return "123CFCpass";
    }

    public String getGoogleLogin() {
        return "auto.tester2019@gmail.com";
    }

    public String getGooglePwd() {
        return "password2019";
    }

    public String getTwitterLogin() {
        return "devtest26732562";
    }

    public String getTwitterPwd() {
        return "password2019";
    }

    public String getEmailLogin() {
        return "new_account_2018@bk.ru";
    }

    public String getEmailPwd() {
        return "password2019";
    }

    public String getLinkednLogin() {
        return "Auto_EPM-CFC_Testing@epam.com";
    }

    public String getLinkednPwd() {
        return "password2019";
    }

    public String getEpamLogin() {
        return "Auto_EPM-CFC_Testing@epam.com";
    }

    public String getEpamPwd() {
        return "9ATfuXbQkqQ827z9MhZABa55U";
    }

    public String getTwitterTelForVerifying() {
        return "77785822317";
    }
}