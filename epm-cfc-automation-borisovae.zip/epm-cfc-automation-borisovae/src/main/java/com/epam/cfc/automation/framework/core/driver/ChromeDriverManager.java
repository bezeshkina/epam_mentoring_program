package com.epam.cfc.automation.framework.core.driver;

import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URI;

public class ChromeDriverManager extends DriverManager {

    public WebDriver createDriver() {
        WebDriver driver = null;
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setBrowserName("chrome");
        capabilities.setVersion("75.0");
        capabilities.setCapability("enableVNC", true);
        capabilities.setCapability("enableVideo", false);

        try {
            driver = new RemoteWebDriver(
                    URI.create(new ConfigParameters().getSelenoidHub()).toURL(),
                    capabilities
            );
        } catch (MalformedURLException e) {
            LoggerUtil.LOGGER.error(e);
        }
        LoggerUtil.LOGGER.info("Chrome browser starts up");
        return driver;
    }

}
