package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.util.Waiting;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.util.Waiting.waitForTitleIs;

public class LinkedInLoginPage extends ServicePage {

    @FindBy(id = "username")
    private WebElement usernameInput;

    @FindBy(id = "password")
    private WebElement passwordInput;

    @FindBy(css = ".btn__primary--large")
    private WebElement submitButton;

    public LinkedInLoginPage(){
        LoggerUtil.LOGGER.info("Linkedn login page was opened");
    }

    @Override
    public ServicePage fillLogin(String login) {
        LoggerUtil.LOGGER.info("Filling the email field(linkedIn)");
        usernameInput.sendKeys(login);
        return this;
    }

    @Override
    public ServicePage fillPassword(String password) {
        LoggerUtil.LOGGER.info("Filling the password field(linkedIn)");
        passwordInput.sendKeys(password);
        return this;
    }

    @Override
    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(linkedIn)");
        submitButton.click();
        Waiting.waitForInvisibilityOfElement(loader);
        waitForTitleIs(new ConfigParameters().getTitleCFC());
        return new StartPage();
    }
}
