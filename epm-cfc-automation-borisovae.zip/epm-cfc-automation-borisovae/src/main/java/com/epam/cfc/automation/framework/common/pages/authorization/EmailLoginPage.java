package com.epam.cfc.automation.framework.common.pages.authorization;

import com.epam.cfc.automation.framework.common.pages.StartPage;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.services.ServicePage;
import com.epam.cfc.automation.framework.core.util.data.ConfigParameters;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.util.Waiting.*;

public class EmailLoginPage extends ServicePage {

    @FindBy(id = "username")
    private WebElement emailInput;

    @FindBy(id = "password")
    private WebElement passInput;

    @FindBy(id = "login")
    private WebElement loginButton;

    public EmailLoginPage(){
        LoggerUtil.LOGGER.info("Social login page was opened");
    }

    public EmailLoginPage fillLogin(String username) {
        waitForElementVisible(emailInput);
        LoggerUtil.LOGGER.info("Filling the email field(social login)");
        emailInput.sendKeys(username);
        return this;
    }

    public EmailLoginPage fillPassword(String pass) {
        LoggerUtil.LOGGER.info("Filling the password field(social login)");
        passInput.sendKeys(pass);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(social login)");
        loginButton.click();
        waitForTitleIs(new ConfigParameters().getTitleCFC());
        return new StartPage().pageIsLoaded();
        //return new StartPage();
    }

}
