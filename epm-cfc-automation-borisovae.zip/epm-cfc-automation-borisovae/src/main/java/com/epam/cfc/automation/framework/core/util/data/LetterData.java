package com.epam.cfc.automation.framework.core.util.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class LetterData {

    public static Properties readProperties() {
        Properties properties = new Properties();
        InputStream inputData = null;

        try {
            inputData = new FileInputStream(new File("src/main/resources/letter.properties").getAbsoluteFile());
            properties.load(inputData);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputData != null) {
                try {
                    inputData.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return properties;
    }

    public static String getAddressee() {
        return readProperties().getProperty("addr");
    }

    public static String getSubjectForNewSubscribers() {
        return readProperties().getProperty("subjSubscribe");
    }

    public static String getSubjectForUnsubscribers() {
        return readProperties().getProperty("subjUnsubscribe");
    }

}
