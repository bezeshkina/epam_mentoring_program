package com.epam.cfc.automation.framework.core.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CurrentTime {
    private String currentTime = null;

    public String getCurrentTime(){
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HHmm");
        LocalDateTime now = LocalDateTime.now();
        currentTime = timeFormat.format(now);
        return currentTime;
    }
}
