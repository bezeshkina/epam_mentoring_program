package com.epam.cfc.automation.framework.common.pages;

import com.epam.cfc.automation.framework.core.driver.DriverFactory;
import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;
import com.epam.cfc.automation.framework.core.util.Waiting;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public abstract class BasePage {

    @FindBy(css = "#loader")
    protected WebElement loader;

    @FindBy(css = ".logo__head")
    private WebElement goHomeBtn;

    public BasePage() {
        DriverFactory.getThreadDriver();
        PageFactory.initElements(DriverFactory.getThreadDriver(), this);
    }

    public String getTitle() {
        return DriverFactory.getThreadDriver().getTitle();
    }

    public void refresh() {
        LoggerUtil.LOGGER.info("Page is refreshing");
        DriverFactory.getThreadDriver().navigate().refresh();
    }

    public StartPage goToHomePage(){
        Waiting.waitAndClick(goHomeBtn);
        return new StartPage();
    }
}
