package com.epam.cfc.automation.framework.core.util.loginFactory;

import com.epam.cfc.automation.framework.common.bo.Services;

public class LoginFactory {
    public Login chooseService(Services social) {
        switch (social) {
            case google:
                return new GoogleLoginFactory();
            case linkedn:
                return new LinkedInLoginFactory();
            case facebook:
                return new FacebookLoginFactory();
            case twitter:
                return new TwitterLoginFactory();
            case vk:
                return new VKLoginFactory();
            case github:
                return new GithubLoginFactory();
            default:
                return new EmailLoginFactory();
        }
    }
}
