package com.epam.cfc.automation.framework.common.pages.quiz;

import com.epam.cfc.automation.framework.core.util.logger.LoggerUtil;

////import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.epam.cfc.automation.framework.core.util.Waiting.waitForElementVisible;

public class FuelPage extends QuizPage {

    @FindBy(css = ".quiz-answer:nth-child(1)")
    private WebElement gasolineCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(2)")
    private WebElement dieselCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(3)")
    private WebElement hybridCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(4)")
    private WebElement electricityCheckbox;

    @FindBy(xpath = "//h2['What is the type of fuel of your car?']")
    private WebElement quizQuestion;

    ////@Step("Set type of fuel")
    public TimeOfJourneyPage setGasoline() {
        LoggerUtil.LOGGER.info("Choosing 'gasoline' section");
        gasolineCheckbox.click();
        return new TimeOfJourneyPage();
    }

    ////@Step("Set type of fuel")
    public TimeOfJourneyPage setDiesel() {
        LoggerUtil.LOGGER.info("Choosing 'diesel' section");
        dieselCheckbox.click();
        return new TimeOfJourneyPage();
    }

    ////@Step("Set type of fuel")
    public TimeOfJourneyPage setHybrid() {
        LoggerUtil.LOGGER.info("Choosing 'gasoline' section");
        hybridCheckbox.click();
        return new TimeOfJourneyPage();
    }

    ////@Step("Set type of fuel")
    public TimeOfJourneyPage setElectricity() {
        waitForElementVisible(quizQuestion);
        LoggerUtil.LOGGER.info("Choosing 'electricity' section");
        electricityCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public boolean fuelPageIsLoaded(){
        if (quizQuestion.isDisplayed())
            return true;
        else
            return false;
    }
}
