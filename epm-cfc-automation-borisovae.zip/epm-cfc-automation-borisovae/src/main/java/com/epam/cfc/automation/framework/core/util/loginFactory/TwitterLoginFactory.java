package com.epam.cfc.automation.framework.core.util.loginFactory;

import com.epam.cfc.automation.framework.common.pages.authorization.TwitterLoginPage;
import com.epam.cfc.automation.framework.core.util.data.UserData;

public class TwitterLoginFactory implements Login {
    @Override
    public void logInService() {
        new TwitterLoginPage()
                .fillLogin(new UserData().getTwitterLogin())
                .fillPassword(new UserData().getTwitterPwd())
                .submit();
    }
}
