package framework.common.pages.quiz;

import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static framework.core.util.Waiting.waitForElementVisible;

public class QuizResultPage extends QuizPage {

    @FindBy(css = ".result-diagram__container")
    private WebElement diagramOfResults;

    public Boolean resultIsPresented() {
        waitForElementVisible(diagramOfResults);
        LoggerUtil.LOGGER.info("Asserting that quiz result is present");
        return diagramOfResults.isDisplayed();
    }

}
