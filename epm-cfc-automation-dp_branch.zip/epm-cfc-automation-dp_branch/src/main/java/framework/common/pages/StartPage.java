package framework.common.pages;

import framework.common.bo.Services;
import framework.common.pages.authorization.*;
import framework.common.pages.quiz.TransportPage;
import framework.core.driver.DriverFactory;
import framework.core.util.data.ConfigParameters;
import framework.core.util.logger.LoggerUtil;
import framework.core.util.loginFactory.EmailLoginFactory;
import framework.core.util.services.ServicePage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import static framework.core.util.Waiting.waitForElementEnabled;
import static framework.core.util.Waiting.waitForInvisibilityOfElement;

public class StartPage extends BasePage {

    @FindBy(css = ".login_button button")
    private WebElement loginButton;

    @FindBy(css = ".login_popup")
    private WebElement loginPopup;

    @FindBy(css = ".login_email a")
    private WebElement emailLink;

    @FindBy(css = ".button_google")
    private WebElement googleButton;

    @FindBy(css = ".button_facebook")
    private WebElement facebookButton;

    @FindBy(css = ".button_github")
    private WebElement githubButton;

    @FindBy(css = ".button_twitter")
    private WebElement twitterButton;

    @FindBy(css = ".button_vk")
    private WebElement vkButton;

    @FindBy(css = ".button_linkedin")
    private WebElement linkedInButton;

    @FindBy(css = "#big-calculate-button")
    private WebElement startButton;

    @FindBy(css = ".login_internal_login>button>span")
    private WebElement epamButton;

    @FindBy(css = ".dropbtn")
    private WebElement dropdownMenu;

    @FindBy(css = ".log-out")
    private WebElement logOut;

    private JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getThreadDriver();

    private Actions action = new Actions(DriverFactory.getThreadDriver());

    public StartPage open() {
        DriverFactory.getThreadDriver().get(new ConfigParameters().getUrl());
        LoggerUtil.LOGGER.info("Home page is loading");
        waitForInvisibilityOfElement(loader);
        return this;
    }

    public StartPage openLoginPopupWindow() {
        waitForInvisibilityOfElement(loader);
        LoggerUtil.LOGGER.info("Login pop-up window is opening");
        action.click(loginButton).build().perform();
        return this;
    }

    public StartPage logout() {
        try {
            waitForInvisibilityOfElement(loader);
            LoggerUtil.LOGGER.info("User logging out");
            action
                    .moveToElement(dropdownMenu)
                    .click()
                    .moveToElement(logOut)
                    .click()
                    .build()
                    .perform();
            waitForElementEnabled(loginButton);
            return this;
        } catch (TimeoutException | NoSuchElementException e ){
            return open();
        }
    }

    public TransportPage start() {
        waitForInvisibilityOfElement(loginPopup);
        waitForInvisibilityOfElement(loader);
        waitForElementEnabled(startButton);
        LoggerUtil.LOGGER.info("Clicking on the 'Start' button");
        startButton.click();
        waitForInvisibilityOfElement(loader);
        return new TransportPage();
    }

    public ServicePage openServicePage(Services service) {
        switch (service) {
            case linkedn:
                linkedInButton.click();
                return new LinkedInLoginPage();
            case facebook:
                facebookButton.click();
                return new FacebookLoginPage();
            case vk:
                vkButton.click();
                return new VKLoginPage();
            case github:
                githubButton.click();
                return new GithubLoginPage();
            case epam:
                epamButton.click();
                return new EpamLoginPage();
            case twitter:
                twitterButton.click();
                return new TwitterLoginPage();
            case email:
                emailLink.click();
                return new EmailLoginPage();
            default:
                googleButton.click();
                return new GoogleLoginPage();
        }
    }

    public StartPage loginViaEpam() {
        epamButton.click();
        waitForInvisibilityOfElement(loader);
        return this;
    }

}
