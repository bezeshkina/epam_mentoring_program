package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.util.data.UserData;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TwitterVerificationPage {
    @FindBy(id = "challenge_response")
    private WebElement telNumber;

    @FindBy(id = "email_challenge_submit")
    private WebElement telSubmit;

    public StartPage verifyUser(){
        telNumber.sendKeys(new UserData().getVkLogin());
        telSubmit.click();
        return new StartPage();
    }
}
