package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.util.Waiting;
import framework.core.util.services.ServicePage;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GoogleLoginPage extends ServicePage {

    @FindBy(css = "input[type='email']")
    private WebElement loginInput;

    @FindBy(id = "passwordNext")
    private WebElement submitButton;

    @FindBy(id = "identifierNext")
    private WebElement nextButton;

    @FindBy(name = "password")
    private WebElement passwordInput;

    public GoogleLoginPage fillLogin(String username) {
        LoggerUtil.LOGGER.info("Filling the email field(gmail)");
        loginInput.sendKeys(username);
        return this;
    }

    public GoogleLoginPage fillPassword(String pass) {
        Waiting.waitForElementVisible(passwordInput);
        LoggerUtil.LOGGER.info("Filling the password field(gmail)");
        passwordInput.sendKeys(pass);
        return this;
    }

    public GoogleLoginPage clickNext() {
        nextButton.click();
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(gmail)");
        submitButton.click();
        Waiting.waitForInvisibilityOfElement(loader);
        return new StartPage();
    }

}
