package framework.common.pages.quiz;

import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static framework.core.util.Waiting.waitForElementVisible;

public class FuelPage extends QuizPage {

    @FindBy(css = ".quiz-answer:nth-child(1)")
    private WebElement gasolineCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(2)")
    private WebElement dieselCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(3)")
    private WebElement hybridCheckbox;

    @FindBy(css = ".quiz-answer:nth-child(4)")
    private WebElement electricityCheckbox;

    @FindBy(xpath = "//h2['What is the type of fuel of your car?']")
    private WebElement quizQuestion;

    public TimeOfJourneyPage setGasoline() {
        LoggerUtil.LOGGER.info("Choosing 'gasoline' section");
        gasolineCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public TimeOfJourneyPage setDiesel() {
        LoggerUtil.LOGGER.info("Choosing 'diesel' section");
        dieselCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public TimeOfJourneyPage setHybrid() {
        LoggerUtil.LOGGER.info("Choosing 'gasoline' section");
        hybridCheckbox.click();
        return new TimeOfJourneyPage();
    }

    public TimeOfJourneyPage setElectricity() {
        waitForElementVisible(quizQuestion);
        LoggerUtil.LOGGER.info("Choosing 'electricity' section");
        electricityCheckbox.click();
        return new TimeOfJourneyPage();
    }

}
