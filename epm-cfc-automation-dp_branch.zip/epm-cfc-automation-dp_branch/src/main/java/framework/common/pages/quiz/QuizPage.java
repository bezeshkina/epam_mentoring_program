package framework.common.pages.quiz;

import framework.common.bo.TransportType;
import framework.common.pages.BasePage;
import framework.core.driver.DriverFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import java.util.HashMap;
import java.util.Map;

public abstract class QuizPage extends BasePage {

    @FindBy(css = ".quiz-button-panel__button--next")
    private WebElement nextButton;

    Actions actions = new Actions(DriverFactory.getThreadDriver());

    private static Map<TransportType, Boolean> transport;

    static {
        transport = new HashMap<TransportType, Boolean>();
        transport.put(TransportType.FOOT, false);
        transport.put(TransportType.BIKE, false);
        transport.put(TransportType.CAR, false);
        transport.put(TransportType.BUS, false);
        transport.put(TransportType.SUBWAY, false);
        transport.put(TransportType.TRAIN, false);
    }

    public static void setTransport(TransportType transportType, Boolean result){
        transport.put(transportType, result);
    }

    public static Map getTransport(){
        return transport;
    }

    public QuizPage clickNext(){
        nextButton.click();
        return this;
    }

}
