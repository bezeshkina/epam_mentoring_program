package framework.common.pages.quiz;

import framework.common.bo.TransportType;
import framework.core.driver.DriverFactory;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static framework.core.util.Waiting.waitForElementVisible;

public class TransportPage extends QuizPage {

    @FindBy(css = ".input-location")
    private WebElement inputLocation;

    @FindAll({@FindBy(css = ".scrollable>div>li")})
    private List<WebElement> cities;

    @FindBy(css = ".dropdown-loader")
    private WebElement dropdownLoader;

    @FindBy(css = ".location-button__start")
    private WebElement startQuizButton;

    @FindBy(css = "section.quiz-answer:nth-child(1)")
    private WebElement onFootCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(2)")
    private WebElement byBikeCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(3)")
    private WebElement byCarCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(4)")
    private WebElement byBusCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(5)")
    private WebElement bySubwayCheckbox;

    @FindBy(css = "section.quiz-answer:nth-child(6)")
    private WebElement byTrainCheckbox;

    private JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getThreadDriver();

    public TransportPage chooseCity(String city) {
        try {
            waitForElementVisible(inputLocation);
            inputLocation.sendKeys(city);
            for (WebElement element : cities) {
                if (element.getText().contains(city))
                    js.executeScript("arguments[0].click();", element);
            }
            startQuizButton.click();
        } catch (NullPointerException | TimeoutException | ElementNotVisibleException e) {
            System.out.println("You have already chosen the city");
        }
        return this;
    }

    public TransportPage tickOnFoot() {
        LoggerUtil.LOGGER.info("Clicking 'on foot' section");
        onFootCheckbox.click();
        QuizPage.setTransport(TransportType.FOOT, true);
        return this;
    }

    public TransportPage tickByBike() {
        LoggerUtil.LOGGER.info("Clicking 'by bike' section");
        byBikeCheckbox.click();
        QuizPage.setTransport(TransportType.BIKE, true);
        return this;
    }

    public TransportPage tickByCar() {
        LoggerUtil.LOGGER.info("Clicking 'by car' section");
        byCarCheckbox.click();
        QuizPage.setTransport(TransportType.CAR, true);
        return this;
    }

    public TransportPage tickByBus() {
        LoggerUtil.LOGGER.info("Clicking 'by bus' section");
        byBusCheckbox.click();
        QuizPage.setTransport(TransportType.BUS, true);
        return this;
    }

    public TransportPage tickBySubway() {
        LoggerUtil.LOGGER.info("Clicking 'by subway' section");
        bySubwayCheckbox.click();
        QuizPage.setTransport(TransportType.SUBWAY, true);
        return this;
    }

    public TransportPage tickByTrain() {
        LoggerUtil.LOGGER.info("Clicking 'by train' section");
        byTrainCheckbox.click();
        QuizPage.setTransport(TransportType.TRAIN, true);
        return this;
    }

    public QuizPage goToNextQuestion() {
        Map<TransportType, Boolean> chosenTransport = QuizPage.getTransport();
        List<TransportType> publicTransport = new ArrayList<TransportType>() {{
            add(TransportType.BUS);
            add(TransportType.SUBWAY);
            add(TransportType.TRAIN);
        }};
        clickNext();
        if (chosenTransport.get(TransportType.CAR))
            return new FuelPage();
        else {
            if (chosenTransport.entrySet()
                    .stream()
                    .filter(Map.Entry::getValue)
                    .collect(Collectors.toList())
                    .containsAll(publicTransport))
                return new TimeOfJourneyPage();
            else
                return new FoodPage();
        }
    }
}
