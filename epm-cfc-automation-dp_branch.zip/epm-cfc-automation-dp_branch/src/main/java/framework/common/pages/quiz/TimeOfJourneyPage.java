package framework.common.pages.quiz;

import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TimeOfJourneyPage extends QuizPage {

    @FindBy(xpath = "//div[@ng-show=\"$ctrl.transport['CAR']\"]//input")
    private WebElement inputCarRange;

    @FindBy(xpath = "//div[@ng-show=\"$ctrl.transport['BUS']\"]//input")
    private WebElement inputBusRange;

    @FindBy(xpath = "//div[@ng-show=\"$ctrl.transport['RAIL']\"]//input")
    private WebElement inputSubwayRange;

    @FindBy(xpath = "//div[@ng-show=\"$ctrl.transport['TRAIN']\"]//input")
    private WebElement inputTrainRange;

    private int stepUp = 4;
    private int stepDown = -4;
    private int offsetX = 0;
    private int zeroValue = 65;

    public TimeOfJourneyPage setTimeOfCarJourney(int x){
        if (x < zeroValue)
            offsetX = (zeroValue - x) * stepDown;
        else
        if (x > zeroValue)
            offsetX = (x - zeroValue) * stepUp;
        LoggerUtil.LOGGER.info("Setting the time of journey by car");
        actions
                .clickAndHold(inputCarRange)
                .moveByOffset(offsetX, -37)
                .click()
                .build()
                .perform();
        return this;
    }

    public TimeOfJourneyPage setTimeOfBusJourney(int x){
        if (x < 65)
            offsetX = (65 - x) * stepDown;
        else
        if (x > 65)
            offsetX = (x - 65) * stepUp;
        LoggerUtil.LOGGER.info("Setting the time of journey by bus");
        actions
                .clickAndHold(inputBusRange)
                .moveByOffset(offsetX, -37)
                .click()
                .build()
                .perform();
        return this;
    }

    public TimeOfJourneyPage setTimeOfTrainJourney(int x){
        if (x < 65)
            offsetX = (65 - x) * stepDown;
        else
        if (x > 65)
            offsetX = (x - 65) * stepUp;
        LoggerUtil.LOGGER.info("Setting the time of journey by train");
        actions
                .clickAndHold(inputTrainRange)
                .moveByOffset(offsetX, -37)
                .click()
                .build()
                .perform();
        return this;
    }

    public TimeOfJourneyPage setTimeOfSubwayJourney(int x){
        if (x < 65)
            offsetX = (65 - x) * stepDown;
        else
        if (x > 65)
            offsetX = (x - 65) * stepUp;
        LoggerUtil.LOGGER.info("Setting the time of journey by subway");
        actions
                .clickAndHold(inputSubwayRange)
                .moveByOffset(offsetX, -37)
                .click()
                .build()
                .perform();
        return this;
    }

}
