package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.util.Waiting;
import framework.core.util.services.ServicePage;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LinkedInLoginPage extends ServicePage {

    @FindBy(id = "username")
    private WebElement usernameInput;

    @FindBy(id = "password")
    private WebElement passwordInput;

    @FindBy(css = ".btn__primary--large")
    private WebElement submitButton;

    @Override
    public ServicePage fillLogin(String login) {
        LoggerUtil.LOGGER.info("Filling the email field(linkedIn)");
        usernameInput.sendKeys(login);
        return this;
    }

    @Override
    public ServicePage fillPassword(String password) {
        LoggerUtil.LOGGER.info("Filling the password field(linkedIn)");
        passwordInput.sendKeys(password);
        return this;
    }

    @Override
    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(linkedIn)");
        submitButton.click();
        Waiting.waitForInvisibilityOfElement(loader);
        return new StartPage();
    }
}
