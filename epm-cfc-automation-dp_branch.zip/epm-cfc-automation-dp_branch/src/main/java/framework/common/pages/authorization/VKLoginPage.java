package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.util.Waiting;
import framework.core.util.services.ServicePage;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class VKLoginPage extends ServicePage {

    @FindBy(name = "email")
    private WebElement emailField;

    @FindBy(name = "pass")
    private WebElement passwordField;

    @FindBy(css = "#install_allow")
    private WebElement submitBtn;

    public VKLoginPage fillLogin(String email) {
        Waiting.waitForElementVisible(emailField);
        LoggerUtil.LOGGER.info("Filling the email field(VK)");
        emailField.sendKeys(email);
        return this;
    }

    public VKLoginPage fillPassword(String pwd) {
        LoggerUtil.LOGGER.info("Filling the password field(VK)");
        passwordField.sendKeys(pwd);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(VK)");
        submitBtn.click();
        return new StartPage();
    }
}
