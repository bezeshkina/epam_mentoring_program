package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.driver.DriverFactory;
import framework.core.util.Waiting;
import framework.core.util.services.ServicePage;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TwitterLoginPage extends ServicePage {

    @FindBy(id = "username_or_email")
    private WebElement usernameInput;

    @FindBy(id = "password")
    private WebElement passInput;

    @FindBy(id = "allow")
    private WebElement loginButton;

    public TwitterLoginPage fillLogin(String username) {
        Waiting.waitForElementEnabled(usernameInput);
        LoggerUtil.LOGGER.info("Filling the email field(twitter)");
        usernameInput.sendKeys(username);
        return this;
    }

    public TwitterLoginPage fillPassword(String pass) {
        LoggerUtil.LOGGER.info("Filling the password field(twitter)");
        passInput.sendKeys(pass);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(twitter)");
        loginButton.click();
        if (DriverFactory.getThreadDriver().getTitle().contains("Twitter"))
            return new TwitterVerificationPage().verifyUser();
        else {
            Waiting.waitForInvisibilityOfElement(loader);
            return new StartPage();
        }
    }
}
