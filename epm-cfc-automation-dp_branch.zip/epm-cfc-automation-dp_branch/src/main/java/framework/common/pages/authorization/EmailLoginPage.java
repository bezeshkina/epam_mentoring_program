package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.util.services.ServicePage;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static framework.core.util.Waiting.*;

public class EmailLoginPage extends ServicePage {
    @FindBy(id = "username")
    private WebElement emailInput;

    @FindBy(id = "password")
    private WebElement passInput;

    @FindBy(id = "login")
    private WebElement loginButton;

    public EmailLoginPage fillLogin(String username) {
        waitForElementVisible(emailInput);
        LoggerUtil.LOGGER.info("Filling the email field(social login)");
        emailInput.sendKeys(username);
        return this;
    }

    public EmailLoginPage fillPassword(String pass) {
        LoggerUtil.LOGGER.info("Filling the password field(social login)");
        passInput.sendKeys(pass);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(social login)");
        loginButton.click();
        waitForInvisibilityOfElement(loader);
        return new StartPage();
    }

}
