package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.util.services.ServicePage;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static framework.core.util.Waiting.*;

public class FacebookLoginPage extends ServicePage {

    @FindBy(xpath = "//input[@id='email']")
    private WebElement fbLoginInput;

    @FindBy(xpath = "//input[@id='pass']")
    private WebElement fbPwdInput;

    @FindBy(xpath = "//button[@id='loginbutton']")
    private WebElement fbLoginBtn;

    public FacebookLoginPage() {
        waitForElementEnabled(fbLoginBtn);
    }

    public FacebookLoginPage fillLogin(String login) {
        LoggerUtil.LOGGER.info("Filling the email field(facebook)");
        fbLoginInput.sendKeys(login);
        return this;
    }

    public FacebookLoginPage fillPassword(String pwd) {
        LoggerUtil.LOGGER.info("Filling the password field(facebook)");
        fbPwdInput.sendKeys(pwd);
        return this;
    }

    public StartPage submit() {
        LoggerUtil.LOGGER.info("Clicking the login button(facebook)");
        fbLoginBtn.click();
        waitForInvisibilityOfElement(loader);
        return new StartPage();
    }

}
