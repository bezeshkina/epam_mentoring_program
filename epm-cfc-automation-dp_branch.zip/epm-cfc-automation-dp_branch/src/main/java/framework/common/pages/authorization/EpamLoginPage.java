package framework.common.pages.authorization;

import framework.common.pages.StartPage;
import framework.core.util.services.ServicePage;

public class EpamLoginPage extends ServicePage {

    public ServicePage fillLogin(String login) {
        return null;
    }

    public ServicePage fillPassword(String password) {
        return null;
    }

    @Override
    public StartPage submit() {
        return null;
    }

}
