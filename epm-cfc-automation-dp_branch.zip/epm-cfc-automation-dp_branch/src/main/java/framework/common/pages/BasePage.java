package framework.common.pages;

import framework.core.driver.DriverFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public abstract class BasePage {

    @FindBy(css = "#loader")
    protected WebElement loader;

    public BasePage() {
        DriverFactory.getThreadDriver();
        PageFactory.initElements(DriverFactory.getThreadDriver(), this);
    }

    public String getTitle() {
        return DriverFactory.getThreadDriver().getTitle();
    }

}
