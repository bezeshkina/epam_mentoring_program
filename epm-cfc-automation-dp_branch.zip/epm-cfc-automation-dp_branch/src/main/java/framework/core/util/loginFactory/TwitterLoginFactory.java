package framework.core.util.loginFactory;

import framework.common.pages.authorization.TwitterLoginPage;
import framework.core.util.data.UserData;

public class TwitterLoginFactory implements Login {
    @Override
    public void logInService() {
        new TwitterLoginPage()
                .fillLogin(new UserData().getTwitterLogin())
                .fillPassword(new UserData().getTwitterPwd())
                .submit();
    }
}
