package framework.core.util.loginFactory;

import framework.common.pages.authorization.GoogleLoginPage;
import framework.core.util.data.UserData;

public class GoogleLoginFactory implements Login {
    @Override
    public void logInService() {
        new GoogleLoginPage()
                .fillLogin(new UserData().getGoogleLogin()).clickNext()
                .fillPassword(new UserData().getGooglePwd())
                .submit();
    }
}
