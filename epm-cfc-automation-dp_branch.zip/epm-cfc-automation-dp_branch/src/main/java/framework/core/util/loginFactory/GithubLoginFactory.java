package framework.core.util.loginFactory;

import framework.common.pages.authorization.GithubLoginPage;
import framework.core.util.data.UserData;

public class GithubLoginFactory implements Login {
    @Override
    public void logInService() {
        new GithubLoginPage()
                .fillLogin(new UserData().getGithubLogin())
                .fillPassword(new UserData().getGithubPwd())
                .submit();
    }
}
