package framework.core.util.data;

public class UserData {
    private String facebookLogin = "auto.tester2019";
    private String facebookPwd = "password2019";
    private String vkLogin = "+77785822317";
    private String vkPwd = "password2019";
    private String githubLogin = "dev-test-2019";
    private String githubPwd = "123CFCpass";
    private String googleLogin = "auto.tester2019@gmail.com";
    private String googlePwd = "password2019";
    private String twitterLogin = "devtest26732562";
    private String twitterPwd = "password2019";
    private String emailLogin = "new_account_2018@bk.ru";
    private String emailPwd = "password2018";
    private String linkednLogin = "Auto_EPM-CFC_Testing@epam.com";
    private String linkednPwd = "password2019";
    private String epamLogin = "Auto_EPM-CFC_Testing@epam.com";
    private String epamPwd = "9ATfuXbQkqQ827z9MhZABa55U";

    public String getFacebookLogin() {
        return facebookLogin;
    }

    public String getFacebookPwd() {
        return facebookPwd;
    }

    public String getVkLogin() {
        return vkLogin;
    }

    public String getVkPwd() {
        return vkPwd;
    }

    public String getGithubLogin() {
        return githubLogin;
    }

    public String getGithubPwd() {
        return githubPwd;
    }

    public String getGoogleLogin() {
        return googleLogin;
    }

    public String getGooglePwd() {
        return googlePwd;
    }

    public String getTwitterLogin() {
        return twitterLogin;
    }

    public String getTwitterPwd() {
        return twitterPwd;
    }

    public String getEmailLogin() {
        return emailLogin;
    }

    public String getEmailPwd() {
        return emailPwd;
    }

    public String getLinkednLogin() {
        return linkednLogin;
    }

    public String getLinkednPwd() {
        return linkednPwd;
    }

    public String getEpamLogin() {
        return epamLogin;
    }

    public String getEpamPwd() {
        return epamPwd;
    }
}