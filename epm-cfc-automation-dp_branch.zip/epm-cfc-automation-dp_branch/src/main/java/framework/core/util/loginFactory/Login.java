package framework.core.util.loginFactory;

public interface Login {
    void logInService();
}
