package framework.core.util.data;

public class ConfigParameters {
    private String url = "https://ecsc00a03b05.epam.com";
    private String selenoidHub = "http://ecsc00a0499a.epam.com:4444/wd/hub";
    private String dbUser = "cfc";
    private String database = "test-cfc";
    private char[] dbPassword = "12345".toCharArray();
    private String key = "employeeId";
    private String host = "ecsc00a03b05.epam.com";

    public String getUrl() {
        return url;
    }

    public String getSelenoidHub() {
        return selenoidHub;
    }

    public String getDbUser() {
        return dbUser;
    }

    public String getDatabase() {
        return database;
    }

    public char[] getDbPassword() {
        return dbPassword;
    }

    public String getKey() {
        return key;
    }

    public String getHost() {
        return host;
    }
}
