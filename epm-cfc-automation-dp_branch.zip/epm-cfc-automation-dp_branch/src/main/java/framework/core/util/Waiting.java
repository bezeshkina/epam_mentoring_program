package framework.core.util;

import framework.core.driver.DriverFactory;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

public class Waiting {

    private static final int WAIT_FOR_ELEMENT_TIMEOUT_SECONDS = 12;

    public static void waitForElementVisible(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element '" + element + "' visible");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.visibilityOf(element));
        } catch (TimeoutException | ElementNotVisibleException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
        }
    }

    public static void waitForElementEnabled(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element'" + element + "' enable");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.elementToBeClickable(element));
        } catch (TimeoutException | ElementClickInterceptedException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
        }
    }

    public static void waitForTitleIs(String title) {
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.titleIs(title));
        } catch (TimeoutException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
        }
    }

    public static void waitForInvisibilityOfElement(WebElement element) {
        LoggerUtil.LOGGER.debug("Waiting for element is disappeared");
        try {
            new WebDriverWait(DriverFactory.getThreadDriver(), WAIT_FOR_ELEMENT_TIMEOUT_SECONDS).until(ExpectedConditions.invisibilityOf(element));
        } catch (TimeoutException | ElementNotVisibleException e) {
            LoggerUtil.LOGGER.error(e.getMessage(), e);
        }
    }

    public static void sleep(int sec) {
        try {
            LoggerUtil.LOGGER.debug("Waiting for [{}] sec", sec);
            Thread.sleep(sec * 1000);
        } catch (InterruptedException e) {
            LoggerUtil.LOGGER.error(e.getMessage());
        }
    }

}
