package framework.core.util.services;

import framework.core.util.loginFactory.LoginFactory;
import framework.common.bo.Services;

public class LogIn {

    public void loginInService(Services service){
        new LoginFactory().chooseService(service).logInService();
    }
}
