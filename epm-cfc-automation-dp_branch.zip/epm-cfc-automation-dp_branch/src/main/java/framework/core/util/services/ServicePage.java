package framework.core.util.services;

import framework.common.pages.BasePage;
import framework.common.pages.StartPage;

public abstract class ServicePage extends BasePage {

    public abstract ServicePage fillLogin(String login);
    public abstract ServicePage fillPassword(String password);
    public abstract StartPage submit();

}
