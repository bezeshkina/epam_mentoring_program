package framework.core.util.loginFactory;

import framework.common.pages.authorization.EmailLoginPage;
import framework.core.util.data.UserData;

public class EmailLoginFactory implements Login {
    @Override
    public void logInService() {
        new EmailLoginPage()
                .fillLogin(new UserData().getEmailLogin())
                .fillPassword(new UserData().getEmailPwd())
                .submit();
    }
}
