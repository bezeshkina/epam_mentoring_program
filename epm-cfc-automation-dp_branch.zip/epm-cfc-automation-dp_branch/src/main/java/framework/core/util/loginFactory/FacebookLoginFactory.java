package framework.core.util.loginFactory;

import framework.common.pages.authorization.FacebookLoginPage;
import framework.core.util.data.UserData;

public class FacebookLoginFactory implements Login {
    @Override
    public void logInService() {
        new FacebookLoginPage()
                .fillLogin(new UserData().getFacebookLogin())
                .fillPassword(new UserData().getFacebookPwd())
                .submit();
    }
}
