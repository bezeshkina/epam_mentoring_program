package framework.core.util.loginFactory;

import framework.common.pages.authorization.VKLoginPage;
import framework.core.util.data.UserData;

public class VKLoginFactory implements Login {
    @Override
    public void logInService() {
        new VKLoginPage()
                .fillLogin(new UserData().getVkLogin())
                .fillPassword(new UserData().getVkPwd())
                .submit();
    }
}
