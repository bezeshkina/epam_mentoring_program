package framework.core.util.logger;

import com.epam.reportportal.message.ReportPortalMessage;
import com.google.common.io.BaseEncoding;
import framework.core.util.Screenshoter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;

public class LoggerUtil {

    public static final Logger LOGGER = LogManager.getLogger(LoggerUtil.class);

    private LoggerUtil(){
    }

    public static void log(File file, String message) {
        LOGGER.info("RP_MESSAGE#FILE#{}#{}", file.getAbsolutePath(), message);
    }

    public static void log(byte[] bytes, String message) {
        LOGGER.info("RP_MESSAGE#BASE64#{}#{}", BaseEncoding.base64().encode(bytes), message);
    }

    public static void logBase64(String base64, String message) {
        LOGGER.info("RP_MESSAGE#BASE64#{}#{}", base64, message);
    }
}
