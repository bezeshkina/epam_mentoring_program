package framework.core.util;

import framework.core.driver.DriverFactory;
import framework.core.driver.DriverManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;


public class Screenshoter {
    private static final String SCREENSHOTS_NAME_TPL = "src/screenshots/";

    public void takeScreenshot() {
        WebDriver driver = DriverFactory.getThreadDriver();
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String screenshotName = SCREENSHOTS_NAME_TPL + System.nanoTime();
        File copy = new File(screenshotName + ".png");
        try {
            FileHandler.copy(screenshot, copy);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
