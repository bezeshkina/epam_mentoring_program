package framework.core.util.loginFactory;

import framework.common.pages.authorization.LinkedInLoginPage;
import framework.core.util.data.UserData;

public class LinkedInLoginFactory implements Login {
    @Override
    public void logInService() {
        new LinkedInLoginPage()
                .fillLogin(new UserData().getLinkednLogin())
                .fillPassword(new UserData().getLinkednPwd())
                .submit();
    }
}
