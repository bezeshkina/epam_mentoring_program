package framework.core.driver;

import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class DriverFactory {

    private static ThreadLocal<WebDriver> threadDriver = new ThreadLocal<WebDriver>();

    private static WebDriver initDriver() {
        WebDriver driver = null;
        if (Browser.getBrowserName().equalsIgnoreCase("chrome")) {
            driver = new ChromeDriverManager().createDriver();
        } else if (Browser.getBrowserName().equalsIgnoreCase("firefox")) {
            driver = new FirefoxDriverManager().createDriver();
        }
        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public synchronized static void driverQuit() {
        WebDriver currentDriver = threadDriver.get();
        if (currentDriver != null){
            currentDriver.quit();
            threadDriver.set(null);
        }
    }

    public synchronized static WebDriver getThreadDriver() {
        WebDriver currentDriver = threadDriver.get();
        if (currentDriver == null){
            currentDriver = initDriver();
            threadDriver.set(currentDriver);
        }
        return threadDriver.get();
    }
}
