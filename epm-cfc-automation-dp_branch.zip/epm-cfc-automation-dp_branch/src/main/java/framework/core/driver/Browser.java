package framework.core.driver;

public class Browser {

    private static String getParameter(String name){
        String val = System.getProperty(name);
        if (val == null){
            throw new RuntimeException(name + " is not parameter");
        }
        if (val.isEmpty())
            throw new RuntimeException(name + " is empty");
        return val;
    }

    public static String getBrowserName(){
        return getParameter("browser");
    }

}
