package framework.core.driver;

import org.openqa.selenium.WebDriver;

public abstract class DriverManager {
    protected abstract WebDriver createDriver();

}
