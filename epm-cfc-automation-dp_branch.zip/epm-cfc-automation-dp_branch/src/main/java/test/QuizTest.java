package test;

import framework.common.bo.Services;
import framework.common.pages.quiz.*;
import framework.core.util.DBConnection;
import framework.core.util.logger.LoggerUtil;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.*;


public class QuizTest extends BaseTest {

    private TransportPage transportPage = new TransportPage();
    private FuelPage fuelPage = new FuelPage();
    private TimeOfJourneyPage timeOfJourneyPage = new TimeOfJourneyPage();
    private FoodPage foodPage = new FoodPage();
    private PetsPage petsPage = new PetsPage();
    private ElectricityPage electricityPage = new ElectricityPage();
    private Services mService;

    @Factory(dataProvider = "getService", dataProviderClass = DataProviderSource.class)
    public QuizTest(Services services){
        this.mService = services;
    }

    @BeforeMethod
    public void signIn(){
        DBConnection.removeUserConnection(mService);
        startPage.openLoginPopupWindow().openServicePage(mService);
        startPage.start();
    }

    @Test(description = "On foot, by bus, vegan, 2 dogs, 150 kWh")
    public void quizTest1() {
        transportPage
                .tickOnFoot()
                .tickByBus()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(15)
                .clickNext();
        foodPage
                .chooseVegan()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setDogsCount(2)
                .clickNext();
        electricityPage
                .setElectricityRange(150)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By bike, by car, diesel, vegetarian, 1 cat, 250 kWh")
    public void quizTest2() {
        transportPage
                .tickByBike()
                .tickByCar()
                .goToNextQuestion();
        fuelPage
                .setDiesel()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(35)
                .clickNext();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setCatsCount(1)
                .clickNext();
        electricityPage
                .setElectricityRange(250)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By bus, by subway, balanced, 5 spiders and snakes, 320 kWh")
    public void quizTest3() {
        transportPage
                .tickByBus()
                .tickBySubway()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(20)
                .setTimeOfSubwayJourney(10)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickOtherSection()
                .setSnakesAndSpidersCount(5)
                .clickNext();
        electricityPage
                .setElectricityRange(320)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "On foot, by subway, balanced, 4 rodents, 130 kWh")
    public void quizTest4() {
        transportPage
                .tickOnFoot()
                .tickBySubway()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfSubwayJourney(70)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setRodentCount(4)
                .clickNext();
        electricityPage
                .setElectricityRange(130)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By bike, vegetarian, 3 cats, 2 dogs, 520 kWh")
    public void quizTest5() {
        transportPage
                .tickByBike()
                .goToNextQuestion();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setCatsCount(3)
                .setDogsCount(2)
                .clickNext();
        electricityPage
                .setElectricityRange(520)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By car, gasoline, vegan, 7 fishes, 440 kWh")
    public void quizTest6() {
        transportPage
                .tickByCar()
                .goToNextQuestion();
        fuelPage
                .setGasoline()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(15)
                .clickNext();
        foodPage
                .chooseVegan()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickOtherSection()
                .setAquariumFishCount(7)
                .clickNext();
        electricityPage
                .setElectricityRange(440)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By bike, by subway, fast food, 5 dogs, 720 kWh")
    public void quizTest7() {
        transportPage
                .tickByBike()
                .tickBySubway()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfSubwayJourney(35)
                .clickNext();
        foodPage
                .chooseFastFood()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setDogsCount(5)
                .clickNext();
        electricityPage
                .setElectricityRange(720)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By bus, by train, balanced, 3 rodents, 9 lizards, 910 kWh")
    public void quizTest8() {
        transportPage
                .tickByBus()
                .tickByTrain()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(40)
                .setTimeOfTrainJourney(90)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setRodentCount(3)
                .clickOtherSection()
                .setLizardsCount(9)
                .clickNext();
        electricityPage
                .setElectricityRange(910)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By car, by bus, electricity, 9 cats, 9 dogs, 7 fishes, 1000 kWh")
    public void quizTest9() {
        transportPage
                .tickByCar()
                .tickByBus()
                .tickBySubway()
                .goToNextQuestion();
        fuelPage
                .setElectricity()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(70)
                .setTimeOfBusJourney(50)
                .setTimeOfSubwayJourney(40)
                .clickNext();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setCatsCount(9)
                .setDogsCount(9)
                .clickOtherSection()
                .setAquariumFishCount(7)
                .clickNext();
        electricityPage
                .setElectricityRange(1000)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "On foot, fast food, 2 dogs, 1 cat, 3 rodents, 4 fishes, 5 parrots, 6 rabbits, 7 lizards, 8 snakes and spiders, 70 kWh")
    public void quizTest10() {
        transportPage
                .tickOnFoot()
                .goToNextQuestion();
        foodPage
                .chooseFastFood()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setDogsCount(2)
                .setCatsCount(1)
                .setRodentCount(3)
                .clickOtherSection()
                .setAquariumFishCount(4)
                .setParrotsCount(5)
                .setRabbitsCount(6)
                .setLizardsCount(7)
                .setSnakesAndSpidersCount(8)
                .clickNext();
        electricityPage
                .setElectricityRange(70)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By train, vegan, 880 kWh")
    public void quizTest11() {
        transportPage
                .tickByTrain()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfTrainJourney(100)
                .clickNext();
        foodPage
                .chooseVegan()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickNext();
        electricityPage
                .setElectricityRange(880)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By subway, vegetarian, 6 dogs, 2 parrots, 770 kWh")
    public void quizTest12() {
        transportPage
                .tickBySubway()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfSubwayJourney(55)
                .clickNext();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setDogsCount(6)
                .clickOtherSection()
                .setParrotsCount(2)
                .clickNext();
        electricityPage
                .setElectricityRange(770)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "On foot, by bike, by car, hybrid, fast food, 8 cats, 610 kWh")
    public void quizTest13() {
        transportPage
                .tickOnFoot()
                .tickByBike()
                .tickByCar()
                .goToNextQuestion();
        fuelPage
                .setHybrid()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(25)
                .clickNext();
        foodPage
                .chooseFastFood()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setCatsCount(8)
                .clickNext();
        electricityPage
                .setElectricityRange(610)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "On foot, by car, by subway, diesel, balanced, 7 rodents, 350 kWh")
    public void quizTest14() {
        transportPage
                .tickOnFoot()
                .tickByCar()
                .tickBySubway()
                .goToNextQuestion();
        fuelPage
                .setDiesel()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(55)
                .setTimeOfSubwayJourney(70)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setRodentCount(7)
                .clickNext();
        electricityPage
                .setElectricityRange(350)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By car, on foot, by bike, by train, hybrid, vegetarian, 1 fish, 1 cat, 1 dog, 1 rodent, 1 parrot, 1 rabbit, 1 lizard, 1 snake and spiders, 950 kWh")
    public void quizTest15() {
        transportPage
                .tickByCar()
                .tickOnFoot()
                .tickByBike()
                .tickByTrain()
                .goToNextQuestion();
        fuelPage
                .setHybrid()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(20)
                .setTimeOfTrainJourney(40)
                .clickNext();
        foodPage
                .chooseVegetarian()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickOtherSection()
                .setAquariumFishCount(1)
                .setCatsCount(1)
                .setDogsCount(1)
                .setRodentCount(1)
                .setParrotsCount(1)
                .setRabbitsCount(1)
                .setLizardsCount(1)
                .setSnakesAndSpidersCount(1)
                .clickNext();
        electricityPage
                .setElectricityRange(950)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

/*    @Test(description = "By bike, by train, fast food, 7 rabbits, 470 kWh")
    public void quizTest16() {
        startPage.start();
        transportPage
                .tickByBike()
                .tickByTrain()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfTrainJourney(45)
                .clickNext();
        foodPage
                .chooseFastFood()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickOtherSection()
                .setRabbitsCount(7)
                .clickNext();
        electricityPage
                .setElectricityRange(470)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By bus, balanced, 4 cats, 7 parrots, 690 kWh")
    public void quizTest17() {
        startPage.start();
        transportPage
                .tickByBus()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(85)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setCatsCount(4)
                .clickOtherSection()
                .setParrotsCount(7)
                .clickNext();
        electricityPage
                .setElectricityRange(690)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By car, by subway, electricity, vegan, 1 dog, 5 cats, 500 kWh")
    public void quizTest18() {
        startPage.start();
        transportPage
                .tickByCar()
                .tickBySubway()
                .goToNextQuestion();
        fuelPage
                .setElectricity()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(30)
                .setTimeOfSubwayJourney(10)
                .clickNext();
        foodPage
                .chooseVegan()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setDogsCount(1)
                .setCatsCount(5)
                .clickNext();
        electricityPage
                .setElectricityRange(500)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By bike, by bus, fast food, 8 rodents, 250 kWh")
    public void quizTest19() {
        startPage.start();
        transportPage
                .tickByBike()
                .tickByBus()
                .goToNextQuestion();
        timeOfJourneyPage
                .setTimeOfBusJourney(65)
                .clickNext();
        foodPage
                .chooseFastFood()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .setRodentCount(8)
                .clickNext();
        electricityPage
                .setElectricityRange(250)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }

    @Test(description = "By car, by train, diesel, balanced, 4 rabbits, 3 dogs, 750 kWh")
    public void quizTest20() {
        startPage.start();
        transportPage
                .tickByCar()
                .tickByTrain()
                .goToNextQuestion();
        fuelPage
                .setDiesel()
                .clickNext();
        timeOfJourneyPage
                .setTimeOfCarJourney(15)
                .setTimeOfTrainJourney(30)
                .clickNext();
        foodPage
                .chooseBalanced()
                .clickNext();
        petsPage
                .waitForSectionVisible()
                .clickOtherSection()
                .setRabbitsCount(4)
                .setDogsCount(3)
                .clickNext();
        electricityPage
                .setElectricityRange(750)
                .calculate();
        Assert.assertTrue(new QuizResultPage().resultIsPresented(), "Results isn't presented");
    }*/

}
