package test;

import org.testng.annotations.DataProvider;

import static framework.common.bo.Services.*;

public class DataProviderSource {
    @DataProvider
    public Object[][] getService(){
        Object[][] services = {
                {facebook},
                {vk},
                {twitter},
                {google},
                //{email},
                {linkedn},
                {github}
        };
        return services;
    }
}
