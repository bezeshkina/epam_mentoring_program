package test;

import framework.common.pages.StartPage;
import framework.core.driver.DriverFactory;
import framework.core.util.logger.LoggerUtil;
import org.testng.annotations.*;

class BaseTest {
    protected static StartPage startPage = new StartPage();

    @BeforeSuite
    public void open(){
        startPage.open();
    }

    @AfterMethod
    public void logout() {
        LoggerUtil.LOGGER.info("Page is refreshing");
        DriverFactory.getThreadDriver().navigate().refresh();
        startPage.logout();
    }

    @AfterSuite
    public static void dismissBrowser() {
        LoggerUtil.LOGGER.info("Browser quits after suite");
        DriverFactory.driverQuit();
    }
}
