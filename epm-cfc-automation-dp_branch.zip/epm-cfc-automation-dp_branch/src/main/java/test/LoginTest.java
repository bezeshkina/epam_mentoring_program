package test;

import framework.core.util.services.LogIn;
import framework.common.bo.Services;
import framework.core.util.logger.LoggerUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import sun.rmi.runtime.Log;

import javax.crypto.interfaces.PBEKey;

public class LoginTest extends BaseTest {
    private Services mService;

    @Factory(dataProvider = "getService", dataProviderClass = DataProviderSource.class)
    public LoginTest(Services services){
        this.mService = services;
    }

    @Test(description = "Login test ")
    public void loginViaService() {
        startPage.openLoginPopupWindow().openServicePage(mService);
        new LogIn().loginInService(mService);
        LoggerUtil.LOGGER.info("Asserting that title is 'Carbon Footprint Calculator'");
        Assert.assertEquals(startPage.getTitle(), "Carbon Footprint Calculator", "User doesn't signed in in " + mService.toString());
    }
}
