package factory;

import org.openqa.selenium.WebElement;

public interface Email {
    void enterAddressee(WebElement element, String a);
    void enterSubject(WebElement element, String s);
    void enterText(WebElement element, String t);
    void uploadAttachment(WebElement element);
}
