package factory;

public class EWAFactory implements EmailFactory {
    @Override
    public Email createEmail() {
        return new EmailWithoutAttachments();
    }
}
