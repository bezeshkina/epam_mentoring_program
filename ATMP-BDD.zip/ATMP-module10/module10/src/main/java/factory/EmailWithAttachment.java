package factory;

import org.openqa.selenium.WebElement;

import java.io.File;

public class EmailWithAttachment implements Email {
    private String filePath = "src/main/resources/data/Blood-dripping-1467657378.gif";

    public void enterAddressee(WebElement element, String addressee) {
        element.sendKeys(addressee);
    }

    public void enterSubject(WebElement element, String subject) {
        element.sendKeys(subject);
    }

    public void enterText(WebElement element, String text) {
        element.sendKeys(text);
    }

    public void uploadAttachment(WebElement element) {
        element.sendKeys(new File(filePath).getAbsolutePath());
    }
}
