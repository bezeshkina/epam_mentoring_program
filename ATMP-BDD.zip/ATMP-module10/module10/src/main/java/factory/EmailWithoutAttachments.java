package factory;

import org.openqa.selenium.WebElement;

public class EmailWithoutAttachments implements Email {
    public void enterAddressee(WebElement element, String addressee) {
        element.sendKeys(addressee);
    }

    public void enterSubject(WebElement element, String subject) {
        element.sendKeys(subject);
    }

    public void enterText(WebElement element, String text) {
        element.sendKeys(text);
    }

    public void uploadAttachment(WebElement element) {
    }
}
