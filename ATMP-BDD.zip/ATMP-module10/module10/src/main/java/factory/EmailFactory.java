package factory;

public interface EmailFactory {
    Email createEmail();
}
