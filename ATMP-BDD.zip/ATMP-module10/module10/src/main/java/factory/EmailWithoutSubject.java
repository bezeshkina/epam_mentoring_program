package factory;

import businessObjects.EmailData;
import org.openqa.selenium.WebElement;

public class EmailWithoutSubject implements Email{
    public void enterAddressee(WebElement element, String addressee) {
        element.sendKeys(addressee);
    }

    public void enterSubject(WebElement element, String subject) {
        element.sendKeys(null);
    }

    public void enterText(WebElement element, String text) {
        element.sendKeys(text);
    }

    public void uploadAttachment(WebElement element) {
    }
}
