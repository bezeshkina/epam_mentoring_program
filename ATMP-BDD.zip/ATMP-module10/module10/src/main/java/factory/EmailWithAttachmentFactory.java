package factory;

public class EmailWithAttachmentFactory implements EmailFactory {
    public Email createEmail() {
        return new EmailWithAttachment();
    }
}
