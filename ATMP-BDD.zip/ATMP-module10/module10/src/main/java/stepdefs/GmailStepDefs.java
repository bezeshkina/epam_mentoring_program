package stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.lexer.Ru;
import pageObjects.*;

public class GmailStepDefs {
    @When("^I initialize creating new email")
    public void iInitializeCreatingNewEmail(){
        new InboxPage().clickCreateBtn();
    }

    @And("^I go to DraftCategory")
    public void iGoToDraftCategory(){
        new InboxPage().goToDrafts();
    }

    @Then("I log out")
    public void logOut(){
        try {
            new DraftsCategory().logOut();
            System.out.println("User log out");
        } catch (RuntimeException e){
            System.out.println("User couldn't log out");
        }
    }

    @And("^I create a draft for \"([^\"]*)\" with \"([^\"]*)\", \"([^\"]*)\" and close the window$")
    public void iCreateADraftForWithAndCloseTheWindow(String addressee, String subject, String textArea){
        new CreateEmailPage().createDraft(addressee, subject, textArea).closeWindow();
    }

    @And("^I compare content from the fields with \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iCompareContentFromTheFieldsWithAnd(String addressee, String subject, String textArea){
        new SendingEmailPage().verifyAddressee(addressee).verifySubject(subject).verifyText(textArea).sendEmail();
    }

    @Then("^I find the draft by \"([^\"]*)\" and click to it$")
    public void iFindTheDraftByAndClickToIt(String subject){
        new DraftsCategory().findElementOnPageAndClick(subject);
    }


    @Given("^I navigate to Gmail site$")
    public void iNavigateToGmailSite() {
        new LoginPage().openPage();
    }

    @Given("^I log in with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iLogInWithAnd(String login, String password){
        try {
            new LoginPage().fillLoginFieldAndClick(login).fillPasswordField(password);
            System.out.println("User successfully log in");
        }catch (RuntimeException e){
            System.out.println("User couldn't log in");
        }
    }
}
