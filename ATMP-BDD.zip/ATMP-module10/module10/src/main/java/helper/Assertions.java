package helper;

import org.testng.Assert;

public class Assertions {
    public void verifyEquels(String actual, String expected, String message){
        Assert.assertEquals(actual, expected, message);
    }
}
