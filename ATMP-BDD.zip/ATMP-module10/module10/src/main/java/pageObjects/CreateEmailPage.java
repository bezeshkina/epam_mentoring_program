package pageObjects;

import factory.Email;
import factory.EmailWithoutAttachments;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreateEmailPage extends Page {
    @FindBy(xpath = "//textarea[@aria-label='Кому']")
    private WebElement addresseeField;

    @FindBy(xpath = "//input[@name='subjectbox']")
    private WebElement subjectField;

    @FindBy(xpath = "//div[@aria-label='Тело письма']")
    private WebElement textAreaField;

    @FindBy(xpath = "//img[@data-tooltip='Сохранить и закрыть']")
    private WebElement closeBtn;

    public CreateEmailPage(){
        super();
    }

    public CreateEmailPage createDraft(String addressee, String subject, String text){
        Email email = new EmailWithoutAttachments();
        email.enterAddressee(addresseeField, addressee);
        email.enterSubject(subjectField, subject);
        email.enterText(textAreaField, text);
        return this;
    }

    public InboxPage closeWindow(){
        clickToElement(closeBtn);
        return new InboxPage();
    }
}
