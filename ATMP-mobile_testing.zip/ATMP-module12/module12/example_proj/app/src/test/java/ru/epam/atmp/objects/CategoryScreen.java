package ru.epam.atmp.objects;

import java.util.List;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;

public class CategoryScreen extends AbstractScreen{
    @AndroidFindAll(@AndroidBy(id = "by.onliner.catalog:id/text"))
    private List<AndroidElement> itemsList;

    public CategoryScreen(){
    }

    public ItemsListScreen goToItemsList(String text){
        for (AndroidElement element : itemsList){
            if (element.getText().contentEquals(text))
                element.click();
        }
        return new ItemsListScreen();
    }
}
