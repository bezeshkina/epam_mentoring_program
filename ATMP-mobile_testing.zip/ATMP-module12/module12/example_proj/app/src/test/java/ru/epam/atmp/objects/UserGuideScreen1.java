package ru.epam.atmp.objects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class UserGuideScreen1 extends AbstractScreen {
    @AndroidFindBy(id = "by.onliner.catalog:id/nextContainer")
    private MobileElement nextBtn;

    public UserGuideScreen1(){

    }

    public UserGuideScreen2 nextBtnClick(){
        nextBtn.click();
        return new UserGuideScreen2();
    }
}
