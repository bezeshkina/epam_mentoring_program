package ru.epam.atmp.objects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class StartScreen extends AbstractScreen{
    @AndroidFindBy(id = "by.onliner.catalog:id/nextContainer")
    private MobileElement nextBtn;

    public StartScreen(){
        super();
    }

    public UserGuideScreen1 nextBtnClick(){
        nextBtn.click();
        return new UserGuideScreen1();
    }
}
