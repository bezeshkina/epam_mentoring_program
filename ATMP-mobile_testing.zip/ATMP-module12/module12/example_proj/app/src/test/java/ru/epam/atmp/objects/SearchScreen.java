package ru.epam.atmp.objects;

import java.util.List;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SearchScreen extends AbstractScreen {
    @AndroidFindBy(id = "by.onliner.catalog:id/search_plate")
    private AndroidElement inputField;

    @AndroidFindAll(@AndroidBy(id = "by.onliner.catalog:id/text_name"))
    private List<AndroidElement> items;

    public SearchScreen enterText(String text){
        inputField.setValue(text);
        return this;
    }

    public SearchScreen goToItem(String text){
        for (AndroidElement element:items) {
            if (element.getText().contains(text)) {
                element.click();
            }
        }
        return this;
    }

    public Boolean verifyExpactedItem(String text){
        Boolean result = true;
        for (AndroidElement element:items){
            if (element.getText().contains(text)){
                result = true;
            }
            else
                result = false;
        }
        return result;
    }
}
