package ru.epam.atmp.objects;

import java.util.List;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;

public class CatalogueScreen extends AbstractScreen {
    @AndroidFindAll(@AndroidBy(id = "by.onliner.catalog:id/name"))
    private List<AndroidElement> items;

    public CatalogueScreen(){
    }

    public CategoryScreen goToCategory(String text){
        for (AndroidElement element : items){
            if (element.getText().contentEquals(text))
                element.click();
        }
        return new CategoryScreen();
    }
}
