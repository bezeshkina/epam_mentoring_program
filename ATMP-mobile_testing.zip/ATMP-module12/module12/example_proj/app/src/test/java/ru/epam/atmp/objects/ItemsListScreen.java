package ru.epam.atmp.objects;

import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class ItemsListScreen extends AbstractScreen {
    @AndroidFindBy(id = "by.onliner.catalog:id/menu_search")
    private AndroidElement searchBtn;

    public ItemsListScreen(){

    }

    public SearchScreen clickSearchBtn(){
        searchBtn.click();
        return new SearchScreen();
    }
}
