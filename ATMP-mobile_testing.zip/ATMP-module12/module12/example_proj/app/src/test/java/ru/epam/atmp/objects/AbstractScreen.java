package ru.epam.atmp.objects;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import ru.epam.atmp.Driver;

public abstract class AbstractScreen {
    protected AppiumDriver<AndroidElement> driver;

    public AbstractScreen() {
        this.driver = Driver.getInstance();
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
}
