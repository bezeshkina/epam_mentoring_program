package ru.epam.atmp;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class Driver {
    private static AppiumDriver<AndroidElement> ourInstance = null;
    private static String APK_PATH = "src/apk/test.apk";
    private static String DEVICE_NAME = "fef5ccf1";
    private static String APP_PACKAGE = "by.onliner.catalog";
    private static String APP_ACTIVITY = "by.onliner.catalog.ui.screen.categories.NavigationClassifiersActivity";
    private static String AVD = "Pixel_XL_API_25";
    private static String URL = "http://localhost:8080/wd/hub";
    private static String AUTOMATION_NAME = "Appium";
    private static int TIMEOUT = 150000;

    private Driver() {
    }

    public static AppiumDriver<AndroidElement> getInstance() {
        if (ourInstance == null) {
            try {
                ourInstance = initDriver();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return ourInstance;
    }

    public static AppiumDriver<AndroidElement> initDriver() throws Exception{
        AppiumDriver driver;
        File app = new File(APK_PATH);
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, DEVICE_NAME);
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
        capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
        //capabilities.setCapability("avd", "Pixel_XL_API_25");
        capabilities.setCapability("androidInstallTimeout", TIMEOUT);
        capabilities.setCapability("adbExecTimeout", TIMEOUT);
        capabilities.setCapability("appWaitDuration", TIMEOUT);
        capabilities.setCapability("newCommandTimeout", TIMEOUT);
        capabilities.setCapability("appPackage", APP_PACKAGE);
        capabilities.setCapability("appActivity", APP_ACTIVITY);
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, AUTOMATION_NAME);
        driver = new AndroidDriver<AndroidElement>(new URL(URL), capabilities);
        return driver;
    }

    public static void killEmulator(){
        if (ourInstance != null)
            ourInstance.quit();
        String[] aCommand = new String[]{"C:/Android/Sdk/platform-tools/adb.exe", "emu", "kill"};
        try {
            Process process = new ProcessBuilder(aCommand).start();
            process.waitFor(1, TimeUnit.SECONDS);
            System.out.println("Emulator closed successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
