package ru.epam.atmp.objects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class UserGuideScreen2 extends AbstractScreen {
    @AndroidFindBy(id = "by.onliner.catalog:id/nextContainer")
    private MobileElement nextBtn;

    public UserGuideScreen2(){
        super();
    }

    public UserGuideScreen3 nextBtnClick(){
        nextBtn.click();
        return new UserGuideScreen3();
    }
}
