package ru.epam.atmp.objects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class UserGuideScreen3 extends AbstractScreen{
    @AndroidFindBy(id = "by.onliner.catalog:id/nextContainer")
    private MobileElement nextBtn;

    public UserGuideScreen3(){
        super();
    }

    public GoToCatalogScreen nextBtnClick(){
        nextBtn.click();
        return new GoToCatalogScreen();
    }
}
