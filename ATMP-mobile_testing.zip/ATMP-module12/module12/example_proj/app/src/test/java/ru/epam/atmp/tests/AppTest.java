package ru.epam.atmp.tests;

import org.junit.After;
import org.junit.Assert;
import org.junit.Test;

import ru.epam.atmp.Driver;
import ru.epam.atmp.objects.CatalogueScreen;
import ru.epam.atmp.objects.CategoryScreen;
import ru.epam.atmp.objects.GoToCatalogScreen;
import ru.epam.atmp.objects.ItemsListScreen;
import ru.epam.atmp.objects.SearchScreen;
import ru.epam.atmp.objects.StartScreen;
import ru.epam.atmp.objects.UserGuideScreen1;
import ru.epam.atmp.objects.UserGuideScreen2;
import ru.epam.atmp.objects.UserGuideScreen3;

public class AppTest {
    private String request = "Lemfo LEM5 Pro";
    private String categoryName = "Красота и спорт";
    private String subCategoryName = "Умные часы и фитнес-браслеты";

    @Test
    public void appTest(){
        new StartScreen().nextBtnClick();
        new UserGuideScreen1().nextBtnClick();
        new UserGuideScreen2().nextBtnClick();
        new UserGuideScreen3().nextBtnClick();
        new GoToCatalogScreen().nextBtnClick();
        new CatalogueScreen().goToCategory(categoryName);
        new CategoryScreen().goToItemsList(subCategoryName);
        new ItemsListScreen().clickSearchBtn();
        new SearchScreen().enterText(request).goToItem(request);
        Assert.assertTrue("Умные часы Lemfo LEM5 Pro не найдены", new SearchScreen().verifyExpactedItem(request));
    }

    @After
    public void tearDown(){
        Driver.killEmulator();
    }
}
