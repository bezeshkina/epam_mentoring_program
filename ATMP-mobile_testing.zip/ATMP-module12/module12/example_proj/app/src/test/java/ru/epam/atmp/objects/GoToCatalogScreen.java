package ru.epam.atmp.objects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class GoToCatalogScreen extends AbstractScreen{
    @AndroidFindBy(id = "by.onliner.catalog:id/nextContainer")
    private MobileElement nextBtn;

    public GoToCatalogScreen(){

    }

    public CatalogueScreen nextBtnClick(){
        nextBtn.click();
        return new CatalogueScreen();
    }
}
