package pageObjects;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class Page {
    protected WebDriver driver;
    private static final int WAITING_FOR_ELEMENT_TIMEOUT = 10;

    public Page(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    protected void waitForElementAndClick(WebElement element){
        try{
            new WebDriverWait(driver, WAITING_FOR_ELEMENT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(element)).click();
        }
        catch (StaleElementReferenceException e){
            new WebDriverWait(driver, WAITING_FOR_ELEMENT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(element)).click();
        }
    }

    protected void waitForElementAndSendKey(WebElement element, String text){
        try{
            new WebDriverWait(driver, WAITING_FOR_ELEMENT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
        }
        catch (StaleElementReferenceException e){
            new WebDriverWait(driver, WAITING_FOR_ELEMENT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
        }
    }


}
