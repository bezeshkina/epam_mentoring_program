package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends Page{
    @FindBy(xpath = "//input[@id='identifierId']")
    protected WebElement loginField;

    @FindBy(xpath = "//input[@type='password']")
    protected WebElement pswField;

    @FindBy(xpath = "//span[text()='Далее']")
    protected WebElement submitBtn;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public LoginPage fillLoginField(){

    }


}
