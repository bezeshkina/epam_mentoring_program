package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.net.MalformedURLException;

public class InboxPage extends Page{
    @FindBy(xpath = "//div[text()='Написать']")
    protected WebElement createBtn;

    @FindBy(xpath = "//a[@title='Черновики']")
    protected WebElement draftsCategory;

    public InboxPage() throws MalformedURLException {
        super();
        waitTitle("Входящие");
    }

    public CreateEmailPage clickCreateBtn() throws MalformedURLException {
        waitForElementAndClick(createBtn);
        return new CreateEmailPage();
    }

    public DraftsCategory goToDrafts() throws MalformedURLException {
        jsAction(draftsCategory, jsHighlight);
        waitForElementAndClick(draftsCategory);
        jsAction(draftsCategory, jsUnhighlight);
        return new DraftsCategory();
    }
}
