package pages;

import java.net.MalformedURLException;

public class SentMsgPage extends Page{

    public SentMsgPage(String text) throws MalformedURLException {
        super();
        waitTitle(text);
    }
}
