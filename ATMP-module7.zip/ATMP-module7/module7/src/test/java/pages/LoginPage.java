package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.net.MalformedURLException;

public class LoginPage extends Page{
    private static final String url = "http://gmail.com";

    @FindBy(xpath = "//input[@id='identifierId']")
    private WebElement loginField;

    @FindBy(xpath = "//input[@type='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//span[text()='Далее']")
    private WebElement submitBtn;

    public LoginPage() throws MalformedURLException {
        super();
        waitTitle("Gmail");
    }

    public LoginPage openPage(){
        driver.get(url);
        return this;
    }

    public LoginPage fillLoginFieldAndClick(String login){
        waitForElementAndSendKeys(loginField, login);
        waitForElementAndClick(submitBtn);
        return this;
    }

    public LoginPage fillPasswordField(String pwd){
        waitForElementAndSendKeys(passwordField, pwd);
        return this;
    }

    public InboxPage Login() throws MalformedURLException {
        waitForElementAndClick(submitBtn);
        return new InboxPage();
    }
}
