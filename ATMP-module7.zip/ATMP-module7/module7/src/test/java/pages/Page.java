package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utils.WebDriverSingleton;

public abstract class Page {
    private final int DEFAULT_TIMEOUT_IN_SECONDS = 10;
    protected WebDriver driver;
    protected String jsHighlight = "arguments[0].style.border='3px solid red'";
    protected String jsUnhighlight = "arguments[0].style.border='0px'";
    protected String jsClick = "arguments[0].click();";

    protected Page(){
        this.driver = WebDriverSingleton.getInstance();
        PageFactory.initElements(driver, this);
    }

    protected void waitForElementAndClick(WebElement element){
        try {
            new WebDriverWait(driver, DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).click();
        } catch (StaleElementReferenceException e) {
            new WebDriverWait(driver, DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).click();
        }
    }

    protected void waitForElementAndSendKeys(WebElement element, String text) {
        try {
            new WebDriverWait(driver, DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
        } catch (StaleElementReferenceException e) {
            new WebDriverWait(driver, DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
        }
    }

    protected void waitTitle(String text){
        try {
            new WebDriverWait(driver, DEFAULT_TIMEOUT_IN_SECONDS).until(ExpectedConditions.titleIs(text));
        }
        catch (TimeoutException e){
            e.getStackTrace();
        }
    }

    protected void clickTab(){
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.TAB).build().perform();
    }

    protected void clickCtrlEnter(){
        Actions actions = new Actions(driver);
        actions.keyDown(Keys.CONTROL).sendKeys(Keys.RETURN).build().perform();
    }

    protected void jsAction(WebElement element, String parameter){
        ((JavascriptExecutor)driver).executeScript(parameter, element);
    }

    protected void verifyEquels(String actual, String expected, String message){
        try{
            Assert.assertEquals(actual, expected, message);
        }
        catch (AssertionError e){
            System.out.println(e);
        }
    }
}
