package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.net.MalformedURLException;

public class SendingEmailPage extends Page{
    @FindBy(xpath = "//input[@name='subject']")
    protected WebElement subjectText;

    @FindBy(css = ".aoD.hl>div:nth-child(1)>span")
    protected WebElement addresseeText;

    @FindBy(css = ".Ar.Au>div")
    protected WebElement textAreaText;

    @FindBy(css = ".gU.Up>div>div:nth-child(2)")
    protected WebElement sendBtn;

    public SendingEmailPage() throws MalformedURLException {
    }

    public DraftsCategory sendEmail() throws MalformedURLException {
        clickCtrlEnter();
        return new DraftsCategory();
    }

    public SendingEmailPage verifyAddressee(String expected){
        verifyEquels(addresseeText.getText(), expected, "Addressee isn't match");
        return this;
    }

    public SendingEmailPage verifySubject(String expected){
        verifyEquels(subjectText.getAttribute("value"), expected, "Subject isn't match");
        return this;
    }

    public SendingEmailPage verifyText(String expected){
        verifyEquels(textAreaText.getText(), expected, "Text isn't match");
        return this;
    }
}
