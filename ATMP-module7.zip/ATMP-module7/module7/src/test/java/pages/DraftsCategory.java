package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.net.MalformedURLException;
import java.util.List;

public class DraftsCategory extends Page{
    @FindBy(xpath = "//span[@class='bog']")
    protected List<WebElement> listOfEmails;

    public DraftsCategory(){
        super();
        waitTitle("Черновики");
    }

    public SendingEmailPage findElementOnPageAndClick(String text) throws MalformedURLException {
        for (WebElement element : listOfEmails){
            if (element.getText().contains(text)){
                jsAction(element, jsHighlight);
                jsAction(element, jsClick);
                return new SendingEmailPage();
            }
        }
        throw new AssertionError("Email isn't found");
    }
}
